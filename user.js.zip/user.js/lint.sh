#!/bin/bash

jshint {src/*.js,src/**/*.js}
