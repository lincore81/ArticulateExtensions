var test = require('tape');
var f = require('../src/f.js');

console.log('testing ../src/f.js');

(function test_afindIndex() {
    [{arr: [1, 2, 3, 4, 5], fn: n => n === 3, result: 2},
     {arr: [true], fn: (n) => n, result: 0},
     {arr: [], fn: (n) => n, result: -1}
    ].forEach(({arr, fn, result}) => {
        test('f.aFindIndex: ' + arr + ', expected: ' + result, t => {
            t.equal(f.afindIndex(arr, fn), result);
            t.end();
        })
    })
})();
            


(function test_amap() {
    [{arr: [1, 2, 3, 4, 5], fn: n => 2*n, result: [2, 4, 6, 8, 10]},
     {arr: [], fn: n => -n, result: []},
     {arr: ['Peter', 'Klaus', 'Hans'], fn: n => `Hallo, ${n}`, result: [
         'Hallo, Peter', 'Hallo, Klaus', 'Hallo, Hans']}
    ].forEach(({arr, fn, result}) => {
        test('f.amap: ' + arr + ', expected: ' + result, t =>
        {
            t.equal(f.amap(arr, fn), result);
            t.end();
        });

    })
})();
            
