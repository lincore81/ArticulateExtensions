var test = require('tape');
var utils = require('../src/utils.js');

function compareArrays(a, b) {
    if (a.length !== b.length) return false;
    for (var i = 0; i < a.length; i++) {
        if (a[i] !== b[i]) {
            return false;
        }
    }
    return true;
}


test('toArray', function(t) {
    function foo() {
        return utils.toArray(arguments);
    }
    var cases = [[1, 2, 3],
                 [],
                 ['foo', 'bar']];
    t.plan(cases.length);
    cases.forEach(function(x) {
        t.ok(compareArrays(x, foo.apply(null, x)), foo.apply(null, x));
    });
    t.end();
});

test('findInArray', function(t) {
    var cases = [
        [[1, 3, 10, 5, 7], function(n) {return n > 5;}, 10],
        [[], function(n) {return n > 5;}, undefined],
    ];
    cases.forEach(function (c) {
        t.ok(utils.findInArray(c[0], c[1]) === c[2], JSON.stringify(c));
    });
    t.end();
});
