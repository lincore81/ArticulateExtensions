"use strict";
var utils = require('../utils.js');
module.exports = canvasToPdf;

function canvasToPdf(api, logger) {

    var FOOTER = "spm GmbH | Friedrichstr. 13 | 19055 Schwerin | Telefon: 0385 / 34 41 932 | http://newspm.de";
    var DISCLAIMER = "Dieses Dokument ist ausschließlich für den persönlichen Gebrauch bestimmt. Eine Vervielfältigung ist ohne die ausdrückliche Zustimmung der spm GmbH nicht gestattet.";

    var WATERMARK_SRC = '/pdf_printer/image/spm_wasserzeichen.png';
    var JS_PDF_SRC =  '/pdf_printer/js/jspdf.min.js';
    var BTN_SAVE_ID = 'btn-save-pdf';

    var watermarkImage;
    var buttonSavePdf;
    var renderCanvas;
    logger.info('START');

    function sanitizeFilename(filename) {
       var badTimes = /[\$\&\^\!\?'"\\/\;\:\,\.<>\%\(\)\[\]\+\#\* -]+/g;
       return filename.replace(badTimes, '_'); 
    }

    api.onReady(ready);
    api.onSlideChange(onChange);
    api.onSlideClose(onClose);

    function ready() {
        utils.async(null, loadWatermark, insertScriptElement, addButton);
    }

    function onChange() {
        logger.info('slide change');
        addButton(function(){});
    }

    function onClose() {
        removeButton();
    }

    function insertScriptElement(callback) {
        var elem = document.createElement('script');
        document.head.appendChild(elem);
        elem.addEventListener('load', callback);
        elem.setAttribute('src', JS_PDF_SRC);
        logger.info('loading jspdf...');
    }

    function loadWatermark(callback) {
        logger.info('loading watermarkImage');
        watermarkImage = new Image();
        watermarkImage.src = WATERMARK_SRC;
        watermarkImage.addEventListener('load', callback); 
    }

    function addButton(callback) {
        logger.info('adding save image button');
        buttonSavePdf = document.createElement('div');
        buttonSavePdf.id = BTN_SAVE_ID;
        buttonSavePdf.innerHTML = '<div class="label">Bild speichern</div>';
        buttonSavePdf.className = 'controlbar-button';
        api.addControlElement(buttonSavePdf);
        buttonSavePdf.addEventListener('click', save);
        callback();
    }

    function removeButton() {
        api.removeControlElement('#' + BTN_SAVE_ID);
    }

    function save() {
        var title = api.getCourseTitle();
        var filename = sanitizeFilename(api.getSlideTitle() + '_' + title) + '.pdf';
        if (!renderCanvas) createRenderCanvas();
        var pdf = renderPdf(title);
        pdf.save(filename);
    }

    function createRenderCanvas() {
        logger.info('creating render canvas...');
        renderCanvas = utils.assertExists(document.createElement('canvas'));
        renderCanvas.width = api.elements.canvas.width;
        renderCanvas.height = api.elements.canvas.height + 300;
    }

    function renderPdf(title) {
        var ctx = utils.assertExists(renderCanvas.getContext('2d'));
        var horizCenter = renderCanvas.width / 2;
        var canvas = api.elements.canvas;
        var aspectRatio = renderCanvas.width / renderCanvas.height;

        // bei der Konvertierung zu jpeg werden alle transparenten Pixel
        // in schwarz konvertiert, daher kopiere ich die Folie auf einen zweiten
        // Canvas, den ich zuvor weiss einfaerbe.
        ctx.fillStyle = "white";
        ctx.fillRect(0, 0, renderCanvas.width, renderCanvas.height);
        ctx.drawImage(canvas, 0, 30);
        ctx.drawImage(watermarkImage, 0, 30);

        ctx.fillStyle = 'black';
        ctx.font = '24px Sans-Serif';
        ctx.textAlign = 'left';
        ctx.fillText(title, 0, 24, renderCanvas.width);
        ctx.font = '18px Sans-Serif';
        ctx.textAlign = 'center';
        ctx.fillText(FOOTER, horizCenter, canvas.height + 46, renderCanvas.width - 20);
        ctx.font = '12px Sans-Serif';
        ctx.fillText(DISCLAIMER, horizCenter, canvas.height + 64, renderCanvas.width - 20);

        // A4: 210mm x 297mm, @300dpi: 2480px x 3508px
        var data = renderCanvas.toDataURL('image/jpeg');
        /* globals jsPDF:false */
        var pdf = new jsPDF('landscape', 'mm', 'a4');
        var imgHeight = 240;
        var imgWidth = imgHeight * aspectRatio;
        var horizMargin = (297-imgWidth) / 2;
        var vertMargin = 20;
        pdf.addImage(data, 'JPEG', horizMargin, vertMargin, imgWidth, imgHeight);
        logger.info('pdf rendered.');
        return pdf;
    }

}


