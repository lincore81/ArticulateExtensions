"use strict";
/*
 * tooltip.js - Extrahiert eine Liste (genauer: Baum) der Folienueberschriften
 * aus dem Inhaltsverzeichnis (ul#slide_list) und zeigt die jeweils naechste
 * Ueberschrift via Tooltip an, wenn der User mit der Maus auf den "naechste
 * Folie"-Button faehrt.
 * Das Inhaltsverzeichnis befindet sich in einer ul#slide_list und besteht
 * aus li#_playerXXX Elementen, wobei XXX fuer die entsprechende Folien-Id steht.
 * Die momentan ausgewaehlte Folie ist li.selected.
 *
 */
var utils = require('../utils.js'),
    f = require('../f.js');
module.exports = tooltip;

// css fuer tooltip:
// jshint multistr:true
var style = '[data-tooltip] {\
  position: relative;\
  z-index: 2;\
  cursor: pointer;\
}\
[data-tooltip]:before,\
[data-tooltip]:after {\
  visibility: hidden;\
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";\
  filter: progid: DXImageTransform.Microsoft.Alpha(Opacity=0);\
  opacity: 0;\
  pointer-events: none;\
}\
[data-tooltip]:before {\
  position: absolute;\
  top: 120%;\
  min-width: 160px;\
  right: 0%;\
  margin-top: 19px;\
  padding: 10px;\
  -webkit-border-radius: 3px;\
  -moz-border-radius: 3px;\
  border-radius: 3px;\
  background-color: #000;\
  color: WhiteSmoke;\
  white-space: nowrap;\
  content: attr(data-tooltip);\
  text-align: center;\
  font-size: 14px;\
  line-height: 1.2;\
}\
/* kleiner pfeil: */\
[data-tooltip]:after {\
  position: absolute;\
  top: 120%;\
  left: 50%;\
  margin-left: -10px;\
  width: 0;\
  border-style: solid;\
  border-width: 0 0 20px 20px;\
  border-color: transparent transparent black transparent;\
  content: " ";\
  font-size: 0;\
  line-height: 0;\
}\
[data-tooltip]:hover:before,\
[data-tooltip]:hover:after {\
  visibility: visible;\
  -ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=100)";\
  filter: progid: DXImageTransform.Microsoft.Alpha(Opacity=100);\
  opacity: 1;\
}';

function tooltip(api, logger) {
    var buttonNext;
    logger.info('START');
    api.onReady(ready);
    api.onSlideChange(updateTooltip);
    api.onSlideClose(removeTooltip);

    function ready() {
        // css einfuegen:
        utils.addStyleSheet(api.elements.document, style);
        // 'naechste folie' button holen
        buttonNext = api.elements.document.getElementById('control-next');
        if (!buttonNext) logger.info('div#control-next nicht gefunden.');
        // tooltip setzen
        updateTooltip();
    }

    function updateTooltip() {
        if (!buttonNext) return;
        var doc = api.elements.document;
        var toc = api.request('toc');
        var text = getTooltipString(doc, toc);
        logger.info('onSlideChange text=', text, ' toc=', toc);
        if (text) {
            buttonNext.setAttribute('data-tooltip', text);
        } else if (buttonNext.hasAttribute('data-tooltip')) {
            removeTooltip();
        }
    }

    function removeTooltip() {
        logger.info('onSlideClose');
        buttonNext.removeAttribute('data-tooltip');
    }
}


/*
 * Return the next node from the current toc if either of the following conditions
 * is satisfied, otherwise return null:
 * a) the next node has children
 * b) the next node is higher up in the hierarchy
 *
 * Gibt die naechste Ueberschrift zurueck, wenn eine der folgenden Bedingungen
 * erfuellt ist, sonst null:
 * a) die naechste Ueberschrift hat Unterelemente
 * b) die naechste Ueberschrift ist eine ebene hoeher als die aktuelle Folie.
 */
function getTooltipString(doc, toc) {
    if (!toc) return;

    // last node?
    if (toc.selected === toc.chapters.length - 1) return;

    var currSection = toc.chapters[toc.selected],
        nextSection = toc.chapters[toc.selected+1];
    var a = nextSection.hasChildren,
        b = currSection.depth > nextSection.depth;
    return a || b? nextSection.title : null;
}

