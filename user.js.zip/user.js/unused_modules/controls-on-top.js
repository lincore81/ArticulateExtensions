"use strict";
/*
 * controls-on-top.js -- MOVE CONTROLS TO THE TOP:
 *
 * This module is responsible for 
 * - moving the .controls div above the .slideframe 
 * - removing the .topbar via `display: none`.
 * - integrating the .customlink from the .topbar into .controls
 *   and giving it the same look and feel as the other buttons in there
 *
 * ************************
 * * TOC * .topbar        *<--+
 * *     ******************   |
 * *     * .slideframe    *   |
 * *     *                *   |
 * *     *                *   |
 * *     *                *   |
 * *     *                *   |
 * *     *                *   |
 * *     *                *   |
 * *     ******************   |
 * *     * .controls      * --+
 * ************************
 *
 * Steps:
 * - hide .topbar: 
 *      + display: none;
 * - .controls change style:
 *      + top: 0px;
 *      + margin-top: 15px;
 *  - .slideframe change style:
 *      + top: 48px !important;
 *  - append info link to .controls
 *  - restyle info link:
 *      + add class 'controlbar-button' (opt: 'right')
 *      + create child div.label element
 *      + move text to child
 */

module.exports = controlsOnTop;
var utils = require('../utils.js');

function controlsOnTop(api, logger) {
    logger.info('START');
    // the slideframe's top position has to be readjusted when the slide is changed:
    // api.onSlideChange(adjustSlideframePosition);
    
    // change styles:
    api.elements.topbar.style.display = 'hidden';
    api.elements.controlPane.style.top = '0px';
    api.elements.controlPane.style.marginTop = '15px';
    var link;
    changeInfoLink();
    if (link) link.style.display = 'none';
    adjustSlideframePosition();

    api.onReady(updateInfoLink);
    api.onSlideChange(updateInfoLink);
    api.onSlideClose(function() {
        if (link) link.style.display = 'none';
    });

    function adjustSlideframePosition() {
        var style = 'div#slideframe {' +
                        'top: 48px !important;' +
                    '}';
        //api.elements.slideframe.style.top = '48px !important';
        var elem = utils.addStyleSheet(api.elements.document, style);
        logger.info('added style sheet:', elem);
    }

    function updateInfoLink() {
        var toc = api.request('toc');
        logger.info('toc:', toc);

        // if title is 'hilfe' hide the button:
        var isFirst = toc.selected === 0;
        link.style.display = isFirst? 'none' : 'inherit';
        
    }

    function changeInfoLink() {
        var elems = api.elements.topbar.getElementsByClassName('label customlink');
        if (elems.length < 1) {
            logger.info('changeInfoLink: no lightbox, no changes.');
            return;
        }
        if (elems.length > 1) {
            logger.warning('more than one .label.customlink found');
        }
        link = elems[0];
        logger.info('link:', link);
        link.className = 'controlbar-button';
        link.style.display = 'block';
        var text = link.innerText;
        link.innerText = '';
        var label = api.elements.document.createElement('div');
        label.innerText = text;
        label.className = 'label';
        link.appendChild(label);
        api.addControlElement(link);
    }
}
