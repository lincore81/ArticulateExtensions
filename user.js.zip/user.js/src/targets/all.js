"use strict";
var toc = require('../modules/toc.js');
// var controlsOnTop = require('../modules/controls-on-top.js');
// var zoom = require('../modules/zoom.js');    
var atheft = require('../modules/anti-theft.js');
// var tooltip = require('../modules/tooltip.js');
var endPrompt = require('../modules/end-prompt.js');
 
module.exports = {
    "toc": toc,
//    "control": controlsOnTop,
//    "zoom": zoom, 
    "atheft": atheft, 
//    "tooltip": tooltip,
    "endPrompt": endPrompt
};

