'use strict';

/* Als targets bezeichne ich alle ./targets/*.js Dateien. Diese werden via
 * browserify beim build dynamisch als 'target' geladen und geben ein array
 * mit gewuenschten Modulen zurueck, z.B. ['zoom', 'pdf'].
 */
var target = require('target');
var initApi = require('./api.js');
var Logger = require('./logger.js');
var f = require('./f.js');
        
(function main() {

    var logger = new Logger('main', Logger.LEVEL_NONE);
    var moduleNames = getValidModuleNames();
    var api = initApi(logger);

    window.addEventListener('DOMContentLoaded', api.preload);
    window.addEventListener('load', api.load);

    f.aiter(moduleNames, startModule);
    
    function startModule(name) {
        var module = target[name];
        try {
            module(api, logger);
            api.registerModule(name, module);
        } catch (e) {
            logger.error('Fehler in Modul ' + name + ':', e);
        }
    }

    function getValidModuleNames() {
        return f.afilter(Object.keys(target), function(key) {
            if (typeof target[key] === 'function') return true;
            logger.error('Invalid module, not a function:', key, target[key]);
        });
    }

})();

