

function EventSystem() {
    this._events = {};
    for (var i = 0; i < arguments.length; i++) {
        var name = arguments[i];
        if (typeof name !== 'string') {
            throw new Error('Arguments should be strings. ');
        }
        this._events[name] = [];
    }
}

EventSystem.prototype.subscribe = function(event, callback, caller) {
    if (!this._events[event]) {
        throw new Error('Unknown event type: ' + event);
    }
    if (typeof caller !== 'string') {
        throw new Error('caller should be a string.');
    }
    this._events[event].push({callback:callback, caller:caller});
};

EventSystem.prototype.fire = function(event, message, onError) {
    if (!this._events[event]) {
        throw new Error('Unknown event type: ' + event);
    }
    this._events[event].forEach(function(elem) {
        try {
            elem.callback(event, message);
        } catch (e) {
            if (onError) onError(e, elem.caller, elem.callback);
        }
    });
};
