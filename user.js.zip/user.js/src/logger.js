var LEVEL_DETAIL = 3,
    LEVEL_INFO = 2,
    LEVEL_WARN = 1,
    LEVEL_ERROR = 0,
    LEVEL_NONE = 0,
    LEVEL_ALL = Infinity;

var LEVELS = [
    {str: '(EE)', fn: function() {
        console.error.apply(console, arguments);                            
    }}, 
    {str: '(WW)'}, 
    {str: '(II)'},
    {str: '(DD)'}
];

var loggers = {
};

function defaultLogFn() {
    console.log.apply(console, arguments);
}

module.exports = Logger;

function Logger(name, level, parent) {
    this.name = name;
    this.parent = parent;
    if (typeof level !== 'undefined') this.logLevel = level;
    this.error = this.log.bind(this, LEVEL_ERROR);
    this.warning = this.log.bind(this, LEVEL_WARN);
    this.info = this.log.bind(this, LEVEL_INFO);
    loggers[name] = this;
}

Logger.prototype.getLoggerByName = getLoggerByName;

Logger.prototype.derive = function(name, level) {
    return new Logger(name, level, this);
};

Logger.prototype.log = function(level) {
    var logLevel = this.getLevel();
    if (level > logLevel) return;
    if (arguments.length <= 1) {
        throw new Error('log requires at least 2 arguments.');
    }
    var args = Array(arguments.length-1);
    for (var i = 1; i < arguments.length; i++) {
        args[i-1] = arguments[i];
    }
    var levelStr, fn;
    if (level >= 0 && level < LEVELS.length) {
        levelStr = LEVELS[level].str;
        fn = LEVELS[level].fn || defaultLogFn;
    } else {
        levelStr = '(' + level + ')';
        fn = defaultLogFn;
    }
    var ans = [levelStr + ' ' + this.name.toUpperCase() + ': '].concat(args);
    fn.apply(null, ans);
};

Logger.prototype.LEVEL_NONE = LEVEL_NONE;
Logger.prototype.LEVEL_ERROR = LEVEL_ERROR;
Logger.prototype.LEVEL_WARN = LEVEL_WARN;
Logger.prototype.LEVEL_INFO = LEVEL_INFO;
Logger.prototype.LEVEL_DETAIL = LEVEL_DETAIL;
Logger.prototype.LEVEL_ALL = LEVEL_ALL;

Logger.prototype.setLevel = function(level) {
    if (level !== 'undefined' && typeof level !== 'number') 
        throw new Error('setLevel: must be a number');
    this.logLevel = level;
};


Logger.prototype.getLevel = function() {
    var curr = this;
    while (curr && typeof curr.logLevel === 'undefined') curr = curr.parent;
    if (!curr) return LEVEL_NONE;
    return curr.logLevel;
};

function getLoggerByName(name) {
    return loggers.hasOwnProperty(name) && loggers[name];
}
