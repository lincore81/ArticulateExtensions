"use strict";
module.exports = antiTheft;

/**
 * Pseudo-Diebstahlsicherung, deaktiviert Kontextmenu fuer
 * Canvas. Kann unter ff mit Shift+Rechtsklick umgangen werden.
 * Fuer andere Browser sind entsprechende Erweiterungen verfuegbar.
 */
function antiTheft(api, logger) {
    logger.info('START');
    api.onReady(disableRightClick);
    api.onSlideChange(disableRightClick);

    function disableRightClick() {
        logger.info('disableRightClick()');
        api.elements.canvasDoc.onmousedown = function(event) {
            logger.info('canvasDoc.onmousedown');
            if (event.button === 2) {
                return false;
            }
        };

        api.elements.canvasBody.oncontextmenu = function() {
            logger.info('canvasBody.oncontextmenu');
            return false;
        };
    }
}
