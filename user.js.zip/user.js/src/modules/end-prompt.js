"use static";
/*
 * 
 *
 * This module puts a function in the slide's global environment.
 * When called (by the slide), a black panel with white text fades in from the 
 * right, indicating that the slide has ended.
 *
 * A variety of messagess can be shown. However, some constraints apply:
 * - a 'you're halfway done' message only makes sense when this statement is true.
 * - the same message should not be shown twice in a row.
 * - the algorithm choosing a message should be deterministic.
 * - in the first, last and second-to-last slide, special messages should be shown.
 *
 * Additional user stories:
 * - I can test the slide outside of the LMS and it logs the message in the 
 *   console.
 * - From within the slide I can adjust the messages to be shown.
 * - If the slide does not use this module, it should still work as intended.
 */
var utils = require('../utils.js');
var f = require('../f.js');

module.exports = endPrompt;

var style = "#end {\n" +
"    position: absolute;\n" +
"    bottom: 12px;\n" +
"    right: -12px;\n" +
"    background-color: rgba(51, 51, 51, .8);\n" +
"    color: gainsboro;\n" +
"    font-family: Arial, Sans-Serif;\n" +
"    font-size: 10pt;\n" +
"    font-weight: 100;\n" +
"    padding: 12px 36px 12px 12px;\n" +
"    transform: translateX(100%);\n" +
"}\n" +

"#end.animate {\n" +
"    animation-duration: 1s;\n" +
"    -webkit-animation-duration: 1s;\n" +
"    -moz-animation-duration: 1s;\n" +

"    animation-name: slide-in;\n" +
"    -webkit-animation-name: slide-in;\n" +
"    -moz-animation-name: slide-in;\n" +

"    animation-timing-function: ease-out, ease-in;\n" +
"    -webkit-animation-timing-function: ease-out, ease-in;\n" +
"    -moz-animation-timing-function: ease-out, ease-in;\n" +
"    transform: translateX(0);\n" +
"    -moz-transform: translateX(0);\n" +
"    -webkit-transform: translateX(0);\n" +
"}\n" +

"@keyframes slide-in {\n" +
"    from {\n" +
"        transform: translateX(100%);\n" +
"    }\n" +
"    67% {\n" +
"        transform: translateX(-12px);\n" +
"    }\n" +
"    to {\n" +
"        transform: translateX(0);\n" +
"    }\n" +
"}\n" +

"@-webkit-keyframes slide-in {\n" +
"    from {\n" +
"        transform: translateX(100%);\n" +
"        -webkit-transform: translateX(0);\n" +
"    }\n" +
"    67% {\n" +
"        transform: translateX(-12px);\n" +
"        -webkit-transform: translateX(-12px);\n" +
"    }\n" +
"    to {\n" +
"        transform: translateX(0);\n" +
"        -webkit-transform: translateX(0);\n" +
"    }\n" +
"}\n" +

"@-moz-keyframes slide-in {\n" +
"    from {\n" +
"        transform: translateX(100%);\n" +
"        -moz-transform: translateX(100%);\n" +
"    }\n" +
"    67% {\n" +
"        transform: translateX(-12px);\n" +
"        -moz-transform: translateX(-12px);\n" +
"    }\n" +
"    to {\n" +
"        transform: translateX(0);\n" +
"        -moz-transform: translateX(0);\n" +
"    }\n" +
"}";

/*
 * messages:
 * Enhaelt eine Liste der Texte, die in Endsprechblasen erscheinen sollen
 * sowie die Folienindezes, fuer die sie gelten. 
 * Die Liste wird der Reihe nach abgearbeitet, bis ein passender Eintrag gefunden
 * wurde.   
 *
 * slide: 
 *  - der Folienindex, beginnend bei 0.
 *  - Ein negativer Folienindex wird vom Ende gezaehlt, -1 beschreibt die letzte 
 *    Folie, -2 die vorletzte usw.
 *  - Ein Dezimalwert zwischen 0 und 1 entspricht einem prozentualen Wert, d.h:
 *    0.5 => 50% => die 5. Folie von 10 oder die 4. Folie von 7.
 *  - "any" trifft auf jede Folie zu und sollte daher nur am Ende der Liste
 *    vorkommen.
 *
 * minSlideCount:
 * Die Mindestanzahl an Folien die ein Kurs haben muss, damit dieser Eintrag
 * anwendbar ist. Insb. nuetzlich fuer prozentuale slide-Werte bei sehr kleinen
 * Kursen. 
 *
 * prompts:
 * Eine Liste der zulaessigen Texte. Der zu waehlende Text wird mithilfe des
 * Folienindexes berechnet, dadurch ist er fuer eine bestimmte Folie immer 
 * derselbe und aufeinander folgende Wiederholungen sind ausgeschlossen.
 *
 */


var settings = {
    "ignore": [1],
    "messages": [
        {"slide": 0, "prompts": [
            "Jetzt kann es losgehen."
        ]},
        {"slide": -1, "prompts": [
            "Geschafft!"
        ]},
        {"slide": -2, "prompts": [
            "Fast geschafft."
        ]},
        {"slide": -3, "prompts": [
            "Endspurt!",
            "Noch ein Kapitel.",
            "Nur noch ein Thema."
        ]},
        {"slide": 0.75, "minSlideCount": 10, "prompts": [
            "Nur noch ein paar Kapitel.",
            "Nur noch ein paar Themen."
        ]},
        {"slide": 0.5, "prompts": [
            "Die Hälfte ist geschafft."
        ]},
        {"slide": "any", "prompts": [
            "Fahren Sie bitte fort.",
            "Weiter geht’s!",
            "Und weiter …",
            "Weiter geht’s zum nächsten Kapitel!",
            "Auf geht’s zum nächsten Kapitel!",
            "Im nächsten Kapitel geht es weiter.",
            "Sehen wir uns das nächste Kapitel an.",
            "Es kann weitergehen."
        ]}
    ]
};



function endPrompt(api, logger) {
    logger.info('START');
    logger.info('Trying to load settings.json...'); 
    setTimeout(loadJson, 3000);
    api.onReady(ready);
    api.onSlideChange(setupSlide.bind(null, undefined));
    var prompts;
    var xhrSettled = false;
    var isReady = false;
    var xhrStart;
    function loadJson() {
        xhrStart = Date.now(); 
        utils.xhr('./story_content/settings.json', function(evt) {
            var timeTaken = Date.now() - xhrStart;
            logger.info('xhr response in ', timeTaken, 'ms');
            if (evt.target.responseURL.endsWith('settings.json')) {
                json = evt.target.response;
                var ans;
                try {
                    ans = JSON.parse(json);
                } catch (e) {
                    logger.error("Couldn't parse json:", json);
                }
                if (ans) {
                    settings = ans;
                    logger.info('loaded settings.json:', evt);
                }
            } else {
                logger.info('Unable to load settings.json:', evt);
            }
            xhrSettled = true;
            if (isReady) ready();     
        }, function(evt) {
            logger.info('Unable to load settings.json:', evt); 
            xhrSettled = true;
            if (isReady) ready();
        }, 'application/json');
    }

    function ready() {
        isReady = true;
        if (!xhrSettled) return;
        var courseTitle = api.getCourseTitle();
        var hash = Math.abs(utils.hashString(courseTitle || ''));
        var toc = api.request('toc-leaves-only', settings.ignore);
        logger.info('READY, hash:', hash, 'course title:', courseTitle, 'toc:', toc);
        var slideCount = toc && toc.chapters.length || 0;   
        settings.messages = filterInvalidMessages(settings.messages, logger, slideCount);
        prompts = getAllPrompts(settings, slideCount, hash); 
        logger.info('prompts: ', prompts);
        setupSlide(toc);
    }

    function setupSlide(toc) {
        toc = toc || api.request('toc-leaves-only', settings.ignore);
        logger.info('setupSlide, toc:', toc || 'none');
        var prompt;
        if (toc && (toc.selected || toc.selected === 0) && 
                prompts && prompts.length > toc.selected) 
        {
            prompt = prompts[toc.selected];
        } else {
            prompt = "Weiter geht's.";
        }
        var end = api.elements.canvasDoc.createElement('div');
        end.id = 'end';
        end.innerText = prompt;
        utils.addStyleSheet(api.elements.canvasDoc, style);
        var container = api.elements.canvasDoc.getElementById('dom_overlay_container');
        logger.info('appending to container: ', container, end);
        container.appendChild(end);

        api.elements.canvasWindow.endSlide = function(p) {
            if (p) end.innerText = p;
            end.className = "animate";
        };
        api.elements.canvasWindow.resetEnd = function() {
            end.className = '';
        };
    }
 
    function getAllPrompts(settings, slideCount, offset) {
        var ans = Array(slideCount);
        for (var i = 0; i < slideCount; i++) {
            ans[i] = getPrompt(settings, slideCount, i, offset);
        }
        return ans;
    }

    function getPrompt(settings, slideCount, slideIndex, offset) {
        for (var i = 0; i < settings.messages.length; i++) {
            var msg = settings.messages[i];
            if (!match(msg)) continue;
            logger.info('match slideCount:', slideCount, 'slideIndex:', slideIndex, 'offset:', offset, 'msg:', msg);
            return nextPrompt(msg.prompts);
        } 
        // uh oh, no match found. This should not happen...
        logger.error('No matching end message found for slide:', slideIndex, slideCount);
        // pretend nothing happened, tee-hee:
        return "Weiter geht's!";

        function nextPrompt(prompts) {
            var index = (slideIndex + offset) % prompts.length;
            return prompts[index];
        }

        // Determine if the given message's slide value matches slideIndex.
        function match(msg) {
            var t = typeof msg.slide;
            if (t === 'string' && msg.slide.toLowerCase() === 'any') {
                return true;
            } else if (t === 'number') {
                return slideIndex === utils.getAbsoluteSlideIndex(msg.slide, slideCount);
            }
        }
    }


    function filterInvalidMessages(messages, logger, slideCount) {
        return f.afilter(messages, isValid);

        function isValid(msg) {
            var type = typeof msg.slide;
            if (type !== 'number' && type !== 'string') {
                logger.error('bad format, slide must be number or string:', msg);
                return false;
            }
            if (type === 'string' && msg.slide.toLowerCase() !== 'any') {
                logger.error('bad format, when slide is a string, it should equal "any"', msg);
                return false;
            }
            var isInteger = msg.slide % 1 === 0;
            if ((msg.slide >= 1 || msg.slide <= 0) && !isInteger) {
                logger.error('bad format, slide outside of (0..1) should be an integer.', msg);
                return false;
            }
            if (msg.slide < 0 && Math.abs(msg.slide) >= slideCount) {
                logger.error('bad format, negative slide is too small (slideCount=' + 
                            slideCount + '):', msg);
                return false;
            }
            if (!msg.prompts || !msg.prompts.length) {
                logger.error('bad format, no prompts:', msg);
                return false;
            }
            return true;
        }
    }
}

