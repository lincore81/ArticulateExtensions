"use strict";
/** toc.js - extract the table of contents from html
 *
 */

var f = require('../f.js');
var utils = require('../utils.js');

module.exports = tocJs;

function tocJs(api, logger) {
    var toc, leaves;

    api.onSlideClose(function(){
        toc = undefined;
        leaves = undefined;
    });

    api.addService('toc', function() {
        logger.info('getting toc...');
        if (!toc) toc = getToc(api.elements.document);
        return toc;
    });

    api.addService('toc-leaves-only', function(filters) {
        if (!leaves) leaves = getLeavesOnly(api.elements.document, filters);
        return leaves;
    });

    function hasClass(elem, className) {
        return f.afindIndex(elem.classList, function(c) {return c === className;}) > -1;
    }


    function applyFilters(node, i, count, filters) {
        for (var j = 0; j < filters.length; j++) {
            var f = filters[j];
            var t = typeof f;
            if (t === 'number') {
                var n = utils.getAbsoluteSlideIndex(f, count);
                var ans = (n === i);
                if (ans) return false;
                else continue;
            }
            if (t === 'string') {
                if (f === node.title) return false;
                else continue;
            }
            if (f && f.constructor === RegExp) {
                if (f.test(node.title)) return false;
                else continue;
            }
            if (t === 'function') {
                if (f(node, i)) return false;
                else continue;
            }
        }
        return true;
    }

    function getDepth(elem) {
        // css class: depthN_M
        // M = Tiefe des elem-Knotes (ab 0).
        // keine Ahnung, welche Funktion M hat, war bis jetzt immer 0!
        var match = elem.className.match(/depth(\d+)_(\d+)/);
        //if (match && match[2] !== '0') logger.warning('HEY: depthN_M, M !== 0', elem);
        return match && parseInt(match[1]);
    }

    function getLeavesOnly(doc, filters) {
        toc = toc || getToc(doc);
        var leaves = {};
        leaves.chapters = f.afilter(toc.chapters, function(node, i) {
           if (node.hasChildren) return false;
           if (filters) {
               return applyFilters(node, i, toc.chapters.length, filters);
           }
           else return true;
       });
       leaves.selected = f.afindIndex(leaves.chapters, function(leaf, i) {
           return leaf.selected;
       });
       return leaves;
    }
    
    function getToc(doc) {
        var slideList = doc.getElementById('slide_list');
        if (!slideList) {
            logger.warning('#slide_list nicht gefunden, Abbruch.');
            return;
        }
        var chapterElems = slideList.getElementsByTagName('li');

        var selectedIndex = -1;
        var chapterInfo = f.amap(chapterElems, function(x, i) {
            var selected = hasClass(x, 'selected');
            if (selected) selectedIndex = i;
            return {
                hasChildren: hasClass(x, 'has_children'),
                title: x.textContent,
                depth: getDepth(x),
                selected: hasClass(x, 'selected')
            };
        });
        logger.info('getToc:', selectedIndex, chapterInfo);
        var ans = {
            selected: selectedIndex,
            chapters: chapterInfo
        }; 
        return ans;
    }
}

