"use strict";
/*
 * zoom-hack, erfindet die zoom-funktion neu.
 * debugging/problembehebung:
 * - ausfuerhliches logging ein/ausschalten:
 *     in der konsole toggleverbosity() tippen und mit enter bestaetigen.
 * - zoom zuruecksetzen:
 *     a) umschalt+linksklick auf die folie oder
 *     b) zoom.reset() in der konsole eingeen.
 * - zoom manuell festlegen:
 *     zoom.set(factor) in der konsole eingeben, wobei factor = prozent/100,
 *     100% entspricht factor=1.0
 *
 *
 * falls sich der seitenaufbau aendert, muss dieses skript ggf. angepasst werden.
 * verhalten:
 * - setzt die css width/height properties der folie auf je 100%, dadurch
 *   passt sich diese auch unter chrome der groesse des umgebenden iframe an.
 * - fuegt dem control pane ein menue hinzu aus dem der user die gewuenschte
 *   zoomstufe auswaehlen kann.
 * - das script reagiert auf groessenaenderungen des radwindow und stellt den
 *   dadurch erreichten zoom nummerisch dar. 
 * - deaktiviert die (ueberfluessigen) scrollbars des radwindow contentframes
 */

module.exports = zoom;
var utils = require('./../utils.js');


function zoom(api, logger) {
    logger.info('START');
    
    // diese zoomfaktoren werden dem zoommenue hinzugefuegt (1.0 entspricht 100%):
    var scaleFactors = [1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0];
    var zoomPreferenceKey = 'de.newspm.onlineacademy.user_zoom';
    var zoomControlId = 'control-zoom';
    var zoomControl, canvasMinWidth, canvasMinHeight;
    var isMobileOrTouch;
    var zoomSelect;

    // globale funktionen, bei problemen:
    api.elements.rootWnd.zoom = {};
    api.elements.rootWnd.zoom.select = onZoomSelected;
    api.elements.rootWnd.zoom.reset = onZoomSelected.bind(null, 1);

    
    // massstab zur berechnung der skalierung: 
    var initialWndWidth = api.elements.radWnd.GetWidth();
    var initialWndHeight = api.elements.radWnd.GetHeight();

    // verstecke ueberfluessige scrollbars:
    api.elements.body.style.overflow = 'hidden';

    api.onReady(ready);
    api.onSlideChange(ready);

    function ready(api, evt) {
        logger.info('READY', evt);
        if (evt === 'ready') {       
            var touch = utils.isTouchSupported();
            var mobile = utils.isMobileUserAgent();
            var small = Math.max(screen.width, screen.height) < 998;
            isMobileOrTouch = (touch || mobile || small);
            logger.info('touch=' + touch, 'mobile-ua=' + mobile, 'small=' + small);
        }
        setupCanvas();
        if (isMobileOrTouch) return;
        setupWindowResizeHandler();
        setupZoomControl(evt);
        if (evt === 'ready') loadUserPref();
        // shift+click setzt den zoom zurueck:
        api.elements.canvasDoc.documentElement.addEventListener('click', function(ev) {
            if (!ev.shiftKey) return;
            onZoomSelected(1);
            zoomSelect.value = 1;
        });
    }

    
    function setupCanvas() {
        canvasMinWidth = api.elements.canvas.clientWidth;
        canvasMinHeight = api.elements.canvas.clientHeight;

        utils.addStyleSheet(api.elements.canvasDoc, "#canvas {\n" +
        "   min-width: " + canvasMinWidth + "px !important;\n" +
        "   min-height: " + canvasMinHeight + "px !important;\n" +
        "   width: 100%;\n" +
        "   height: 100%;\n" +
        "}");
    }
    
    function setupWindowResizeHandler() {
        // verarbeite maximal 10 resize events pro sekunde:
        var resizeTimeout;
        window.addEventListener('resize', function() {
            if (!resizeTimeout) {
                resizeTimeout = setTimeout(function() {
                    resizeTimeout = null;
                    onRadWindowResize();
                }, 100); 
            }
        }, false);
    }

    /**
     * fuegt unterhalb der Folie ein drop-down Menue ein, mit dem unter den in 
     * ZOOM_LEVELS definierten Skalierungsstufen gewaehlt werden kann.
     */
    // setupZoomControl {{{2
    function setupZoomControl(evt) {
        if (evt === 'ready') {
            zoomSelect = document.createElement('select');
            zoomSelect.id = "zoomlvl-menu";
            zoomSelect.style.height = '20px';
            zoomSelect.style.verticalAlign = 'text-bottom';
            zoomSelect.style.marginLeft = '1em';
            var zoomSelectInner = [];
            scaleFactors.forEach(function(value) {
                zoomSelectInner.push('<option value="' + value + '">' + Math.floor(value * 100) + '%</option>\n');
            });
            zoomSelect.innerHTML = zoomSelectInner.join('') + '</select>\n\t';

            var label = document.createElement('div');
            label.className = 'label';
            label.innerText = 'Größe:';
            label.appendChild(zoomSelect);

            var zoomControl = document.createElement('div');
            zoomControl.className = 'controlbar-button';
            zoomControl.id = zoomControlId;
            zoomControl.appendChild(label);
            zoomControl.style.paddingBottom = '3px';
            zoomControl.style.paddingTop = '2px';
            api.addControlElement(zoomControl);
        }
        zoomSelect.onchange = function(event) {
            onZoomSelected(event.target.value);
        };
    }
    // 2}}}
    
    function measureZoom() {
        var sx = api.elements.radWndWrapper.clientWidth / initialWndWidth;
        var sy = api.elements.radWndWrapper.clientHeight / initialWndHeight;
        return Math.min(sx, sy);
    }
    
    
    /**
     * Skaliert die Folie entsprechend des vom User gewaehlten Faktors.
     * @param {number} factor, positiver Groessenfaktor, 1.0 = 100%
     */
    function onZoomSelected(factor) {
        utils.assert(factor && factor > 0, "setZoom: Falscher Paramter '" + factor + "', erwarte (factor > 0)");
        logger.info("Skaliere auf " + factor);
        var newWidth = initialWndWidth * factor,
            newHeight = initialWndHeight * factor;
        api.elements.radWnd.SetSize(newWidth, newHeight);
        api.elements.radWnd.Center();
        saveUserPref(factor);
    }
    
    
    /**
     * Passt den Zoomfaktor im Menue der neuen Groesse des RadWindow an.
     */
    function onRadWindowResize() {
        var scale = Math.round(measureZoom() * 10) / 10;
        logger.info('onWindowResize: scale=' + scale);
        var i = utils.getFloatInArray(scale, scaleFactors, 0.1);
        if (i) zoomSelect.value = scaleFactors[i];
        saveUserPref(scale);
    }

    function loadUserPref() {
        var savedScale = localStorage.getItem(zoomPreferenceKey);
        if (savedScale) {
            onZoomSelected(savedScale);
            var i = utils.getFloatInArray(savedScale, scaleFactors, 0.1);
            if (i) zoomSelect.value = scaleFactors[i];
        }
    }
    
    function saveUserPref(n) {
        localStorage.setItem(zoomPreferenceKey, ''+n);
    }
    
} // end zoom()
