"use static";
// mehr fp fuer es5
var f = {};
module.exports = f;

f.aiter = function(arr, fn) {
    for (var i = 0; i < arr.length; i++) fn(arr[i], i, arr);
};

f.aexists = function(arr, fn) {
    return f.afindIndex(arr, fn) > -1;
};

f.afindIndex = function(arr, fn) {
    for (var i = 0; i < arr.length; i++) {
        if (fn(arr[i], i, arr)) return i;
    }
    return -1;
};

f.afind = function(arr, fn) {
    var n = f.afindIndex(arr, fn);
    return n >= 0? arr[n] : null;
};

// map([a']) => [b']
f.amap = function(arr, fn) {
    var ans = Array(arr.length);
    f.aiter(arr, function(x, i, arr) {
        ans[i] = fn(x, i, arr);
    });
    return ans;
};

f.foldRight = function(arr, acc, fn) {
    f.aiter(arr, function(x, i, arr) {
        acc = fn(acc, x, i, arr);
    });
    return acc;
};

f.afilter = function(arr, fn) {
    var ans = [];
    f.aiter(arr, function(x, i) {
        if (fn(x, i, arr)) ans.push(x);
    });
    return ans;
};

f.agen = function(fn, start) {
    var i = start || 0;
    var arr = [];
    while (true) {
        var x = fn(i++);
        console.log(x);
        if (x === undefined) return arr;
        arr.push(x);
    }
};
