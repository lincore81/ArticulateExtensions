"use static";
var utils = require('./utils.js');
module.exports = extensionApi;

/*
 * ExtensionApi: {
 *  verbose: {boolean}
 *  isReady: {boolean}
 *  getLogger("module_name") : {string => ()}
 *  getCourseTitle(): {string}
 *  getSlideTitle(): {string}
 *
 * events:
 *  onReady(callback: API => ());
 *  onSlideChange(callback: (API, 'slide change') => ());
 *  onSlideClose(callback: (API, 'slide close') => ());
 *
 * HTML-elemente:
 *  elements: {
 *      document
 *      body: body Element der story.html (im Rad-Window)
 *      rootWnd: das oberste window
 *      slidecontainer: 
 *          in der story.html, beinhaltet den iframe mit der Folie,
 *          wird dynamisch ins DOM eingefuegt.
 *      radWnd: die aktive RadWindow Instanz
 *      radWndContent,
 *      radWndWrapper,
 *      canvasFrame,
 *      canvas
 *  }
 *
 * }
 *

// {{{1 ExtensionApi
/**
 *  Stellt grundlegende Funktionen bereit, mit denen Erweiterungen einfacher 
 *  realisiert werden koennen.
 *
 *  - beobachtet und reagiert auf den Ladevorgang des Kurses
 *  - stellt ein Eventsystem bereit, um auf das Oeffnen und Schliessen von
 *    Folien reagieren zu koennen.
 *  - haelt alle relevanten HTML Elemente unter api.elements vor.
 *
 * @returns {object} Das api Objekt, ueber das Erweiterungen auf die o.g.
 *                   Funktionen zugreifen koennen.
 */
function extensionApi(logger) {
    var api = {};
    init();
    return api;

    // {{{2 init()
    function init() {
        api.logger = logger.derive('API');
        api.preload = preload;
        api.load = load;
        api.isReady = false;
        api.state = 'init';


        // nur loggen wenn api.verbose:
        api.verbose = !!(localStorage && localStorage.getItem(
                    'de.newspm.onlineacademy.verbose') === 'true');
        if (api.verbose) {
            logger.setLevel(logger.LEVEL_ALL);
        }
        api.modules = {};
        api.events = {ready:[], slideChange:[], slideClose:[]};
        api.onPreload = function(callback) {

        };
        api.onReady = function(callback) {
            if (api.isReady) {
                callback(api);
            } else {
                api.events.ready.push(callback);
            }
        };
        api.onSlideChange = function(callback) {
            api.events.slideChange.push(callback);
        };
        api.onSlideClose = function(callback) {
            api.events.slideClose.push(callback);
        };
        api.registerModule = function(name, module) {
            api.modules[name] = module;
        };

        api.services = {};
        api.addService = function(name, fn) {
            utils.assertExists(name, 'name');
            utils.assertExists(fn, 'fn');
            api.services[name] = fn;
        };
        api.hasService = function(name) {
            return api.services.hasOwnPorperty(name);
        };
        api.request = function(name, param) {
            var fn = api.services[name];
            if (!fn || !api.services.hasOwnProperty(name)) {
                api.logger.warning('no service: ' + name);
                return;
            }
            return fn(param);
        };
    }
    // init 2}}}


    function preload() {  
        api.state = 'preload';      
        // in general, moduls should not hold references to DOM elements
        api.elements = {
            document: document,
            body: document.getElementsByTagName('BODY')[0],
            rootWnd: utils.getRootWindow(),
            slidecontainer: document.getElementById('slidecontainer'),
            slideframe: document.getElementById('slideframe'),
            controlPane: document.getElementById('controls'),
            topbar: document.getElementById('topbar')
        };
        api.elements.radWnd = api.elements.rootWnd.GetRadWindowManager().GetActiveWindow();
        api.elements.radWndContent = api.elements.radWnd.GetContentFrame().contentWindow;
        api.elements.radWndWrapper = api.elements.rootWnd.document.getElementById('RadWindowWrapper_ContentWindow');    

        Object.keys(api.elements).forEach(function(k) {
            if (!api.elements.hasOwnProperty(k)) return;
            utils.assertExists(api.elements[k], k);
        });

        // optional elements:
        api.elements.infoButton = api.elements.topbar;

        api.elements.rootWnd.toggleVerbosity = function() {
            api.verbose = !api.verbose;
            localStorage.setItem('de.newspm.onlineacademy.verbose', api.verbose);
            return api.verbose;
        };
        api.elements.rootWnd.toggleDebug = function() {
            api.debug = !api.debug;
            api.elements.rootWnd.extapi = api.debug? api : undefined;
            localStorage.setItem('de.newspm.onlineacademy.debug', api.debug);
            return api.debug;
        };

        /**
         * Gibt den Namen des Kurses (ggf. zusammen mit dem Folienname)
         * zurueck.
         * Z. Zt. gibt es zwei designs, wobei jedes eine andere Methode
         * erfordert, um den Kursnamen zu erfahren.
         */
        api.getCourseTitle = function() {
            // altes design (< 2016)
            var e = document.getElementById('storytitle_section');
            if (e && utils.isVisible(e)) return e.textContent;
            // neues design (~06/2016)
            e = api.elements.radWnd.GetTitlebar();
            if (!e) {
                api.logger.warning('Konnte Kursnamen nicht finden, hat sich das Layout geaendert?');
                return '';
            }
            // entferne Text ab der ersten Klammer oder Close am Ende
            // (alt-text des Schliessen-buttons)
            var title = e.textContent.replace(/\(.*$/, '').replace(/Close$/, '').trim();
            return title;
        };

        api.getSlideTitle = function() {
            var e = document.querySelector('ul#slide_list > li.selected');
            return e? e.textContent : '';
        };
    }

    function load() {
        api.state = 'load';
        utils.async(null, lookForCanvasFrame, loadCanvasFrame, setCanvas, ready);
    }

    /**
     * wartet, bis der iframe, in dem die Folien-canvas liegt, dem Dokument
     * zugefuegt wurde. MutationObserver werden von IE 10 nicht unterstuetzt,
     * daher benutze ich timeouts.
     */
    // lookForCanvasFrame {{{2
    function lookForCanvasFrame(callback) {
        var timerid = setInterval(ontime, 100);
        api.logger.info('lookForCanvasFrame()');
        function ontime() {
            var frame = document.getElementsByTagName('iframe');
            if (frame.length >= 1) {
                api.logger.info('iframe gefunden.');
                if (frame.length > 1)
                    api.logger.warning('habe nur einen iframe erwartet, aber mehrere gefunden! Das koennte bedeuten, dass das Skript ueberarbeitet werden muss.');
                clearInterval(timerid);
                callback(frame[0]);
                return;
            }
        }
    }
    // 2}}}

    // loadCanvasFrame {{{2
    function loadCanvasFrame(callback, canvasFrame) {
        api.logger.info('loadCanvasFrame(): ', canvasFrame);
        api.elements.canvasFrame = canvasFrame;
        api.elements.canvasWindow = canvasFrame.contentWindow;
        var doc = utils.getFrameDocument(canvasFrame);
        api.logger.info('canvasFrame', canvasFrame, 'doc', doc, 'readyState', doc && doc.readyState);
        if (doc && doc.readyState === 'complete') {
            callback();
            return;
        } 
        // in 20 secs. assume the loading failed 
        var timeoutId = setTimeout(function() {
            api.logger.info('canvas iframe wurde nicht geladen.');
            wait();
        }, 20*1000);

        canvasFrame.addEventListener('load', function() {
            api.logger.info('iframe geladen');
            clearTimeout(timeoutId);
            callback();
        });
    }
    // 2}}}

    // setCanvas {{{2
    function setCanvas(callback) {
        api.logger.info('setCanvas()');
        api.elements.canvasDoc = utils.assertExists(
                utils.getFrameDocument(api.elements.canvasFrame), 'canvasDoc');

        api.elements.canvasBody = utils.assertExists(
                api.elements.canvasDoc.getElementsByTagName('BODY')[0], 'body element');

        api.elements.canvas = utils.assertExists(
                api.elements.canvasDoc.getElementById('canvas'), 'canvas');

        callback();
    }
    // 2}}}

    // observeSlideChange {{{2
    function observeSlideChange(callback) {
        api.logger.info('wait for slide change...');
        var slideDiv = document.getElementsByClassName('slide')[0];
        var id = slideDiv.id;
        var millis = 250;
        var timer = setInterval(function() {
            if (document.getElementById(id)) return;
            clearInterval(timer);
            api.logger.info('slide change observed');
            slideClose();
            callback();
        }, millis);
    }
    // 2}}}

    // {{{2 wait
    function wait() {
        api.logger.info('wait()');
        utils.async(null, observeSlideChange, lookForCanvasFrame, loadCanvasFrame, setCanvas, slideChange);
    }
    // 2}}}

    // ready {{{2
    function ready(callback) {
        api.logger.info('READY.');
        api.state = 'ready';
        api.events.ready.forEach(function(f) {
            try {
                f(api, 'ready');
            } catch (e) {
                api.logger.error('Exception raised in ready listener:', e);
            }
        });
        callback();
        wait();
    }
    // 2}}}

    // slideChange {{{2
    function slideChange(callback) {
        api.logger.info('slideChange');
        api.events.slideChange.forEach(function(f) {
            try {
                f(api, 'slide change');
            } catch (e) {
                api.logger.error('Exception raised in "slide change" listener:', e);
            }
        });
        callback();
        wait();
    }
    // 2}}}

    // slideClose {{{2
    function slideClose() {
        api.logger.info('slideClose');
        api.events.slideClose.forEach(function(f) {
            try {
                f(api, 'slide close');
            } catch (e) {
                api.logger.error('Exception raised in "slide close " listener:', e);
            }
        });
    }
    // 2}}}

} // 1}}} ExtensionApi

                
