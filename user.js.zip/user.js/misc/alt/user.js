/* 
 * Inhalt:
 * - ExtensionApi()
 * - zoom(api)
 * - 
 */
window.addEventListener('load', function() {
    'use strict';
    var api = ExtensionApi();
    try {
        zoom(api);
    } catch (e) {
        console.log('zoom:', e);
    }
    try {
        canvasToPdf(api);
    } catch (e) {
        console.log('canvasToPdf:', e);
    }
});

// start ExtensionApi
function ExtensionApi() {
    var api = {};
    init();
    async(null, lookForCanvasFrame, loadCanvasFrame, setCanvas, ready);
    return api;

    function init() {
        api.isReady = false;
        api.verbose = localStorage.getItem('de.newspm.onlineacademy.verbose') || false;
        if (api.verbose) console.log('ExtensionApi.init()');
        api.events = {ready:[], slideChange:[]};

        api.elements = {};
        api.elements.body = assertExists(document.getElementsByTagName('BODY')[0], 'body');
        api.elements.rootWnd = assertExists(getRootWindow(), 'rootWnd');
        api.elements.slidecontainer = assertExists(document.getElementById('slidecontainer'), 'slidecontainer');
        api.elements.controlPane = assertExists(document.getElementById('controls'), 'div#controls');
        api.elements.radWnd = assertExists( api.elements.rootWnd.GetRadWindowManager().GetActiveWindow(), 'radWnd');
        api.elements.radWndContent = api.elements.radWnd.GetContentFrame().contentWindow;
        api.elements.radWndWrapper = api.elements.rootWnd.document.getElementById('RadWindowWrapper_ContentWindow');    
        
        api.elements.rootWnd.toggleVerbosity = function() {
            api.verbose = !api.verbose;
            localStorage.setItem('de.newspm.onlineacademy.verbose', api.verbose);
            return api.verbose;
        };

        api.onReady = function(callback) {
            if (api.isReady) {
                callback(api);
            } else {
                api.events.ready.push(callback);
            }
        };

        api.onSlideChange = function(callback) {
            api.events.slideChange.push(callback);
        };

        api.addControlElement = function(controlElement) {
           api.elements.controlPane.appendChild(controlElement);
        };

        api.removeControlElement = function(selector) {
            var elem = api.elements.controlPane.querySelector(selector);
            if (!elem) return false;
            elem.remove();
            return true;
        };

        api.getSlideTitle = function() {
            var e = document.getElementById('storytitle_section') || document.querySelector('li.selected')
            return api.elements.storyTitle.textContent;
        };
    }


    /** 
     * Wartet bis der die Folie beinhaltende iframe dem div#slidecontainer hinzugefuegt wurde.
     * @param {MutationRecord[]} mutations ein Array aller stattgefundenen Veraenderungen vom
     *                           Element mit der id 'slidecontainer'
     */
    function lookForCanvasFrame(callback) {
        if (api.verbose) console.log('lookForCanvasFrame()');
        var observer = new MutationObserver(observerCallback);
        observer.observe(api.elements.slidecontainer, {attributes: false, childList: true, characterData: false});
        function observerCallback(mutations) {
           findInArray(mutations, function(mutation) {
                if (api.verbose) console.log(mutation);
                var added = findElement(mutation.addedNodes,   'DIV',    ['slide', 'transitionable', 'in']);
                if (!added) return false;
                var webobj = findElement(added.children,       'DIV',    ['item', 'webobject']);
                if (!webobj) return false;
                var canvasFrame = findElement(webobj.children, 'IFRAME', ['item', 'webobject', 'unhideable']);
                if (!canvasFrame) return false;

                if (api.verbose) console.log('iframe gefunden, warte bis geladen...');
                observer.disconnect();
                callback(canvasFrame); 
                return true;
            });
        }
    }


    function loadCanvasFrame(callback, canvasFrame) {
        var timeoutId = setTimeout(function() {
            if (api.verbose) console.log('Konnte canvasFrame nicht finden.');
        }, 20*1000);

        if (api.verbose) console.log('loadCanvasFrame(): ', canvasFrame);
        api.elements.canvasFrame = canvasFrame;
        canvasFrame.addEventListener('load', function() {
            clearTimeout(timeoutId);
            callback();
        });
    }

    function setCanvas(callback) {
        if (api.verbose) console.log('setCanvas()');
        api.elements.canvasDoc = assertExists(getFrameDocument(api.elements.canvasFrame), 'canvasDoc');
        api.elements.canvasBody = assertExists(api.elements.canvasDoc.getElementsByTagName('BODY')[0], 'body element');
        api.elements.canvas = assertExists(api.elements.canvasDoc.getElementById('canvas'), 'canvas');
        callback();
    }

    function ready(callback) {
        if (api.verbose) console.log('ready()');
        api.isReady = true;
        api.events.ready.forEach(function(f) {
            f(api, 'ready');
        });
        async(null, lookForCanvasFrame, loadCanvasFrame, setCanvas, slideChange);
        callback();
    }

    function slideChange(callback) {
        if (api.verbose) console.log('slideChange');
        api.events.slideChange.forEach(function(f) {
            f(api, 'slide change');
        });
        async(null, lookForCanvasFrame, loadCanvasFrame, setCanvas, slideChange);
        callback();
    }

} // end ExtensionApi


/*
 * zoom-hack, erfindet die zoom-funktion neu.
 * debugging/problembehebung:
 * - ausfuerhliches logging ein/ausschalten:
 *     in der console zoom.toggleverbosity() tippen und mit enter bestaetigen.
 * - zoom zuruecksetzen:
 *     a) umschalt+linksklick auf die folie oder
 *     b) zoom.reset() in der konsole eingeen.
 * - zoom manuell festlegen:
 *     zoom.set(factor) in der konsole eingeben, wobei factor = prozent/100,
 *     100% entspricht factor=1.0
 *
 *
 * falls sich der seitenaufbau aendert, muss dieses skript ggf. angepasst werden.
 * verhalten:
 * - setzt die css width/height properties der folie auf je 100%, dadurch
 *   passt sich diese auch unter chrome der groesse des umgebenden iframe an.
 * - fuegt dem control pane ein menue hinzu aus dem der user die gewuenschte
 *   zoomstufe auswaehlen kann.
 * - das script reagiert auf groessenaenderungen des radwindow und stellt den
 *   dadurch erreichten zoom nummerisch dar. 
 * - deaktiviert die scrollbars des radwindow contentframes
 */

function zoom(api) {
    if (api.verbose) console.log('zoom() start...');
    
    // diese zoomfaktoren werden dem zoommenue hinzugefuegt (1.0 entspricht 100%):
    var scaleFactors = [1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0];
    var zoomPreferenceKey = 'de.newspm.onlineacademy.user_zoom';
    var zoomControlId = 'control-zoom';
    var zoomControl, canvasMinWidth, canvasMinHeight;
    var isMobileOrTouch;

    // globale funktionen, bei problemen:
    api.elements.rootWnd.zoom = {};
    api.elements.rootWnd.zoom.select = onZoomSelected;
    api.elements.rootWnd.zoom.reset = onZoomSelected.bind(this, 1);

    
    // massstab zur berechnung der skalierung: 
    var initialWndWidth = api.elements.radWnd.GetWidth();
    var initialWndHeight = api.elements.radWnd.GetHeight();

    // verstecke ueberfluessige scrollbars:
    api.elements.body.style.overflow = 'hidden';

    api.onReady(ready);
    api.onSlideChange(ready);

    function ready(api, evt) {
        if (api.verbose) console.log('zoom ' + evt);
        if (evt === 'ready') {       
            var touch = isTouchSupported();
            var mobile = isMobileUserAgent();
            var small = Math.max(screen.width, screen.height) < 998;
            isMobileOrTouch = (touch || mobile || small);
            if (api.verbose) console.log('touch=' + touch, 'mobile-ua=' + mobile, 'small=' + small);
        }
        setupCanvas();
        if (isMobileOrTouch) return;
        setupWindowResizeHandler();
        setupZoomControl(evt);
        if (evt === 'ready') loadUserPref();
        // shift+click setzt den zoom zurueck:
        api.elements.canvasDoc.documentElement.addEventListener('click', function(ev) {
            if (!ev.shiftKey) return;
            onZoomSelected(1);
            zoomSelect.value = 1;
        });
    }

    
    function setupCanvas() {
        canvasMinWidth = parseInt(api.elements.canvas.width);
        canvasMinHeight = parseInt(api.elements.canvas.height);

        addStyleSheet(api.elements.canvasDoc, "#canvas {\n" +
        "   min-width: " + canvasMinWidth + "px !important;\n" +
        "   min-height: " + canvasMinHeight + "px !important;\n" +
        "   width: 100%;\n" +
        "   height: 100%;\n" +
        "}");
    }
    
    function setupWindowResizeHandler() {
        // verarbeite maximal 10 resize events pro sekunde:
        var resizeTimeout;
        window.addEventListener('resize', function() {
            if (!resizeTimeout) {
                resizeTimeout = setTimeout(function() {
                    resizeTimeout = null;
                    onRadWindowResize();
                }, 100); 
            }
        }, false);
    }

    /**
     * fuegt unterhalb der Folie ein drop-down Menue ein, mit dem unter den in 
     * ZOOM_LEVELS definierten Skalierungsstufen gewaehlt werden kann.
     */
    function setupZoomControl(evt) {
        if (evt === 'ready') {
            zoomSelect = document.createElement('select');
            zoomSelect.id = "zoomlvl-menu";
            zoomSelect.style.height = '20px';
            zoomSelect.style.verticalAlign = 'text-bottom';
            zoomSelect.style.marginLeft = '1em';
            var zoomSelectInner = [];
            scaleFactors.forEach(function(value) {
                zoomSelectInner.push('<option value="' + value + '">' + Math.floor(value * 100) + '%</option>\n');
            });
            zoomSelect.innerHTML = zoomSelectInner.join('') + '</select>\n\t';

            var label = document.createElement('div');
            label.className = 'label';
            label.innerText = 'Größe:';
            label.appendChild(zoomSelect);

            var zoomControl = document.createElement('div');
            zoomControl.className = 'controlbar-button';
            zoomControl.id = zoomControlId;
            zoomControl.appendChild(label);
            api.addControlElement(zoomControl);
        }
        zoomSelect.onchange = function(event) {
            onZoomSelected(event.target.value);
        };
    }
    
    
    
    ////// Zoom control //////

    function measureZoom() {
        var sx = api.elements.radWndWrapper.clientWidth / initialWndWidth;
        var sy = api.elements.radWndWrapper.clientHeight / initialWndHeight;
        return Math.min(sx, sy);
    }
    
    
    /**
     * Skaliert die Folie entsprechend des vom User gewaehlten Faktors.
     * @param {number} factor, positiver Groessenfaktor, 1.0 = 100%
     */
    function onZoomSelected(factor) {
        assert(factor && factor > 0, "setZoom: Falscher Paramter '" + factor + "', erwarte (factor > 0)");
        if (api.verbose) console.log("Skaliere auf " + factor);
        var newWidth = initialWndWidth * factor,
            newHeight = initialWndHeight * factor;
        api.elements.radWnd.SetSize(newWidth, newHeight);
        api.elements.radWnd.Center();
        saveUserPref(factor);
    }
    
    
    /**
     * Passt den Zoomfaktor im Menue der neuen Groesse des RadWindow an.
     */
    function onRadWindowResize() {
        var scale = Math.round(measureZoom() * 10) / 10;
        if (api.verbose) console.log('onWindowResize: scale=' + scale);
        var i = getFloatInArray(scale, scaleFactors, 0.1);
        if (i) zoomSelect.value = scaleFactors[i];
        saveUserPref(scale);
    }

    function loadUserPref() {
        var savedScale = localStorage.getItem(zoomPreferenceKey);
        if (savedScale) {
            onZoomSelected(savedScale);
            var i = getFloatInArray(savedScale, scaleFactors, 0.1);
            if (i) zoomSelect.value = scaleFactors[i];
        }
    }
    
    function saveUserPref(n) {
        localStorage.setItem(zoomPreferenceKey, ''+n);
    }
    
} // end zoom()


function canvasToPdf(api) {
    var FOOTER = "spm GmbH | Friedrichstr. 13 | 19055 Schwerin | Telefon: 0385 / 34 41 932 | http://newspm.de";
    var DISCLAIMER = "Dieses Dokument ist ausschließlich für den persönlichen Gebrauch bestimmt. Eine Vervielfältigung ist ohne die ausdrückliche Zustimmung der spm GmbH nicht gestattet.";
    var watermark;
    var watermarkSrc = '/pdf_printer/image/spm_wasserzeichen.png';
    var jsPdfSrc =  '/pdf_printer/js/jspdf.min.js';
    var buttonSavePdfId = 'btn-save-pdf';
    var renderCanvas;
    if (api.verbose) console.log('canvasToPdf start...');

    function sanitizeFilename(filename) {
       var badTimes = /[\$\&\^\!\?'"\\/\;\:\,<>\%\(\)\[\]\+\#\* -]+/g;
       return filename.replace(badTimes, '_'); 
    }

    api.onReady(ready);
    function ready(api, evt) {
        async(null, loadWatermark, insertScriptElement, addButton);
    }

    function insertScriptElement(callback) {
        elem = document.createElement('script');
        elem.setAttribute('src', jsPdfSrc);
        document.head.appendChild(elem);
        if (api.verbose) console.log('loading jspdf');
        elem.addEventListener('load', callback);
    }

    function loadWatermark(callback) {
        if (api.verbose) console.log('loading watermark');
        watermark = new Image();
        watermark.src = watermarkSrc;
        watermark.addEventListener('load', callback); 
    }

    function addButton(callback) {
        console.log('adding save image button');
        api.removeControlElement('#' + buttonSavePdfId);
        buttonSavePdf = document.createElement('div');
        buttonSavePdf.id = buttonSavePdfId;
        buttonSavePdf.innerHTML = '<div class="label">Bild speichern</div>';
        buttonSavePdf.className = 'controlbar-button';
        api.addControlElement(buttonSavePdf);
        buttonSavePdf.addEventListener('click', save);
        callback();
    }

    function save() {
        var title = api.getStoryTitle();
        var filename = sanitizeFilename(title) + '.pdf';
        if (!renderCanvas) createRenderCanvas();
        var pdf = renderPdf(title);
        pdf.save(filename);
    }

    function createRenderCanvas() {
        console.log('creating render canvas...');
        renderCanvas = assertExists(document.createElement('canvas'));
        renderCanvas.width = api.elements.canvas.width;
        renderCanvas.height = api.elements.canvas.height + 300;
    }

    function renderPdf(title) {
        var ctx = assertExists(renderCanvas.getContext('2d'));
        var horizCenter = renderCanvas.width / 2;
        var canvas = api.elements.canvas;
        var aspectRatio = renderCanvas.width / renderCanvas.height;

        // bei der Konvertierung zu jpeg werden alle transparenten Pixel
        // in schwarz konvertiert, daher kopiere ich die Folie auf einen zweiten
        // Canvas, den ich zuvor weiss einfaerbe.
        ctx.fillStyle = "white";
        ctx.fillRect(0, 0, renderCanvas.width, renderCanvas.height);
        ctx.drawImage(canvas, 0, 30);
        ctx.drawImage(watermark, 0, 30);

        ctx.fillStyle = 'black';
        ctx.font = '24px Sans-Serif';
        ctx.textAlign = 'left';
        ctx.fillText(title, 0, 24, renderCanvas.width);
        ctx.font = '18px Sans-Serif';
        ctx.textAlign = 'center';
        ctx.fillText(FOOTER, horizCenter, canvas.height + 46, renderCanvas.width - 20);
        ctx.font = '12px Sans-Serif';
        ctx.fillText(DISCLAIMER, horizCenter, canvas.height + 64, renderCanvas.width - 20);

        // A4: 210mm x 297mm, @300dpi: 2480px x 3508px
        var data = renderCanvas.toDataURL('image/jpeg');
        var pdf = new jsPDF('landscape', 'mm', 'a4');
        var imgHeight = 240;
        var imgWidth = imgHeight * aspectRatio;
        var horizMargin = (297-imgWidth) / 2;
        var vertMargin = 20;
        pdf.addImage(data, 'JPEG', horizMargin, vertMargin, imgWidth, imgHeight);
        if (api.verbose) console.log('pdf rendered.');
        return pdf;
    }

}


// Utils

/**
 * gibt true zurueck falls das touch api verfuegbar ist.
 * Touch api ist leider nicht 100% zuverlaessig.
 * @returns {boolean}
 */
function isTouchSupported() {
    var msTouchEnabled = window.navigator.msMaxTouchPoints;
    var generalTouchEnabled = "ontouchstart" in document.createElement("div");
    return msTouchEnabled || generalTouchEnabled;
}
        
/**
 * gibt true zurueck, falls der user agent auf ein Mobilgeraet schliessen laesst.
 * nur bedingt zuverlaessig, da nicht standartisiert.
 * @returns {boolean}
 */
function isMobileUserAgent() {
    var agent = navigator.userAgent || navigator.vendor || window.opera;
    return /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od|ad)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(agent) || 
           /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(agent.substr(0, 4));
}

/** 
 * Rundet n auf m.
 */
function roundTo(n, m) {
    var rem = n % m;
    return rem < (m/2) ? n - rem : n - rem + m;
}

/**
 * Sucht eine Zahl im gegebenen Array, die von der gegebenen Zahl f 
 * um nicht mehr als epsilon abweicht.
 * @param {number} f, die Zahl nach der gesucht werden soll.
 * @param {number[]} arr, das Array das durchsucht werden soll.
 * @param {number} epsilon, die maximale Abweichung. Wenn nicht gegeben, wird Number.EPSILON verwendet.
 * @returns {number} der Index der gefundenen Zahl oder undefined, wenn keine gefunden wurde.
 */
function getFloatInArray(f, arr, epsilon) {
    epsilon = epsilon || Number.EPSILON;
    for (var i = 0, len = arr.length; i < len; i++)
        if ((Math.abs(f - arr[i])) <= epsilon) return i;
}

/** 
 * gibt das document element des gegebenes iframes zurueck. 
 * @param elem {HTMLElement} - der iframe, dessen document zurueck gegeben werden soll
 * @returns {HTMLDocument}
 */ 
function getFrameDocument(elem) {
    var ans = elem.contentWindow.contentDocument || elem.contentWindow.document;
    assert (ans, 'Konnte frame document nicht finden!');
    return ans;
}


function addStyleSheet(doc, rules) {
    var css = doc.createElement('style');
    css.type = 'text/css';
    if (css.styleSheet) css.styleSheet.cssText = rules;
    else css.appendChild(doc.createTextNode(rules));
    doc.getElementsByTagName("head")[0].appendChild(css);
    return css;
}

/** 
 * Gibt true zurueck, falls <elem> das Tag <tagname> hat und alle in <classes> definierte Klassen.
 * @param elem {HTMLElement}
 * @param tagname {string}
 * @param classes {string[]}Var i =
 * @param id {string}
 */
function doesElemMatch(elem, tagname, classes, id) {
    if (tagname && elem.tagName !== tagname.toUpperCase()) return false;
    if (id && elem.id !== id) return false;
    if (!classes) return true;
    for (var j = 0, len = classes.length; j < len; j++) {
        if (!elem.classList.contains(classes[j])) return false;
    }
    return true;
}

/** 
 * Sucht ein Element in <elems>, das das Tag <tagname> hat und alle in <classes> definierten Klassen.
 * Gibt das gefundene Element zurueck, oder null, falls keines gefunden wurde.
 * @param elem {HTMLElement}
 * @param tagname {string}
 * @param classes {string[]}
 */
function findElement(elems, tagname, classes, id) {
    var elem;
    for (var i = 0, len = elems.length; i < len; i++) {
        elem = elems[i];
        if (doesElemMatch(elem, tagname, classes, id)) return elem;
    }
    return null;
}


/** Gibt das oberste DOM Fenster zurueck.
 * @returns {Window}, das oberste Fenster 
*/
function getRootWindow() {
    var wnd, root;
    do {
        wnd = root || window;
        root = wnd.parent;
    } while (root !== wnd);
    return root;
}
// utils end


/*
 * async - fuehrt mehrere voneinander abhaengige funktionen asynchron aus.
 * @param initial {any} Der Wert, der der ersten Funktionbb uebergeben werden soll.
 * @param tasks {function...} ein oder mehr Argumente. Jede Funktion muss ein callback
 *                            und das Ergebnis des vorherigen Tasks entgegen nehmen.
 *                            Liegt ein Ergebnis vor, muss die callback-funktion damit
 *                            aufrufen werden. 
 *                            Zum Abbruch der Kette muss ein Fehler geworfen werden.
 */
function async(initial, tasks) {
  if (arguments.length === 0) throw new Error('argument required');
  var chain = Array.from(arguments).slice(1);
  var head = -1;
  var top = chain.length - 1;

  callback(initial);

  function callback(result) {
    head++;
    if (head > top) return;
    var task = chain[head];
    task(callback, result);
  }
}

function findInArray(arr, predicate) {
    for (var i = 0; i < arr.length; i++)
        if (predicate(arr[i])) return arr[i];
}


/**
 * Erzeugt einen Fehler, wenn cond false ist.
 * @param {boolean} cond, Die zu pruefende Bedingung.
 * @param {string} msg, Die Meldung, die im Fall eines Fehlers ausgegeben werden soll.
 */
function assert(cond, msg) {
    if (!cond) throw new Error(msg || 'Assertion failed.');
}

function assertExists(obj, name) {
    if (obj !== null && obj !== undefined) return obj;
    throw new Error(name + ' ist nicht definiert/null.');
}


