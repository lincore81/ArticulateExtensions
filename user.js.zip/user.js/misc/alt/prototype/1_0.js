(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes
lib.webFontTxtFilters = {}; 

// library properties:
lib.properties = {
	width: 750,
	height: 550,
	fps: 20,
	color: "#FFFFFF",
	webfonts: {},
	manifest: [
		{src:"images/header.jpg", id:"header"}
	]
};



lib.webfontAvailable = function(family) { 
	lib.properties.webfonts[family] = true;
	var txtFilters = lib.webFontTxtFilters && lib.webFontTxtFilters[family] || [];
	for(var f = 0; f < txtFilters.length; ++f) {
		txtFilters[f].updateCache();
	}
};
// symbols:



(lib.header = function() {
	this.initialize(img.header);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,750,82);


(lib.zündquelle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgcAnIAAhNIA4AAIAAANIgoAAIAAASIAlAAIAAALIglAAIAAAVIAqAAIAAAOg");
	this.shape.setTransform(75.4,22);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgaAmIAAhLIAQAAIAAA+IAlAAIAAANg");
	this.shape_1.setTransform(68.5,22.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgaAmIAAhLIAQAAIAAA+IAlAAIAAANg");
	this.shape_2.setTransform(61.8,22.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgcAnIAAhNIA4AAIAAANIgoAAIAAASIAlAAIAAALIglAAIAAAVIAqAAIAAAOg");
	this.shape_3.setTransform(54.7,22);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgPAlQgFgDgEgEQgDgEgBgFQgCgGAAgNIAAgpIAQAAIAAApIABANQABAFAEADQADADAFAAQAHAAADgDQAEgDAAgEIABgNIAAgqIAQAAIAAAoIgBAUQgCAFgDAEQgEAEgFADQgGACgKABQgJgBgGgCg");
	this.shape_4.setTransform(46.9,22.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAaApIgLgIQgHAEgIAAQgSAAgKgLQgKgKAAgSQAAgTAKgLQALgLARAAQAPAAALALQAKALAAATQAAAJgDAHQgCAGgEAFQAFAFAHACIgGALIgHgCgAgQgWQgGAHAAANQAAAMAGAHQAGAGAJAAIAFAAIgIgGIAEgJQAHADAGAFQADgDACgFQABgGABgEQAAgNgHgHQgFgHgIAAQgKAAgGAHg");
	this.shape_5.setTransform(38.9,22.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AggAnIAAhNIAeAAQAHAAAFACQAHACAGAFQAFAFACAIQADAHAAAJQAAAKgDAHQgDAIgGAGQgDAEgIACQgFACgGAAgAgQAZIAMAAIAIAAQADgBADgDQADgCACgFQABgFAAgJQAAgIgBgFQgCgEgDgDQgDgDgFgBIgKgBIgIAAg");
	this.shape_6.setTransform(30.6,22);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AAPAnIgegyIAAAyIgPAAIAAhNIAQAAIAeAzIAAgzIAPAAIAABNg");
	this.shape_7.setTransform(22.5,22);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgPAuQgFgDgEgEQgDgEgBgFQgCgHAAgNIAAgoIAQAAIAAApIABANQABAFAEADQADADAFAAQAHAAADgDQAEgDAAgEIABgNIAAgqIAQAAIAAAnIgBAUQgCAGgDAEQgEAEgFADQgGACgKAAQgJAAgGgCgAAFgjIAAgMIANAAIAAAMgAgQgjIAAgMIANAAIAAAMg");
	this.shape_8.setTransform(14.6,21.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgeAnIAAgPIAngxIgjAAIAAgNIA4AAIAAAMIgpAzIArAAIAAAOg");
	this.shape_9.setTransform(7.3,22);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Ebene 1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgMAzQAPgagBgZQAAgJgBgJIgEgQIgJgQIAHAAQAJAOAFANQADAMAAALQABAOgGANQgFAOgHAKg");
	this.shape_10.setTransform(242.9,69.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_11.setTransform(237.9,69.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AANAnIAAgkQAAgGgDgDQgDgDgGAAQgCAAgEACQgEACgCAEQgBACAAAHIAAAfIgKAAIAAhNIAKAAIAAAcQAHgIAIAAQAGAAAFADQAFACACAFQABAEAAAHIAAAkg");
	this.shape_12.setTransform(231.8,68.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgQAWQgHgIAAgOQAAgIADgHQADgGAGgEQAGgEAGABQAJAAAGAEQAGAFABAJIgJABQgBgGgEgDQgDgCgFAAQgFgBgFAGQgFAFAAAKQAAALAFAFQAEAGAFAAQAGAAAEgEQAEgEABgHIAJABQgBAKgHAGQgGAGgKgBQgJAAgHgHg");
	this.shape_13.setTransform(226.2,69.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgUAjQgFgFAAgHQAAgEACgDIAFgGIAHgDIAJgCIAPgDIAAgCQAAgEgDgDQgDgDgHAAQgGAAgDACQgDADgCAFIgJgBQABgGADgDQADgEAGgCQAFgCAGAAQAHAAAEACQAFABACADIADAHIABAGIAAANIAAARIADAHIgKAAIgCgHQgGAFgFACQgDACgFAAQgKAAgFgFgAgBANIgIACIgEADIgBAFQAAAEACACQADADAGAAQAEAAAEgCQAEgDACgEQACgDAAgHIAAgDQgFACgJABgAAEgcIAAgLIALAAIAAALgAgOgcIAAgLIALAAIAAALg");
	this.shape_14.setTransform(220.2,68.4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_15.setTransform(215.9,68.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgDAGABIAJAAIgBAJIgGAAQgEgBgCACQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_16.setTransform(213.5,68.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgFAAQgDAAgBACQgCACgBAEQgBAFAAAFIAAAdg");
	this.shape_17.setTransform(210.3,69.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_18.setTransform(205,69.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgOAfIAAAHIgJAAIAAhMIAKAAIAAAcQAGgJAHABQAGgBAEADQAFACADAEQADADACAGQABAEAAAFQAAAPgHAJQgHAHgKAAQgIABgGgJgAgKgFQgEAFAAAJQAAAKADAFQAEAIAHAAQAFAAAFgGQAFgFAAgMQAAgJgFgFQgEgGgGABQgFgBgFAGg");
	this.shape_19.setTransform(199,68.4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgSAjQgJgGgFgJQgEgJAAgLQAAgRALgLQAKgLAPAAQALAAAIAFQAJAFAFAJQAEAKAAAKQAAALgEAKQgGAJgIAFQgJAFgKAAQgKAAgIgFgAgRgXQgJAIABAQQAAAOAHAIQAIAIAKAAQALAAAIgIQAHgIABgPQgBgIgDgHQgDgIgHgDQgGgEgHAAQgKAAgHAHg");
	this.shape_20.setTransform(191.6,68.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_21.setTransform(181.2,69.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgCAkQgFgDgDgGIAJgEQABAFACACQADACADAAQADAAAEgDQACgCAAgEQAAgDgBgCIgHgFQgJgGAAgDQgBgDAAgCIAAgEIABgHIAFgHIAAgEQAAgDgDgDQgCgCgEAAQgGAAgDADQgDAEgBAMIAAAzIgJAAIAAg0QgBgKADgFQACgFAGgDQAGgDAGAAQAIAAAFAEQAFAFABAGIgBAGIgEAHIgDAGIAAADIABACQABABAFAEQAIAEACADQADAEAAAGQAAAHgFAGQgGAFgIAAQgHAAgDgEg");
	this.shape_22.setTransform(175.1,68.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_23.setTransform(170.3,68.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_24.setTransform(166,69.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AANAnIAAgkQAAgGgDgDQgDgDgGAAQgCAAgEACQgEACgCAEQgBACAAAHIAAAfIgKAAIAAhNIAKAAIAAAcQAGgIAJAAQAGAAAFADQAEACADAFQABAEAAAHIAAAkg");
	this.shape_25.setTransform(159.9,68.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgFAJQADgCACgCQAAgDAAgDIgEAAIAAgLIAJAAIAAALQAAAEgCAEQgCAEgDACg");
	this.shape_26.setTransform(152.3,72.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAFAAAFACQAEACACADIADAHIABAKIAAAhg");
	this.shape_27.setTransform(147.7,69.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_28.setTransform(141.6,69.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AALAnIgRgdIgHAGIAAAXIgJAAIAAhNIAJAAIAAArIAWgVIAMAAIgVATIAXAkg");
	this.shape_29.setTransform(136.2,68.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIABAKIAAAhg");
	this.shape_30.setTransform(130,69.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgMAbQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCg");
	this.shape_31.setTransform(123.9,69.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgDAGABIAJAAIgBAJIgGAAQgEgBgCACQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_32.setTransform(119.6,68.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgLAjQgGgDgDgHQgDgGAAgKQAAgIACgFQAEgHAFgEQAGgDAGAAQAEgBAEADQAEACACAEIAAgcIAKAAIAABMIgIAAIAAgHQgGAJgKgBQgGAAgFgEgAgJgFQgEAFgBAJQAAAMAGAFQAEAGAEAAQAGAAAFgGQAFgFAAgLQAAgKgFgFQgFgGgGABQgFgBgEAGg");
	this.shape_33.setTransform(114.6,68.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIABAKIAAAhg");
	this.shape_34.setTransform(108.7,69.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgMAmQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCgAAEgcIAAgLIAKAAIAAALgAgOgcIAAgLIAKAAIAAALg");
	this.shape_35.setTransform(102.5,68.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgeAnIAAgKIAngwIAIgKIgqAAIAAgJIA2AAIAAAJIgqA1IgFAFIAxAAIAAAKg");
	this.shape_36.setTransform(96.1,68.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_37.setTransform(88.3,71.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgcAnIAAhNIAcAAQAIAAAGACQAFADADAFQADAFAAAFQAAAFgCAFQgDAEgGADQAIABADAEQAEAFAAAHQAAAFgCAFQgCAFgEADQgDACgFABQgGACgHAAgAgSAdIASAAIAHAAIAGgCIAEgEQABgDAAgEQAAgEgCgEQgCgDgEgBQgEgCgGAAIgSAAgAgSgFIARAAIAIgBQAEgBACgDQACgCAAgFQAAgEgCgCQgCgDgDgCIgKgBIgQAAg");
	this.shape_38.setTransform(83.2,68.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_39.setTransform(74.9,71.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgYAcIAAgIIAjgnIgLAAIgVAAIAAgIIAsAAIAAAHIgdAiIgGAGIAMgBIAZAAIAAAJg");
	this.shape_40.setTransform(70.5,69.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AAFAzQgFgKgGgOQgFgNgBgOQABgLAEgMQAEgNAIgOIAIAAIgJAQIgEAQQgBAJgBAJQABAZAOAag");
	this.shape_41.setTransform(66.1,69.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_42.setTransform(59.6,71.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AAAAlQgDgCgCgDQgBgDAAgIIAAgfIgHAAIAAgIIAHAAIAAgNIAIgHIAAAUIAKAAIAAAIIgKAAIAAAgIAAAFIACACIAEAAIAEAAIABAJIgHABQgGAAAAgCg");
	this.shape_43.setTransform(56.6,68.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgPAZQgGgFgBgJIAJgCQABAGAEADQADADAFABQAHgBADgDQADgCAAgDQAAgEgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgDACgEIAFgGIAGgCQAEgCAEABQAFAAAFABQAFADADADQACADABAGIgKABQAAgEgDgDQgDgCgFAAQgGAAgDACQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACAEAAAEQAAAFgDAEQgDAEgFADQgFACgHAAQgJAAgGgEg");
	this.shape_44.setTransform(52.2,69.4);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_45.setTransform(48.3,68.3);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AAAAlQgDgCgBgDQgBgDAAgIIAAgfIgHAAIAAgIIAHAAIAAgNIAHgHIAAAUIAKAAIAAAIIgKAAIAAAgIABAFIACACIACAAIAFAAIACAJIgIABQgGAAAAgCg");
	this.shape_46.setTransform(42.6,68.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_47.setTransform(37.9,69.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_48.setTransform(31.9,69.3);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgQAkQgGgFAAgJIAKABQAAAFADACQAEACAFAAQAFAAAEgCQAEgDABgFIABgMQgHAHgIAAQgLAAgGgIQgHgJAAgKQAAgIADgHQADgHAGgDQAFgEAHAAQAJAAAHAIIAAgHIAJAAIAAAwQAAANgDAFQgDAGgGADQgGADgHAAQgJAAgHgEgAgJgaQgFAFAAALQAAAKAFAEQAEAFAFAAQAHAAAEgFQAFgEAAgKQAAgKgFgGQgFgFgGAAQgFAAgEAFg");
	this.shape_49.setTransform(25.6,70.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_50.setTransform(21.5,68.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_51.setTransform(17.2,69.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_52.setTransform(11.1,69.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgQAkQgGgFAAgJIAKABQAAAFADACQAEACAFAAQAFAAAEgCQAEgDABgFIABgMQgHAHgIAAQgLAAgGgIQgHgJAAgKQAAgIADgHQADgHAGgDQAFgEAHAAQAJAAAHAIIAAgHIAJAAIAAAwQAAANgDAFQgDAGgGADQgGADgHAAQgJAAgHgEgAgJgaQgFAFAAALQAAAKAFAEQAEAFAFAAQAHAAAEgFQAFgEAAgKQAAgKgFgGQgFgFgGAAQgFAAgEAFg");
	this.shape_53.setTransform(4.9,70.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgPAZQgGgFgBgJIAJgCQABAGAEADQADADAFAAQAHAAADgDQADgCAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgEACgDIAFgGIAGgCQAEgBAEAAQAFAAAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgCgFAAQgGAAgDACQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAEgFADQgFACgHAAQgJAAgGgEg");
	this.shape_54.setTransform(230.9,53.1);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AAcAdIAAgiIgBgJQgBgCgCgCQgDgBgDAAQgFAAgEAEQgEAEAAAJIAAAfIgJAAIAAgjQAAgHgCgDQgCgDgGAAQgEAAgDACQgDACgCAEQgCAEABAHIAAAdIgKAAIAAg3IAJAAIAAAIQACgEAEgDQAFgDAGAAQAGAAAEADQACADACAEQAHgKAKAAQAJAAAFAFQAEAFAAAKIAAAlg");
	this.shape_55.setTransform(223.7,53);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_56.setTransform(216,53.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AAAAlQgDgCgCgDQgBgDAAgIIAAgfIgHAAIAAgIIAHAAIAAgNIAIgHIAAAUIAKAAIAAAIIgKAAIAAAgIAAAEIADADIADAAIAEAAIACAJIgIABQgFAAgBgCg");
	this.shape_57.setTransform(211.5,52.2);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgPAZQgGgFgBgJIAJgCQABAGAEADQADADAFAAQAHAAADgDQADgCAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgEACgDIAFgGIAGgCQAEgBAEAAQAFAAAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgCgFAAQgGAAgDACQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAEgFADQgFACgHAAQgJAAgGgEg");
	this.shape_58.setTransform(207.1,53.1);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AgTAmIgCgJIAGABQADABACgCIADgDIADgHIABgCIgWg4IAKAAIANAhIACALIAEgLIAMghIAKAAIgWA5IgEAMQgCAFgEACQgDACgFAAIgFgBg");
	this.shape_59.setTransform(201.7,54.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AgOAlQgHgDgEgGQgFgHAAgIIAKAAQABAGACADQADAEAFACQAGADAEAAQAGAAAFgCQAEgCADgDQACgDAAgEQAAgDgCgDQgCgDgFgCIgMgEIgQgCQgFgDgDgFQgDgEAAgGQAAgGAEgFQADgFAGgDQAHgCAHAAQAIAAAGADQAHACAEAGQADAFABAHIgKABQgBgIgFgDQgFgEgIAAQgIAAgEADQgFAEAAAFQAAAEADADQADACALADIARAFQAHABAEAFQADAFAAAHQAAAGgEAFQgDAGgHADQgHADgIAAQgJAAgHgDg");
	this.shape_60.setTransform(195.2,52);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAFAAAFACQAEACACADIADAHIABAKIAAAhg");
	this.shape_61.setTransform(185.5,53);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_62.setTransform(179.4,53.1);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgFAAQgCAAgCACQgBACgCAEQgBAFAAAFIAAAdg");
	this.shape_63.setTransform(175,53);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgUAZQgFgFAAgHQAAgEACgDIAFgGIAHgBIAJgCIAPgDIAAgCQAAgGgDgDQgDgDgHAAQgGAAgDACQgDADgCAGIgJgCQABgGADgDQADgFAGgBQAFgCAGAAQAHAAAEACQAFABACACIADAHIABAJIAAALIAAARIADAHIgKAAIgCgHQgGAEgFACQgDACgFAAQgKAAgFgEgAgBADIgIACIgEADIgBAEQAAAEACADQADACAGAAQAEAAAEgCQAEgCACgFQACgDAAgGIAAgDQgFACgJABg");
	this.shape_64.setTransform(169.6,53.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgOAfIAAAHIgJAAIAAhNIAKAAIAAAdQAGgIAHAAQAGAAAEACQAFACADAEQADAEACAFQABAEAAAGQAAAPgHAHQgHAIgKAAQgIABgGgJgAgKgFQgEAFAAAJQAAALADAEQAEAIAHgBQAFABAFgGQAFgFAAgMQAAgJgFgFQgEgGgGABQgFgBgFAGg");
	this.shape_65.setTransform(163.7,52.1);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIABAKIAAAhg");
	this.shape_66.setTransform(157.5,53);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAGAAADACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_67.setTransform(151.4,53);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#000000").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_68.setTransform(145.2,53.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#000000").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgEgDgDAAQgDAAgCACQgBACgCAEQgBAFAAAFIAAAdg");
	this.shape_69.setTransform(140.8,53);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#000000").s().p("AgOAfIAAAHIgJAAIAAhNIAKAAIAAAdQAGgIAHAAQAGAAAEACQAFACADAEQADAEACAFQABAEAAAGQAAAPgHAHQgHAIgKAAQgIABgGgJgAgKgFQgEAFAAAJQAAALADAEQAEAIAHgBQAFABAFgGQAFgFAAgMQAAgJgFgFQgEgGgGABQgFgBgFAGg");
	this.shape_70.setTransform(135.6,52.1);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#000000").s().p("AgPAZQgGgFgBgJIAJgCQABAGAEADQADADAFAAQAHAAADgDQADgCAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgEACgDIAFgGIAGgCQAEgBAEAAQAFAAAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgCgFAAQgGAAgDACQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAEgFADQgFACgHAAQgJAAgGgEg");
	this.shape_71.setTransform(126.6,53.1);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#000000").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_72.setTransform(120.8,53.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#000000").s().p("AgLAkQgGgEgDgHQgDgGAAgKQAAgIACgFQAEgHAFgEQAGgDAGAAQAEAAAEACQAEACACAEIAAgdIAKAAIAABNIgIAAIAAgHQgGAJgKgBQgGAAgFgDgAgJgFQgEAFgBAJQAAAMAGAFQAEAGAEgBQAGABAFgGQAFgFAAgLQAAgKgFgFQgFgGgGABQgFgBgEAGg");
	this.shape_73.setTransform(114.6,52.1);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#000000").s().p("AgQAkQgGgFAAgJIAKABQAAAFADACQAEACAFAAQAFAAAEgCQAEgDABgFIABgMQgHAHgIAAQgLAAgGgIQgHgJAAgKQAAgIADgHQADgHAGgDQAFgEAHAAQAJAAAHAIIAAgHIAJAAIAAAwQAAANgDAFQgDAGgGADQgGADgHAAQgJAAgHgEgAgJgaQgFAFAAALQAAAKAFAEQAEAFAFAAQAHAAAEgFQAFgEAAgKQAAgKgFgGQgFgFgGAAQgFAAgEAFg");
	this.shape_74.setTransform(105.4,54.2);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#000000").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAGAAADACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_75.setTransform(99.5,53);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#000000").s().p("AgMAbQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCg");
	this.shape_76.setTransform(93.4,53.2);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#000000").s().p("AgLAkQgGgEgDgHQgDgGAAgKQAAgIACgFQAEgHAFgEQAGgDAGAAQAEAAAEACQAEACACAEIAAgdIAKAAIAABNIgIAAIAAgHQgGAJgKgBQgGAAgFgDgAgJgFQgEAFgBAJQAAAMAGAFQAEAGAEgBQAGABAFgGQAFgFAAgLQAAgKgFgFQgFgGgGABQgFgBgEAGg");
	this.shape_77.setTransform(87.1,52.1);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#000000").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIABAKIAAAhg");
	this.shape_78.setTransform(81.2,53);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#000000").s().p("AgMAmQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCgAAEgcIAAgLIAKAAIAAALgAgOgcIAAgLIAKAAIAAALg");
	this.shape_79.setTransform(75.1,52.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#000000").s().p("AgeAnIAAgKIAngwIAIgKIgqAAIAAgJIA2AAIAAAJIgqA1IgFAFIAxAAIAAAKg");
	this.shape_80.setTransform(68.7,52);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#000000").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_81.setTransform(59.2,53.1);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#000000").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_82.setTransform(55,52);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#000000").s().p("AgLAkQgGgEgDgHQgDgGAAgKQAAgIACgFQADgHAGgEQAGgDAGAAQAEAAAEACQAEACACAEIAAgdIAKAAIAABNIgJAAIAAgHQgFAJgKgBQgGAAgFgDgAgJgFQgEAFgBAJQAAAMAGAFQAEAGAEgBQAHABAEgGQAFgFgBgLQABgKgFgFQgEgGgHABQgFgBgEAGg");
	this.shape_83.setTransform(50.6,52.1);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#000000").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgEgDgEAAQgDAAgBACQgBACgCAEQgBAFAAAFIAAAdg");
	this.shape_84.setTransform(43.3,53);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#000000").s().p("AgMAmQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCgAAEgcIAAgLIAKAAIAAALgAgOgcIAAgLIAKAAIAAALg");
	this.shape_85.setTransform(37.9,52.1);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#000000").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgDAGABIAJABIgBAIIgGAAQgEgBgCACQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_86.setTransform(33.6,52);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#000000").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_87.setTransform(25.7,53.1);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#000000").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_88.setTransform(21.5,52);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#000000").s().p("AgLAkQgGgEgDgHQgDgGAAgKQAAgIACgFQADgHAGgEQAGgDAGAAQAEAAAEACQAEACACAEIAAgdIAKAAIAABNIgJAAIAAgHQgFAJgKgBQgFAAgGgDgAgJgFQgFAFABAJQAAAMAEAFQAFAGAEgBQAGABAFgGQAFgFgBgLQABgKgFgFQgFgGgGABQgEgBgFAGg");
	this.shape_89.setTransform(17.1,52.1);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#000000").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_90.setTransform(9.7,55.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#000000").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_91.setTransform(6.6,55.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#000000").s().p("AgEAFIAAgJIAJAAIAAAJg");
	this.shape_92.setTransform(3.6,55.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,14,253,62.6);


(lib.zuendquelle = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFF00","#FFCC00"],[0,1],7,18.8,-3,-18.7).s().p("AgNBhIjbBJICWhxIhJgSIA4gbIithkIC5AhIgWhNIBgApIguiqIBhCJIAig5IAAA9ICAh8Ig4CpIBkgWIhmBWIBoArIhSARIBtB1IihhIIAABQIg9g6IhACSg");
	this.shape.setTransform(55,48.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FF0000","#A30A0A"],[0,1],10.7,29,-4.8,-28.9).s().p("AgWCWIlSBwIDpiuIhxgbIBWgrIkKicIEdA0Igjh2ICVA/IhIkGICWDTIA3hZIAABeIDEi/IhWEFICagiIicCFICfBEIh9AaICnCzIj6huIAAB9IhbhbIhmDhgAAaEHIBDiSIA8A6IAAhQIChBIIhsh1IBSgRIhogrIBlhWIhjAWIA3ipIh/B8IAAg9IgjA5IhhiJIAsCqIhdgpIAVBNIi4ghICtBkIg4AbIBJASIiWBxIDYhJg");
	this.shape_1.setTransform(50.8,48.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(8.7,8.3,84.3,81);


(lib.sprechblase = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgHAIIAAgQIAPAAIAAAQg");
	this.shape.setTransform(-155.3,100.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_1.setTransform(-160.7,97.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgWAqQgHgGAAgJIAAgCIAUACQABAEACABQACACAEAAQAHAAADgCIAEgFIABgIIAAgKQgIALgLAAQgNAAgIgLQgGgJAAgMQAAgRAIgJQAIgJAMAAQALAAAIALIAAgJIAQAAIAAA6QAAAMgCAGQgCAGgDADQgEAEgGACQgGACgJAAQgPAAgHgGgAgJgcQgEAFAAAKQAAALAEADQAEAFAFAAQAGAAAEgFQAFgDAAgKQAAgLgEgFQgFgFgGAAQgFAAgEAFg");
	this.shape_2.setTransform(-168.4,99);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AANAiIAAgiQAAgJgCgEQgBgDgCgBQgDgCgDAAQgDAAgEACQgDADgCAEQgBAEAAAJIAAAfIgSAAIAAhCIARAAIAAAKQAIgLAMAAQAGAAAFACQAEADADACQACAEABAEIABAMIAAAog");
	this.shape_3.setTransform(-176.1,97.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgYAqQgGgGAAgIQAAgGADgEQACgFAFgCQAFgDAJgCIAQgEIAAgCQAAgDgDgCQgCgCgFAAQgFAAgDACQgCACgCADIgQgCQACgJAHgFQAHgFAMAAQALAAAGADQAGACACAFQACAEAAAKIAAAVIABANIADAJIgRAAIgCgGIgBgCQgEAFgGADQgDABgGAAQgKAAgGgFgAAAARQgHABgCACQgDACAAAEQAAAEADACQACADAFAAQACAAAFgDQADgCABgEIABgJIAAgEgAAGgfIAAgQIAPAAIAAAQgAgUgfIAAgQIAQAAIAAAQg");
	this.shape_4.setTransform(-183.7,96.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgWAqQgHgGAAgJIAAgCIAUACQABAEACABQACACAEAAQAHAAADgCIAEgFQABgCAAgGIAAgKQgIALgLAAQgNAAgIgLQgGgJAAgMQAAgRAIgJQAIgJAMAAQALAAAIALIAAgJIAQAAIAAA6QAAAMgCAGQgCAGgDADQgEAEgGACQgGACgJAAQgPAAgHgGgAgJgcQgEAFAAAKQAAALAEADQAEAFAFAAQAGAAAEgFQAFgDAAgKQAAgLgEgFQgFgFgGAAQgFAAgEAFg");
	this.shape_5.setTransform(-191.4,99);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgUAiIAAhCIAQAAIAAAKQAEgHACgCQADgCAFAAQAGAAAFAEIgFAPQgFgDgDAAQgEAAgDACQgBACgBAFQgBAGAAAPIAAAVg");
	this.shape_6.setTransform(-197.2,97.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgQAfQgIgFgFgIQgFgIABgKQgBgIAFgJQAEgIAJgEQAHgFAJAAQAPAAAJAKQALAKAAAOQAAAPgLAKQgJAKgPAAQgHAAgJgEgAgLgOQgEAGAAAIQAAAKAEAFQAGAFAFAAQAGAAAFgFQAFgFAAgKQAAgIgFgGQgFgFgGAAQgFAAgGAFg");
	this.shape_7.setTransform(-204.1,97.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgGAhIgbhBIATAAIAMAgIACAMIACgGIABgGIAOggIASAAIgbBBg");
	this.shape_8.setTransform(-211.8,97.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgUAdQgHgFgDgKIASgDQABAFAEADQADADAFAAQAGAAAEgDQAAAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBIgBgEQgCgBgEgBQgTgFgHgEQgHgDgBgKQABgJAGgGQAIgGANAAQAMAAAIAFQAGAEADAJIgRADQgBgEgDgCQgDgCgFAAQgGAAgDACQAAABgBAAQAAAAAAABQgBAAAAABQAAAAAAABQAAAAAAABQAAAAABAAQAAABAAAAQABABAAAAQACACAMADQAPADAFAEQAGAEAAAIQAAAJgIAHQgHAHgPAAQgMAAgJgGg");
	this.shape_9.setTransform(-219.1,97.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgWAqQgHgGAAgJIAAgCIAUACQABAEACABQACACAEAAQAHAAADgCIAEgFIABgIIAAgKQgIALgLAAQgNAAgIgLQgGgJAAgMQAAgRAIgJQAIgJAMAAQALAAAIALIAAgJIAQAAIAAA6QAAAMgCAGQgCAGgDADQgEAEgGACQgGACgJAAQgPAAgHgGgAgJgcQgEAFAAAKQAAALAEADQAEAFAFAAQAGAAAEgFQAFgDAAgKQAAgLgEgFQgFgFgGAAQgFAAgEAFg");
	this.shape_10.setTransform(-226.6,99);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AANAiIAAgiQAAgJgCgEQgBgDgCgBQgDgCgDAAQgDAAgEACQgDADgCAEQgBAEAAAJIAAAfIgSAAIAAhCIARAAIAAAKQAIgLAMAAQAGAAAFACQAEADADACQACAEABAEIABAMIAAAog");
	this.shape_11.setTransform(-234.4,97.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgTAfQgFgDgDgGQgCgFAAgJIAAgpIASAAIAAAfQAAANABACQABADACADQADABAEABQACgBAEgCQAEgDABgDQABgEAAgNIAAgcIASAAIAABBIgRAAIAAgKQgDAGgGADQgEADgHAAQgHAAgFgDg");
	this.shape_12.setTransform(-242.3,97.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AANAiIAAgiQAAgJgCgEQgBgDgCgBQgDgCgDAAQgDAAgEACQgDADgCAEQgBAEAAAJIAAAfIgSAAIAAhCIARAAIAAAKQAIgLAMAAQAGAAAFACQAEADADACQACAEABAEIABAMIAAAog");
	this.shape_13.setTransform(-250.2,97.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AANAiIAAgiQAAgJgCgEQgBgDgCgBQgDgCgDAAQgDAAgEACQgDADgCAEQgBAEAAAJIAAAfIgSAAIAAhCIARAAIAAAKQAIgLAMAAQAGAAAFACQAEADADACQACAEABAEIABAMIAAAog");
	this.shape_14.setTransform(-258.1,97.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_15.setTransform(-265.7,97.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgUAiIAAhCIAQAAIAAAKQAEgHACgCQADgCAFAAQAGAAAFAEIgFAPQgFgDgDAAQgEAAgDACQgBACgBAFQgBAGAAAPIAAAVg");
	this.shape_16.setTransform(-271.3,97.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgFAsQgGgDgEgGIAAAKIgQAAIAAhbIASAAIAAAiQAHgKAKAAQAMAAAIAJQAJAJgBAPQAAARgIAJQgIAKgMAAQgEAAgFgDgAgKgDQgDADAAAKQAAALACAFQAFAHAGAAQAGAAAEgFQAEgFAAgLQAAgMgEgDQgEgFgGAAQgFAAgFAFg");
	this.shape_17.setTransform(-278,96.5);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgUAiIAAhCIAQAAIAAAKQAEgHACgCQADgCAFAAQAGAAAFAEIgFAPQgFgDgDAAQgEAAgDACQgBACgBAFQgBAGAAAPIAAAVg");
	this.shape_18.setTransform(-284.2,97.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_19.setTransform(-290.9,97.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgJAuIghhbIAVAAIAVBDIAXhDIAUAAIghBbg");
	this.shape_20.setTransform(-298.8,96.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_21.setTransform(-152.8,79.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgHAuIAAhbIAPAAIAABbg");
	this.shape_22.setTransform(-158.1,78);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgHAuIAAhbIAPAAIAABbg");
	this.shape_23.setTransform(-161.7,78);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgYAdQgGgGAAgIQAAgGADgEQACgFAFAAQAFgDAJgBIAQgFIAAgCQAAgFgDgCQgCgCgFAAQgFAAgDACQgCACgCAEIgQgDQACgJAHgFQAHgFAMAAQALAAAGADQAGADACAEQACAFAAALIAAATIABANIADAJIgRAAIgCgFIgBgCQgEAEgGADQgDACgGAAQgKAAgGgGgAAAAEQgHABgCACQgDACAAAEQAAAEADACQACADAFAAQACAAAFgDQADgCABgEIABgJIAAgDg");
	this.shape_24.setTransform(-167.1,79.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgUAiIAAhBIAQAAIAAAJQAEgGACgDQADgCAFAAQAGAAAFADIgFAQQgFgDgDAAQgEAAgDACQgBACgBAFQgBAGAAAPIAAAVg");
	this.shape_25.setTransform(-176.4,79.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgTAsQgFgDgDgFQgCgFAAgKIAAgoIASAAIAAAcQAAAPABADQABADACACQADACAEAAQACAAAEgCQAEgDABgEQABgDAAgPIAAgaIASAAIAABBIgRAAIAAgKQgDAFgGADQgEADgHAAQgHAAgFgDgAAFggIAAgOIAQAAIAAAOgAgUggIAAgOIAPAAIAAAOg");
	this.shape_26.setTransform(-183.3,78);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgLAvIAAg0IgKAAIAAgOIAKAAIAAgFQAAgIACgEQABgFAFgCQADgDAHAAQAIAAAHACIgCANIgIgBQgEAAgCACQgBABAAAGIAAAEIANAAIAAAOIgNAAIAAA0g");
	this.shape_27.setTransform(-189.2,77.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AANAiIAAgiQAAgJgCgDQgBgEgCgCQgDgCgDAAQgDAAgEADQgDADgCAEQgBAEAAAKIAAAeIgSAAIAAhBIARAAIAAAKQAIgMAMAAQAGAAAFACQAEADADACQACAEABAEIABAMIAAAog");
	this.shape_28.setTransform(-199.1,79.2);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_29.setTransform(-206.7,79.2);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgWAqQgHgGAAgJIAAgCIAUACQABAEACABQACACAEAAQAHAAADgCIAEgFIABgIIAAgKQgIALgLAAQgNAAgIgLQgGgJAAgMQAAgRAIgJQAIgJAMAAQALAAAIALIAAgJIAQAAIAAA6QAAAMgCAGQgCAGgDADQgEAEgGACQgGACgJAAQgPAAgHgGgAgJgcQgEAFAAAKQAAALAEADQAEAFAFAAQAGAAAEgFQAFgDAAgKQAAgLgEgFQgFgFgGAAQgFAAgEAFg");
	this.shape_30.setTransform(-214.4,80.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AANAiIAAgiQAAgJgCgDQgBgEgCgCQgDgCgDAAQgDAAgEADQgDADgCAEQgBAEAAAKIAAAeIgSAAIAAhBIARAAIAAAKQAIgMAMAAQAGAAAFACQAEADADACQACAEABAEIABAMIAAAog");
	this.shape_31.setTransform(-222.1,79.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgTAfQgFgDgDgFQgCgGAAgKIAAgoIASAAIAAAfQAAAMABAEQABADACABQADACAEAAQACAAAEgCQAEgDABgEQABgDAAgNIAAgcIASAAIAABCIgRAAIAAgKQgDAFgGADQgEADgHAAQgHAAgFgDg");
	this.shape_32.setTransform(-230,79.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgdAhIAAgOIAagbIAHgKIgGABIgYAAIAAgPIA2AAIAAAMIgaAcIgHAKIAHAAIAcAAIAAAPg");
	this.shape_33.setTransform(-237.3,79.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AgBAsQgEgBgCgDQgCgDgBgEIAAgNIAAgbIgIAAIAAgOIAIAAIAAgOIAQgKIAAAYIAMAAIAAAOIgMAAIAAAZIAAAKIACACIADABIAHgCIABAOQgGADgIAAQgEAAgCgCg");
	this.shape_34.setTransform(-242.6,78.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_35.setTransform(-248.4,79.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgUAdQgHgFgDgKIASgDQABAFADADQAEADAEAAQAIAAADgDQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBAAAAIgBgEQgCgBgEgBQgUgFgGgEQgIgDAAgKQAAgJAIgGQAGgGAOAAQAMAAAIAFQAGAEADAJIgRADQgBgEgDgCQgDgCgFAAQgGAAgDACQAAABgBAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAQADACALADQAPADAFAEQAGAEAAAIQAAAJgIAHQgHAHgQAAQgLAAgJgGg");
	this.shape_36.setTransform(-255.7,79.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AgUAdQgHgFgDgKIASgDQABAFADADQAEADAEAAQAIAAADgDQAAAAABgBQAAAAAAgBQABAAAAgBQAAgBAAAAIgBgEQgCgBgEgBQgUgFgGgEQgIgDAAgKQAAgJAIgGQAGgGAOAAQAMAAAIAFQAGAEADAJIgRADQgBgEgDgCQgDgCgFAAQgGAAgDACQAAABgBAAQAAAAgBABQAAAAAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQABABAAAAQADACALADQAPADAFAEQAGAEAAAIQAAAJgIAHQgHAHgQAAQgLAAgJgGg");
	this.shape_37.setTransform(-262.9,79.2);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgTAfQgFgDgDgFQgCgGAAgKIAAgoIASAAIAAAfQAAAMABAEQABADACABQADACAEAAQACAAAEgCQAEgDABgEQABgDAAgNIAAgcIASAAIAABCIgRAAIAAgKQgDAFgGADQgEADgHAAQgHAAgFgDg");
	this.shape_38.setTransform(-270.3,79.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("AgYAdQgGgGAAgIQAAgGADgEQACgFAFAAQAFgDAJgBIAQgFIAAgCQAAgFgDgCQgCgCgFAAQgFAAgDACQgCACgCAEIgQgDQACgJAHgFQAHgFAMAAQALAAAGADQAGADACAEQACAFAAALIAAATIABANIADAJIgRAAIgCgFIgBgCQgEAEgGADQgDACgGAAQgKAAgGgGgAAAAEQgHABgCACQgDACAAAEQAAAEADACQACADAFAAQACAAAFgDQADgCABgEIABgJIAAgDg");
	this.shape_39.setTransform(-277.9,79.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("AgUAiIAAhBIAQAAIAAAJQAEgGACgDQADgCAFAAQAGAAAFADIgFAQQgFgDgDAAQgEAAgDACQgBACgBAFQgBAGAAAPIAAAVg");
	this.shape_40.setTransform(-283.5,79.2);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("AgQAfQgIgFgFgIQgEgIAAgKQAAgIAEgJQAEgIAJgEQAHgFAJAAQAPAAAKAKQAJAKABAOQgBAPgJAKQgKAKgPAAQgIAAgIgEgAgLgOQgEAGAAAIQAAAKAEAFQAFAFAGAAQAGAAAFgFQAFgFAAgKQAAgIgFgGQgFgFgGAAQgGAAgFAFg");
	this.shape_41.setTransform(-290.4,79.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AgJAuIghhbIAVAAIAVBDIAXhDIAUAAIghBbg");
	this.shape_42.setTransform(-298.8,78);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AANAiIAAgiQAAgJgCgEQgBgCgCgCQgDgCgDAAQgDAAgEADQgDACgCAEQgBAEAAAJIAAAfIgSAAIAAhCIARAAIAAAKQAIgLAMAAQAGAAAFACQAEADADADQACADABAEIABAMIAAAog");
	this.shape_43.setTransform(-185.4,60.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_44.setTransform(-193,60.7);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AANAiIAAgiQAAgJgCgEQgBgCgCgCQgDgCgDAAQgDAAgEADQgDACgCAEQgBAEAAAJIAAAfIgSAAIAAhCIARAAIAAAKQAIgLAMAAQAGAAAFACQAEADADADQACADABAEIABAMIAAAog");
	this.shape_45.setTransform(-200.5,60.7);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("AANAuIAAgjQAAgLgBgBQgBgDgEgBQgCgCgDAAQgDAAgDACQgEACgCADQgCAEAAAIIAAAiIgRAAIAAhbIARAAIAAAiQAJgKAKAAQAGAAAGACQAFACACAEQADAEABAEIAAALIAAAog");
	this.shape_46.setTransform(-208.4,59.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AgIAuIAAhbIARAAIAABbg");
	this.shape_47.setTransform(-214.2,59.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AAMAuIAAgjQAAgLgBgBQAAgDgDgBQgDgCgDAAQgDAAgEACQgDACgCADQgCAEAAAIIAAAiIgRAAIAAhbIARAAIAAAiQAJgKAKAAQAGAAAGACQAEACADAEQACAEABAEIABALIAAAog");
	this.shape_48.setTransform(-223.5,59.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AgWAZQgIgJAAgQQAAgPAIgJQAJgKANAAQANAAAHAGQAHAFADALIgRADQgBgFgDgDQgDgDgFAAQgFAAgEAFQgEAFAAAKQAAAKAEAFQAEAFAFAAQAFAAADgDQADgDACgHIARADQgCAMgIAHQgIAGgNAAQgNAAgJgKg");
	this.shape_49.setTransform(-231,60.7);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgHAuIAAhCIAPAAIAABCgAgHgdIAAgQIAPAAIAAAQg");
	this.shape_50.setTransform(-236.5,59.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_51.setTransform(-245.5,60.7);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgWAqQgHgGAAgJIAAgCIAUACQABAEACABQACACAEAAQAHAAADgCIAEgFIABgIIAAgKQgIALgLAAQgNAAgIgLQgGgJAAgMQAAgRAIgJQAIgJAMAAQALAAAIALIAAgJIAQAAIAAA6QAAAMgCAGQgCAGgDADQgEAEgGACQgGACgJAAQgPAAgHgGgAgJgcQgEAFAAAKQAAALAEADQAEAFAFAAQAGAAAEgFQAFgDAAgKQAAgLgEgFQgFgFgGAAQgFAAgEAFg");
	this.shape_52.setTransform(-253.2,62);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgHAuIAAhCIAPAAIAABCgAgHgdIAAgQIAPAAIAAAQg");
	this.shape_53.setTransform(-258.8,59.5);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_54.setTransform(-264.2,60.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AgdAhIAAgOIAagbIAHgKIgGABIgYAAIAAgPIA2AAIAAAMIgaAcIgHAKIAHAAIAcAAIAAAPg");
	this.shape_55.setTransform(-271.1,60.7);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AgUAiIAAhCIAQAAIAAAKQAEgHACgCQADgCAFAAQAGAAAFADIgFAQQgFgDgDAAQgEAAgDACQgBACgBAGQgBAFAAAPIAAAVg");
	this.shape_56.setTransform(-279.9,60.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_57.setTransform(-286.6,60.7);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("AgHAuIAAhCIAPAAIAABCgAgHgdIAAgQIAPAAIAAAQg");
	this.shape_58.setTransform(-291.9,59.5);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AASAuIAAgpIgjAAIAAApIgTAAIAAhbIATAAIAAAkIAjAAIAAgkIATAAIAABbg");
	this.shape_59.setTransform(-298.4,59.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["rgba(255,255,255,0.4)","rgba(255,255,255,0.086)"],[0,1],197.4,-28.7,197.4,18.3).s().p("AsAEkQhpAAAAhkIAAl/QAAhkBpAAIYBAAQBpAAAABkIAAAcIAAFjQAABkhpAAg");
	this.shape_60.setTransform(-223.1,77.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_60).wait(1));

	// Ebene 1
	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#D0DB8F").s().p("AsrGaQhkAAAAhlIAAmxQAAhjBkgBIE/AAIAAi5IETC5IQFAAQBkABAABjIAAGxQAABlhkAAg");
	this.shape_61.setTransform(-223.3,67.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_61).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-314.5,26.5,182.5,82);


(lib.sauerstoffblase = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgIANIACgFIAGgGIADgDIABgDIgBgDIgDgBIgBABIgBADIgFAAQAAgEADgDQACgCACAAQAEAAADACQACADAAADIgBAEIgCACIgDADIgDADIAAACIAJAAIAAAEg");
	this.shape.setTransform(2.1,1.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgOAQQgFgGgBgKQAAgFADgEIADgGIAGgEQAEgCAEABQAJgBAFAGQAHAGgBAJQABAKgHAGQgFAGgJAAQgIAAgGgGgAgHgKQgEAEAAAGQAAAHAEADQADAFAEAAQAFAAADgFQADgDABgHQgBgGgDgEQgDgDgFAAQgEAAgDADg");
	this.shape_1.setTransform(-1.2,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.rf(["rgba(0,197,255,0.102)","rgba(2,142,202,0.2)"],[0.914,1],0,-0.1,0,0,-0.1,6.1).s().p("AgrAsQgRgRAAgbQAAgYARgSQATgSAYAAQAaAAARASQASASAAAYQAAAbgSARQgRARgaAAQgYAAgTgRg");

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-6.1,-6.1,12.3,12.3);


(lib.rauchwolke = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AAPAnIAAgjIgdAAIAAAjIgQAAIAAhNIAQAAIAAAfIAdAAIAAgfIAQAAIAABNg");
	this.shape.setTransform(138.6,46.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgWAdQgLgKAAgTQAAgSALgKQAJgLAPAAQAOAAAJAIQAGAFACAKIgPADQgCgGgEgDQgEgEgHAAQgGAAgGAHQgFAGgBANQABAOAFAGQAGAHAGAAQAGAAAFgFQAEgEACgIIAQAFQgEANgIAGQgIAGgNAAQgOAAgJgLg");
	this.shape_1.setTransform(130.7,46.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAhQgIgHgBgNIAPgBQACAHADAEQAFAEAFAAQAIAAAEgEQAEgDAAgEQgBgBAAAAQAAgBAAgBQAAAAAAgBQgBAAAAgBQgCgCgEgBIgKgEQgOgDgEgDQgIgGABgJQAAgGADgGQADgFAGgDQAHgCAIAAQAOAAAIAGQAHAHAAALIgPAAQgBgGgEgCQgDgDgGAAQgGAAgEADQgCABAAAEQAAACACACQADADAKADQALACAFADQAGADADADQAEAFAAAIQAAAHgFAFQgDAGgHADQgHADgKAAQgNAAgIgHg");
	this.shape_2.setTransform(123.1,46.4);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgGAnIAAhNIANAAIAABNg");
	this.shape_3.setTransform(118,46.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAWAnIAAg8IgPA8IgNAAIgQg8IAAA8IgOAAIAAhNIAXAAIANA0IANg0IAZAAIAABNg");
	this.shape_4.setTransform(111.9,46.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgdAnIAAhNIA5AAIAAANIgpAAIAAASIAmAAIAAALIgmAAIAAAVIAqAAIAAAOg");
	this.shape_5.setTransform(103.8,46.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgRAjQgJgFgFgKQgEgKAAgKQAAgLAFgKQAFgJAKgFQAHgEAKAAQAOAAAJAGQAIAGACALIgQADQgBgGgFgDQgFgEgGAAQgJAAgGAHQgGAGAAANQAAAMAGAIQAGAHAIAAQAFAAAFgCIAJgFIAAgKIgSAAIAAgLIAiAAIAAAdQgFAFgJADQgKAEgKAAQgKAAgJgFg");
	this.shape_6.setTransform(95.6,46.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgVAhQgIgHgBgNIAPgBQACAHADAEQAFAEAFAAQAIAAAEgEQADgDAAgEQAAgBAAAAQAAgBAAgBQAAAAAAgBQgBAAAAgBQgCgCgEgBIgKgEQgOgDgEgDQgIgGAAgJQABgGADgGQADgFAHgDQAGgCAIAAQAOAAAIAGQAHAHAAALIgPAAQgCgGgDgCQgEgDgFAAQgGAAgEADQgDABABAEQgBACADACQADADAKADQALACAGADQAFADAEADQADAFAAAIQAAAHgFAFQgDAGgHADQgHADgKAAQgNAAgIgHg");
	this.shape_7.setTransform(152.9,32.1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdAnIAAhNIA5AAIAAANIgoAAIAAASIAlAAIAAALIglAAIAAAVIAqAAIAAAOg");
	this.shape_8.setTransform(145.8,32.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgRAjQgJgFgFgKQgEgKAAgKQAAgLAFgKQAFgJAKgFQAHgEAKAAQAOAAAJAGQAIAGACALIgQADQgBgGgFgDQgFgEgGAAQgJAAgGAHQgGAGAAANQAAAMAGAIQAGAHAIAAQAFAAAFgCIAJgFIAAgKIgSAAIAAgLIAiAAIAAAdQgFAFgJADQgKAEgKAAQgKAAgJgFg");
	this.shape_9.setTransform(137.6,32.1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgGAnIAAhNIANAAIAABNg");
	this.shape_10.setTransform(131.9,32.1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAPAnIAAgjIgdAAIAAAjIgQAAIAAhNIAQAAIAAAfIAdAAIAAgfIAQAAIAABNg");
	this.shape_11.setTransform(126.4,32.1);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAVAwIgGgSIgdAAIgHASIgRAAIAfhNIAPAAIAfBNgAAKARIgKgcIgKAcIAUAAgAADgiIAAgNIAOAAIAAANgAgRgiIAAgNIANAAIAAANg");
	this.shape_12.setTransform(118.5,31.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgaAnIAAhNIA0AAIAAANIgjAAIAAATIAfAAIAAALIgfAAIAAAig");
	this.shape_13.setTransform(111.4,32.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AggAnIAAhNIAeAAQAHAAAFACQAHACAGAFQAFAFACAIQACAHABAJQgBAKgCAHQgDAIgFAGQgFAEgHACQgFACgGAAgAgQAZIAMAAIAIAAQADgBADgDQADgCACgFQABgFAAgJQAAgIgBgFQgCgEgDgDQgDgDgFgBIgLgBIgHAAg");
	this.shape_14.setTransform(104.1,32.1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAPAnIgegyIAAAyIgPAAIAAhNIAQAAIAeAzIAAgzIAPAAIAABNg");
	this.shape_15.setTransform(96,32.1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgPAuQgFgDgEgEQgDgEgBgFQgCgHAAgNIAAgoIAQAAIAAApIABANQABAFAEADQADADAFAAQAHAAADgDQAEgDAAgEIABgNIAAgqIAQAAIAAAnIgBAUQgCAGgDAEQgEAEgFADQgGACgKAAQgJAAgGgCgAAFgjIAAgMIANAAIAAAMgAgQgjIAAgMIANAAIAAAMg");
	this.shape_16.setTransform(88.1,31.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgeAnIAAgPIAngxIgjAAIAAgNIA4AAIAAAMIgpAzIArAAIAAAOg");
	this.shape_17.setTransform(80.8,32.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_18.setTransform(182.7,122.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_19.setTransform(178.4,123.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAAAlQgDgCgCgDQgBgDABgIIAAgfIgIAAIAAgIIAIAAIAAgNIAHgHIAAAUIAKAAIAAAIIgKAAIAAAgIAAAEIACADIAEAAIAEAAIABAJIgHABQgFAAgBgCg");
	this.shape_20.setTransform(174,122.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAAAlQgDgCgCgDQgBgDAAgIIAAgfIgHAAIAAgIIAHAAIAAgNIAIgHIAAAUIAKAAIAAAIIgKAAIAAAgIAAAEIACADIAEAAIAEAAIABAJIgHABQgGAAAAgCg");
	this.shape_21.setTransform(170.9,122.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_22.setTransform(168.1,122.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAcAdIAAgiIgBgJQgBgCgCgCQgDgBgCAAQgGAAgEAEQgEAEgBAJIAAAfIgIAAIAAgjQAAgHgCgDQgCgDgGAAQgEAAgDACQgEACgBAEQgBAEAAAHIAAAdIgKAAIAAg3IAJAAIAAAIQACgEAEgDQAFgDAFAAQAHAAAEADQACADACAEQAGgKALAAQAJAAAFAFQAEAFAAAKIAAAlg");
	this.shape_23.setTransform(162.4,123.2);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgPAZQgGgFgBgJIAJgCQABAGAEADQADADAFAAQAHAAADgDQADgCAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgDAAgFQAAgEACgDIAFgGIAGgCQAEgBAEAAQAFAAAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgCgFAAQgGAAgDACQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAEgFADQgFACgHAAQgJAAgGgEg");
	this.shape_24.setTransform(155,123.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_25.setTransform(149.2,123.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgSAVQgHgHAAgOQAAgPAJgHQAHgHAJABQALAAAIAIQAHAHAAANQAAAKgDAGQgDAHgHADQgGAEgHgBQgKAAgIgIgAgKgPQgFAFAAAKQAAALAFAFQAEAGAGgBQAHABAFgGQAEgFAAgLQAAgJgEgGQgFgGgHABQgGgBgEAGg");
	this.shape_26.setTransform(143.1,123.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_27.setTransform(138.9,122.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAAAlQgDgCgBgDQgBgDAAgIIAAgfIgHAAIAAgIIAHAAIAAgNIAHgHIAAAUIAKAAIAAAIIgKAAIAAAgIABAEIACADIACAAIAFAAIACAJIgIABQgGAAAAgCg");
	this.shape_28.setTransform(136.2,122.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgUAZQgFgFAAgHQAAgEACgDIAFgGIAHgBIAJgCIAPgDIAAgCQAAgGgDgDQgDgDgHAAQgGAAgDACQgDADgCAGIgJgCQABgGADgDQADgFAGgBQAFgCAGAAQAHAAAEACQAFABACACIADAHIABAJIAAALIAAARIADAHIgKAAIgCgHQgGAEgFACQgDACgFAAQgKAAgFgEgAgBADIgIACIgEADIgBAEQAAAEACADQADACAGAAQAEAAAEgCQAEgCACgFQACgDAAgGIAAgDQgFACgJABg");
	this.shape_29.setTransform(131.5,123.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgLAkQgGgEgDgHQgDgGAAgKQAAgIACgFQADgHAGgEQAGgDAGAAQAEAAAEACQAEACACAEIAAgdIAKAAIAABNIgJAAIAAgHQgFAJgKgBQgGAAgFgDgAgJgFQgEAFgBAJQAAAMAGAFQAEAGAEgBQAHABAEgGQAFgFgBgLQABgKgFgFQgEgGgHABQgEgBgFAGg");
	this.shape_30.setTransform(125.3,122.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_31.setTransform(121.2,122.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAOAcIgMgSIgCgEIgOAWIgLAAIAUgcIgTgbIAMAAIAJANIADAHIADgHIAKgNIAMAAIgUAbIAVAcg");
	this.shape_32.setTransform(117.3,123.3);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgSAjQgJgGgFgJQgEgJAAgLQAAgRAKgLQALgLAPAAQALAAAIAFQAJAFAFAJQAEAKAAAKQAAALgEAKQgGAJgJAFQgJAFgJAAQgKAAgIgFgAgRgXQgJAIAAAQQABAOAHAIQAIAIAKAAQALAAAIgIQAHgIAAgPQAAgIgDgHQgDgIgGgDQgGgEgIAAQgKAAgHAHg");
	this.shape_33.setTransform(110.3,122.2);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgLAkQgGgEgDgHQgDgGAAgKQAAgIADgFQADgHAFgEQAGgDAGAAQAEAAAEACQAEACADAEIAAgdIAJAAIAABNIgJAAIAAgHQgFAJgKgBQgFAAgGgDgAgJgFQgFAFABAJQAAAMAEAFQAFAGAEgBQAHABAEgGQAEgFAAgLQAAgKgEgFQgEgGgHABQgFgBgEAGg");
	this.shape_34.setTransform(99.7,122.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAGAAADACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_35.setTransform(93.8,123.2);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgMAbQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCg");
	this.shape_36.setTransform(87.6,123.4);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgNAFIAAgJIAbAAIAAAJg");
	this.shape_37.setTransform(79.7,123.3);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgDAGABIAJABIgBAIIgGAAQgEgBgCACQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_38.setTransform(76.6,122.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgDAGABIAJABIgBAIIgGAAQgEgBgCACQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_39.setTransform(73.6,122.2);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgSAVQgHgHAAgOQAAgPAJgHQAHgHAJABQALAAAIAIQAHAHAAANQAAAKgDAGQgDAHgHADQgGAEgHgBQgKAAgIgIgAgKgPQgFAFAAAKQAAALAFAFQAEAGAGgBQAHABAFgGQAEgFAAgLQAAgJgEgGQgFgGgHABQgGgBgEAGg");
	this.shape_40.setTransform(68.7,123.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAAAlQgDgCgCgDQgBgDAAgIIAAgfIgHAAIAAgIIAHAAIAAgNIAIgHIAAAUIAKAAIAAAIIgKAAIAAAgIAAAEIACADIAEAAIAEAAIABAJIgHABQgGAAAAgCg");
	this.shape_41.setTransform(64.3,122.4);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgOAlQgHgDgEgGQgFgHAAgIIAKAAQABAGACADQADAEAFACQAGADAEAAQAGAAAFgCQAEgCADgDQACgDAAgEQAAgDgCgDQgCgDgFgCIgMgEIgQgCQgFgDgDgFQgDgEAAgGQAAgGAEgFQADgFAGgDQAHgCAHAAQAIAAAGADQAHACAEAGQADAFABAHIgKABQgBgIgFgDQgFgEgIAAQgIAAgEADQgFAEAAAFQAAAEADADQADACALADIARAFQAHABAEAFQADAFAAAHQAAAGgEAFQgDAGgHADQgHADgIAAQgJAAgHgDg");
	this.shape_42.setTransform(59,122.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIABAKIAAAhg");
	this.shape_43.setTransform(168.7,106.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgIQAHgHAKAAQALAAAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_44.setTransform(162.6,107);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgEAAQgDAAgCACQgCACAAAEQgCAFAAAFIAAAdg");
	this.shape_45.setTransform(158.2,106.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgUAZQgFgFAAgHQAAgEACgDIAFgGIAHgBIAJgCIAPgDIAAgCQAAgGgDgDQgDgEgHAAQgGAAgDADQgDACgCAHIgJgCQABgGADgEQADgEAGgBQAFgCAGAAQAHAAAEACQAFABACACIADAHIABAJIAAALIAAARIADAHIgKAAIgCgHQgGAEgFACQgDACgFAAQgKAAgFgEgAgBADIgIACIgEADIgBAEQAAAEACADQADACAGAAQAEAAAEgCQAEgCACgFQACgDAAgGIAAgDQgFACgJABg");
	this.shape_46.setTransform(152.8,107);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgOAfIAAAHIgJAAIAAhNIAKAAIAAAcQAGgHAHAAQAGAAAEACQAFACADAEQADAEACAFQABADAAAHQAAAPgHAHQgHAJgKgBQgIAAgGgIgAgKgFQgEAFAAAJQAAALADAEQAEAIAHgBQAFABAFgGQAFgFAAgLQAAgKgFgFQgEgGgGAAQgFAAgFAGg");
	this.shape_47.setTransform(146.9,106);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_48.setTransform(140.7,106.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIABAKIAAAhg");
	this.shape_49.setTransform(134.6,106.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgIQAHgHAKAAQALAAAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_50.setTransform(128.4,107);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgEgDgEAAQgDAAgBACQgCACgBAEQgBAFAAAFIAAAdg");
	this.shape_51.setTransform(124,106.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgOAfIAAAHIgJAAIAAhNIAKAAIAAAcQAGgHAHAAQAGAAAEACQAFACADAEQADAEACAFQABADAAAHQAAAPgHAHQgHAJgKgBQgIAAgGgIgAgKgFQgEAFAAAJQAAALADAEQAEAIAHgBQAFABAFgGQAFgFAAgLQAAgKgFgFQgEgGgGAAQgFAAgFAGg");
	this.shape_52.setTransform(118.8,106);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIABAKIAAAhg");
	this.shape_53.setTransform(109.6,106.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgIQAHgHAKAAQALAAAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_54.setTransform(103.4,107);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AANAnIAAgkQAAgGgDgDQgDgDgGAAQgCAAgEACQgEACgCAEQgBACAAAHIAAAfIgKAAIAAhNIAKAAIAAAcQAGgIAJAAQAGAAAFADQAEACACAFQACAEAAAHIAAAkg");
	this.shape_55.setTransform(97.4,105.9);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgQAVQgHgHAAgOQAAgHADgIQADgGAGgEQAGgDAGAAQAJAAAGAEQAGAFABAJIgJABQgBgFgEgDQgDgDgFgBQgFAAgFAGQgFAFAAAKQAAALAFAFQAEAGAFgBQAGABAEgEQAEgDABgIIAJACQgBAJgHAGQgGAGgKgBQgJABgHgJg");
	this.shape_56.setTransform(91.7,107);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgPAZQgGgFgBgJIAJgBQABAFAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgDAAgFQAAgEACgDIAFgFIAGgDQAEgBAEAAQAFAAAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgDgFAAQgGAAgDADQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAFgFACQgFADgHgBQgJAAgGgEg");
	this.shape_57.setTransform(86,107);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_58.setTransform(82.1,105.9);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AAKAcIgJggIgBgKIgKAqIgKAAIgRg3IAKAAIAJAfIADAMIACgMIAKgfIAIAAIAJAfIACALIADgLIAKgfIAJAAIgSA3g");
	this.shape_59.setTransform(77,107);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AgYAcIAAgIIAjgnIgLAAIgVAAIAAgIIAsAAIAAAGIgdAiIgGAHIAMgBIAZAAIAAAJg");
	this.shape_60.setTransform(70.2,107);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_61.setTransform(188.2,90.7);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AANAnIAAgkQAAgGgDgDQgDgDgGAAQgCAAgEACQgEACgCAEQgBACAAAHIAAAfIgJAAIAAhNIAJAAIAAAcQAGgIAJAAQAHAAAEADQAFACACAFQACAEAAAHIAAAkg");
	this.shape_62.setTransform(182.1,89.6);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgQAVQgHgHAAgOQAAgHADgIQADgGAGgEQAGgEAGAAQAJABAGAEQAGAFABAIIgJACQgBgFgEgDQgDgEgFAAQgFAAgFAGQgFAFAAAKQAAALAFAFQAEAGAFgBQAGABAEgEQAEgDABgIIAJACQgBAJgHAGQgGAFgKAAQgJABgHgJg");
	this.shape_63.setTransform(176.5,90.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgUAjQgFgFAAgHQAAgEACgDIAFgGIAHgDIAJgCIAPgDIAAgCQAAgEgDgDQgDgDgHAAQgGAAgDACQgDADgCAFIgJgBQABgGADgDQADgEAGgCQAFgCAGAAQAHAAAEACQAFABACADIADAHIABAGIAAANIAAARIADAHIgKAAIgCgHQgGAFgFACQgDACgFAAQgKAAgFgFgAgBANIgIACIgEADIgBAFQAAAEACACQADADAGAAQAEAAAEgCQAEgDACgEQACgDAAgHIAAgDQgFACgJABgAAEgcIAAgLIALAAIAAALgAgOgcIAAgLIALAAIAAALg");
	this.shape_64.setTransform(170.5,89.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_65.setTransform(166.2,89.6);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgHAnIAAgvIgIAAIAAgIIAIAAIAAgGIABgIQACgEADgCQACgCAGAAIAJABIgBAIIgGAAQgEAAgCABQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAvg");
	this.shape_66.setTransform(163.8,89.6);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgYAcIAAgIIAjgoIgLABIgVAAIAAgIIAsAAIAAAGIgdAiIgGAHIAMgBIAZAAIAAAJg");
	this.shape_67.setTransform(159.2,90.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIABAKIAAAhg");
	this.shape_68.setTransform(153.5,90.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_69.setTransform(147.3,90.7);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgEgDgEAAQgDAAgBACQgCACgBAEQgBAFAAAFIAAAdg");
	this.shape_70.setTransform(142.9,90.6);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AgQAjQgJgFgFgJQgFgKAAgLQAAgKAFgKQAFgKAJgEQAJgFAKAAQAIAAAHACQAHADAEAFQAEAFACAIIgKADQgBgGgDgEQgDgDgFgCQgEgCgGAAQgGAAgFACQgFACgDADIgFAIQgDAIAAAHQAAAKADAHQAEAHAHADQAHAEAGAAQAHAAAGgDIAKgFIAAgPIgXAAIAAgIIAhAAIAAAcQgIAGgIADQgIADgJAAQgJAAgKgFg");
	this.shape_71.setTransform(136.3,89.6);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgEgDgDAAQgDAAgCACQgBACgBAEQgCAFAAAFIAAAdg");
	this.shape_72.setTransform(127.7,90.6);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_73.setTransform(122.3,90.7);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgLAkQgGgEgDgHQgDgHAAgIQAAgJACgFQADgHAGgDQAGgEAGgBQAEAAAEADQAEACACADIAAgcIAKAAIAABNIgJAAIAAgHQgFAIgKAAQgFAAgGgDgAgJgFQgFAFABAKQAAALAEAFQAFAGAEgBQAGABAFgGQAFgFgBgKQABgLgFgFQgFgGgGAAQgEAAgFAGg");
	this.shape_74.setTransform(116.1,89.7);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIABAKIAAAhg");
	this.shape_75.setTransform(107.1,90.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgUAZQgFgFAAgHQAAgEACgEIAFgFIAHgCIAJgBIAPgDIAAgCQAAgHgDgCQgDgEgHAAQgGAAgDADQgDACgCAHIgJgCQABgGADgEQADgDAGgCQAFgCAGgBQAHABAEACQAFABACACIADAIIABAIIAAALIAAARIADAHIgKAAIgCgHQgGAFgFACQgDABgFAAQgKAAgFgEgAgBADIgIACIgEADIgBAEQAAAFACACQADADAGgBQAEAAAEgCQAEgCACgFQACgDAAgGIAAgDQgFACgJABg");
	this.shape_76.setTransform(101,90.7);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgPAZQgGgFgBgJIAJgBQABAFAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgDACgEIAFgFIAGgDQAEgCAEAAQAFABAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgDgFAAQgGAAgDADQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAEgFADQgFADgHgBQgJAAgGgEg");
	this.shape_77.setTransform(92.1,90.7);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_78.setTransform(88.2,89.6);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_79.setTransform(84,90.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgCgDQgBgCABgJIAAgfIgIAAIAAgIIAIAAIAAgNIAHgGIAAATIAKAAIAAAIIgKAAIAAAgIAAAEIACACIAEABIAEAAIABAIIgHACQgFgBgBgCg");
	this.shape_80.setTransform(79.5,89.8);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_81.setTransform(76.6,89.6);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AgUAjQgFgFAAgHQAAgEACgDIAFgGIAHgDIAJgCIAPgDIAAgCQAAgEgDgDQgDgDgHAAQgGAAgDACQgDADgCAFIgJgBQABgGADgDQADgEAGgCQAFgCAGAAQAHAAAEACQAFABACADIADAHIABAGIAAANIAAARIADAHIgKAAIgCgHQgGAFgFACQgDACgFAAQgKAAgFgFgAgBANIgIACIgEADIgBAFQAAAEACACQADADAGAAQAEAAAEgCQAEgDACgEQACgDAAgHIAAgDQgFACgJABgAAEgcIAAgLIALAAIAAALgAgOgcIAAgLIALAAIAAALg");
	this.shape_82.setTransform(72.4,89.7);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AANAnIAAgkQAAgGgDgDQgDgDgGAAQgCAAgEACQgEACgCAEQgBACAAAHIAAAfIgKAAIAAhNIAKAAIAAAcQAGgIAJAAQAGAAAFADQAEACADAFQABAEAAAHIAAAkg");
	this.shape_83.setTransform(66.3,89.6);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgEAAQgDAAgCACQgCACAAAEQgCAFAAAFIAAAdg");
	this.shape_84.setTransform(61.9,90.6);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_85.setTransform(56.5,90.7);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgDAcIgWg3IAKAAIANAgIACAMIADgLIANghIAKAAIgWA3g");
	this.shape_86.setTransform(50.8,90.7);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgNAEIAAgIIAbAAIAAAIg");
	this.shape_87.setTransform(186.4,74.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgPAYQgGgEgBgJIAJgBQABAFAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgEACgDIAFgFIAGgDQAEgCAEAAQAFAAAFADQAFABADAEQACADABAFIgKACQAAgFgDgCQgDgCgFgBQgGABgDACQgCACAAADIABADIADADIAHACIAOAFQAEAAADADQACAEAAAEQAAAFgDAEQgDAEgFADQgFACgHABQgJAAgGgGg");
	this.shape_88.setTransform(181.8,74.4);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIAAAKIAAAhg");
	this.shape_89.setTransform(176,74.3);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgSAVQgHgHAAgOQAAgPAJgHQAHgHAJAAQALABAIAHQAHAIAAANQAAAJgDAHQgDAGgHAEQgGADgHABQgKAAgIgJgAgKgPQgFAGAAAJQAAAKAFAGQAEAFAGAAQAHAAAFgFQAEgFAAgLQAAgJgEgGQgFgFgHgBQgGABgEAFg");
	this.shape_90.setTransform(169.9,74.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_91.setTransform(165.7,73.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgCgDQgBgCAAgJIAAgfIgGAAIAAgIIAGAAIAAgOIAIgFIAAATIAKAAIAAAIIgKAAIAAAgIAAAEIADACIADABIAEAAIACAIIgIABQgFAAgBgCg");
	this.shape_92.setTransform(163,73.5);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AgUAYQgFgEAAgHQAAgEACgEIAFgFIAHgCIAJgBIAPgDIAAgCQAAgHgDgCQgDgDgHgBQgGABgDACQgDACgCAGIgJgBQABgGADgEQADgDAGgCQAFgDAGAAQAHAAAEADQAFABACACIADAIIABAIIAAALIAAARIADAHIgKAAIgCgHQgGAFgFACQgDABgFABQgKAAgFgGgAgBADIgIACIgEADIgBAEQAAAEACADQADADAGgBQAEAAAEgBQAEgDACgFQACgDAAgGIAAgDQgFABgJACg");
	this.shape_93.setTransform(158.3,74.4);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgEAAQgDAAgCACQgBACgBAEQgCAFAAAFIAAAdg");
	this.shape_94.setTransform(153.9,74.3);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgCgDQgBgCAAgJIAAgfIgHAAIAAgIIAHAAIAAgOIAIgFIAAATIAKAAIAAAIIgKAAIAAAgIAAAEIACACIAEABIAEAAIABAIIgHABQgGAAAAgCg");
	this.shape_95.setTransform(150.2,73.5);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIABAKIAAAhg");
	this.shape_96.setTransform(145.6,74.3);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAJgGAEQgHAGgKAAQgKAAgHgJgAAQgEQgBgHgDgEQgFgFgHgBQgFABgEAEQgFAFAAAHIAeAAIAAAAg");
	this.shape_97.setTransform(139.4,74.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgYAcIAAgIIAjgoIgLABIgVAAIAAgIIAsAAIAAAGIgdAiIgGAHIAMAAIAZAAIAAAIg");
	this.shape_98.setTransform(133.6,74.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAADACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_99.setTransform(127.9,74.3);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgSAVQgHgHAAgOQAAgPAJgHQAHgHAJAAQALABAIAHQAHAIAAANQAAAJgDAHQgDAGgHAEQgGADgHABQgKAAgIgJgAgKgPQgFAGAAAJQAAAKAFAGQAEAFAGAAQAHAAAFgFQAEgFAAgLQAAgJgEgGQgFgFgHgBQgGABgEAFg");
	this.shape_100.setTransform(121.7,74.4);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AATAnIgagnIgOALIAAAcIgKAAIAAhNIAKAAIAAAmIAmgmIANAAIgeAgIAgAtg");
	this.shape_101.setTransform(115.5,73.3);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgPAYQgGgEgBgJIAJgBQABAFAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgEACgDIAFgFIAGgDQAEgCAEAAQAFAAAFADQAFABADAEQACADABAFIgKACQAAgFgDgCQgDgCgFgBQgGABgDACQgCACAAADIABADIADADIAHACIAOAFQAEAAADADQACAEAAAEQAAAFgDAEQgDAEgFADQgFACgHABQgJAAgGgGg");
	this.shape_102.setTransform(105.6,74.4);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAJgGAEQgHAGgKAAQgKAAgHgJgAAQgEQgBgHgDgEQgFgFgHgBQgFABgEAEQgFAFAAAHIAeAAIAAAAg");
	this.shape_103.setTransform(99.8,74.4);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgCgDQgBgCAAgJIAAgfIgHAAIAAgIIAHAAIAAgOIAIgFIAAATIAKAAIAAAIIgKAAIAAAgIAAAEIACACIAEABIAEAAIABAIIgHABQgGAAAAgCg");
	this.shape_104.setTransform(95.3,73.5);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AAdAdIAAgiIgBgJQgBgCgDgCQgCgBgDAAQgHAAgDAEQgFAEAAAJIAAAfIgHAAIAAgjQgBgHgBgDQgDgDgFAAQgEAAgEACQgEACgBAEQgCAEAAAHIAAAdIgJAAIAAg3IAIAAIAAAIQADgEAEgDQAFgDAFAAQAHAAAEADQACADACAEQAHgKALAAQAIAAAEAFQAFAFAAAKIAAAlg");
	this.shape_105.setTransform(89.2,74.3);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AAcAdIAAgiIgBgJQgBgCgCgCQgDgBgCAAQgGAAgEAEQgEAEgBAJIAAAfIgIAAIAAgjQAAgHgCgDQgCgDgGAAQgEAAgDACQgDACgCAEQgBAEAAAHIAAAdIgKAAIAAg3IAJAAIAAAIQACgEAEgDQAFgDAFAAQAHAAAEADQACADACAEQAGgKALAAQAJAAAFAFQAEAFAAAKIAAAlg");
	this.shape_106.setTransform(80,74.3);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_107.setTransform(74.2,73.3);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgCgDQgBgCAAgJIAAgfIgHAAIAAgIIAHAAIAAgOIAIgFIAAATIAKAAIAAAIIgKAAIAAAgIAAAEIADACIADABIAEAAIACAIIgIABQgFAAgBgCg");
	this.shape_108.setTransform(71.6,73.5);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgPAYQgGgEgBgJIAJgBQABAFAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgEACgDIAFgFIAGgDQAEgCAEAAQAFAAAFADQAFABADAEQACADABAFIgKACQAAgFgDgCQgDgCgFgBQgGABgDACQgCACAAADIABADIADADIAHACIAOAFQAEAAADADQACAEAAAEQAAAFgDAEQgDAEgFADQgFACgHABQgJAAgGgGg");
	this.shape_109.setTransform(67.2,74.4);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAJgGAEQgHAGgKAAQgKAAgHgJgAAQgEQgBgHgDgEQgFgFgHgBQgFABgEAEQgFAFAAAHIAeAAIAAAAg");
	this.shape_110.setTransform(61.4,74.4);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgcAnIAAhNIAcAAQAIAAAGACQAFADADAFQADAFAAAFQAAAFgCAFQgDAEgGADQAIABADAEQAEAFAAAHQAAAFgCAFQgCAFgEADQgDACgFABQgGACgHAAgAgSAdIASAAIAHAAIAGgCIAEgEQABgDAAgEQAAgEgCgEQgCgDgEgBQgEgCgGAAIgSAAgAgSgFIARAAIAIgBQAEgBACgDQACgCAAgFQAAgEgCgCQgCgDgDgCIgKgBIgQAAg");
	this.shape_111.setTransform(54.8,73.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18}]}).wait(1));

	// Layer 2
	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.lf(["#CCCCCC","#666666"],[0,1],-4.2,0,4.4,0).s().p("AgdAZQgNgLAAgOQAAgNANgMQANgLAQAAQASAAAMALQANAMAAANQAAAOgNALQgMALgSAAQgQAAgNgLg");
	this.shape_112.setTransform(211.9,51.5);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.lf(["#CCCCCC","#666666"],[0,1],-30.3,-100.9,-30.3,70.6).s().p("AljMgQhFgwAAhFQAAgRAFgPQgxAbhAAAQhTAAg7gxQg9gwAAhEQAAgOACgOQgcAGghAAQhzAAhQhPQhThOAAhwQAAhvBThPQAhggAogRQgUgKgRgOQg3gsAAg+QAAg+A3gsQA2gsBLAAIASABQgbgeAAgnQAAgyAsgiQAigcAsgFIAAgLQAAg5AzgpQAxgoBGAAQALAAAKABQAJgOAPgNQAggaAtAAQAkAAAcARIAAgHQAAgjAcgYQABgDAEgCQAfgaAuAAIANADQAIACACgDQAVgtA3gXQAygVA9ACQA6ABAqAVQAuAXADAjQABAEAHAEIAMAGQALAJAIAKIAHgHQAagVAkAAQAmAAAbAVQAWATADAZQARgDAUAAQA9AAArAjQAsAjAAAyIgBAPQAkgLApAAQBVAAA+AwQA8AyAABGQAAA5gqAsQA5ABAoAhQApAhAAAwQAAAUgHARIABAAQBUAAA8AwQA7AwAABDQAABFg7AvQg6AvhPADQBPBSAABtQAACAhwBbQhxBcieAAQhrAAhVgpIAAACQAABFg4AwQg4AxhRAAQhQAAg3gxIgTgQQgQAjgnAcQg8ArhRAFIgaABQhhAAhGgxg");
	this.shape_113.setTransform(117,74.2);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.lf(["#CCCCCC","#666666"],[0,1],-7,0,7.3,0).s().p("AgxAqQgVgRAAgZQAAgYAVgRQAWgTAbAAQAdAAAWATQAUARAAAYQAAAZgUARQgWATgdAAQgbAAgWgTg");
	this.shape_114.setTransform(27.7,136.4);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.lf(["#CCCCCC","#666666"],[0,1],-4.3,0,4.3,0).s().p("AgdAaQgNgMAAgOQAAgNANgMQANgKAQAAQARAAANAKQANAMAAANQAAAOgNAMQgNALgRAAQgQAAgNgLg");
	this.shape_115.setTransform(18.7,126.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_112}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(9.6,-10.7,214.8,169.9);


(lib.rahmen_neu = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.instance = new lib.header();

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,750,82);


(lib.pfeil_rot3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B60000").s().p("ACGAoIooAAIAAhOIIoAAIAAhVIEdB7IkdB8g");
	this.shape.setTransform(71.5,12.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(29.6,0,83.9,25);


(lib.pfeil_rot2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B60000").s().p("AEiAoItfAAIAAhOINfAAIAAhVIEdB7IkdB8g");
	this.shape.setTransform(56,12.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1.5,0,115,25);


(lib.pfeil_rot1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#B60000").s().p("AbyAoMg7/AAAIAAhOMA7/AAAIAAhVIEcB7IkcB8g");
	this.shape.setTransform(-136.2,12.5);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-342.5,0,412.6,25);


(lib.pfeil_mitte = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#CCCCCC"],[0,1],0,69.9,0,-69.8).s().p("AuBsVIcDAAIuCYrg");
	this.shape.setTransform(50.2,11.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.6,-67.9,179.7,158.1);


(lib.papierkugel_braun = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C98E58").s().p("AAKChIh9g4IgXgKQEKhYhJivQAPAUAKAkIADAOQAJBXAcAnQATAiAAAtQgBA+hEAAQgZAAgjgIg");
	this.shape.setTransform(219.3,281.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F4B482").s().p("AAgBIQhSg4gXg2QgqgvByAQQAxAQALAhQgDAHgBAKQgtAuBLAfQgaAAgbgCg");
	this.shape_1.setTransform(163.4,241.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C88A57").s().p("ADQAlQgKgUgvAaIhKAsQg1g5h5AJQgqAEgqAAQhLgeAtguQABgKADgIQgLghgzgPQA5ACgkguQA7ApARAXQAbgGAsAPQBVAmBigmQBYgThIBFQhFA+BlgQQBIgqBEgFQgkAjgVAsQhFBVhAABQAxg5BPgyg");
	this.shape_2.setTransform(190.3,244.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#E19B6C").s().p("ACWBKQj2Ajj0gDQATgpBTgIQA0gCA3glQBZgkBrA8QALgQANgPQBBgBBEhTQAVgsAkglIABAAQAMAfAAAkIgBASIgBALQgMA/ARAmQAKAXAUAMQAfAcgfAoQgMAJgSAAQgzAAhehRg");
	this.shape_3.setTransform(189.3,257.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#DB985C").s().p("AhwAjIALgVQA4hgAvgRQgKAWAIAlQAuBvBEAbQgMACgNAAQhJAAiAhBg");
	this.shape_4.setTransform(219.9,224.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#9B5C34").s().p("AhjhtQAeAeBFgjQCOgygaCVQg/gCgRAeQgvAQg4BjQhUixA0g8g");
	this.shape_5.setTransform(216.5,213.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#5B3516").s().p("ADlCLQjNhijIBiQgKgkgPgUQgXgeglAHQgRgmAMg/IABgLIABgSQCdBQBQgkQB3gzAAhCQA0AlAGAlQAoBwBFBOIANAXQgVgBgWgEg");
	this.shape_6.setTransform(245.1,255.8);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#BB805B").s().p("AhJBPIgNgXQBCg5AfhNIAKAHQB2AxheBJQguAchAAAIgIAAg");
	this.shape_7.setTransform(279.8,262.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#E8AA7C").s().p("AhKg5QgFgkg0glIANABQBEgPAxA4ICFBYQghBKhCA7QhDhNgohxg");
	this.shape_8.setTransform(267.7,254.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#9B6539").s().p("Ah/BIQAAgjgMggQgVgyg4gpIgMgMIAAgeQCaBNBKgOIAHAEQAkAKApgMQAtgJAogQQAFBPA3AJIAAAAQAABBh5AzQgZANghAAQhGAAhrg5g");
	this.shape_9.setTransform(231.4,241.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FBD99A").s().p("AhDBxIgJgDQhEgbguhvQgKglAMgWQARgfA/ABQAVABAbAEIgBA3QgfA2BFgGQA8gUBRApQAqAHAkANQgvAhg4AWQgoAPgtAKQgVAGgUAAQgSAAgQgFg");
	this.shape_10.setTransform(239.1,223.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#925B3D").s().p("ABLDVIgKgGIiFhYQgyg4hDAPIgOgBIgBAAQg3gLgEhNQA4gWAvghQA3ATAoAeQBnA4BEhkQAXhrA7hpQAcg/ASgBQAIAAAGALQAdCXhDBiQgoA2A4A3QBABOiBCnQgdAngmAWQBehMh1gxg");
	this.shape_11.setTransform(274.5,233.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#D18E68").s().p("AgDhxQgGgpgEgpQA2BsgHC6QgHArAAA2QhohTBKjig");
	this.shape_12.setTransform(47.2,263.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#5D3316").s().p("AonClQi5hNg9hVQBRAYBOAzQBZApBVghQAtgSAsglQBdgNAIhCQBLAABygVQAlgMARgMQAPgKgCgKQA4hGBygFIAUgBQAugDAsAAQDlgDCdA+IAXAKIB/A4QiVAWiGg2Qjsg0iGBqQhUBpiAghQhmgThIBPQhyBqhjAAQgyAAgvgcg");
	this.shape_13.setTransform(140.6,304);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#B87549").s().p("AiUBpQh3gCh2gKQg9gcBfgBQBUg5BpgcQAwg+A1gKIAMABIARABQAaACAZAAQAqAAAqgEQB7gJA1A5IBKgsQAugaALAUQhPAygxA3QgNAPgLAQQhug8hYAkQg3AlgyACQhTAIgTApg");
	this.shape_14.setTransform(170.1,257.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#D17E52").s().p("AhnAeQgCguAYgtQgPgcAPgXQAdAMAaAWQAUA5B5AAQgIBChdANQgqAmgsARQhBgHAihMg");
	this.shape_15.setTransform(101.4,301.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#E5A267").s().p("ABAD3QhMgzhRgYQhvACgcgcQgXgRBSgkQgahGgCg/QAAg2AHgqQAPhWAtgpQATgLATAKQAQBzBDAhQAjCQCTgLQAfAAAdALQgOAXAOAbQgYAtADAxQgiBMBAAHQgmAPgnAAQgwAAgxgXg");
	this.shape_16.setTransform(70.2,287.1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#F0A974").s().p("AgpBpQgbgXgdgMQgdgLgfABQiTALgmiQQALg0AdgjQABA/BoAlQBoAcA9ByQAgA+CXgUQCdgZAjASQgSALgkANQhzAUhKAAQh6AAgTg4g");
	this.shape_17.setTransform(103,282.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#EAA66D").s().p("Ag7BlQgsATgqACQBAgmAZhUQA4idBjAiQglAjgQA7QgBACACAIQAIBRBbBFQhshBhhAjg");
	this.shape_18.setTransform(93.8,252.8);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFC48E").s().p("Ag7B7Qg8h0hogaQhoglgBg/QAIgKAJgJQAYAEAYgBQApgDAsgSQBjgkBqBBIABABIAZASIEUD2QACAJgPALQgigSidAZQglAFgfAAQhbAAgZgvg");
	this.shape_19.setTransform(105.6,278.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#C8774B").s().p("AigggIgZgSIgBAAQhahFgJhTQgBgIABgCQACgGASAhQARBHBqAUQCRAvAzBEQAbAwBIACQBrAOAaA2QhyAFg6BGg");
	this.shape_20.setTransform(127.1,271.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#F7BF85").s().p("AgeCpQhXgpAVguQBCh+BbhpQA8g0gfBOIiHDMQgOATAMANQAVAWBhAGQgkAegrAAQgLAAgLgCg");
	this.shape_21.setTransform(97.1,219.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFC283").s().p("AgLC0QlGh0gGgeQg+hBhfgSQjXhZFVhUIAKgDQCwgoCgBTIgMgCQg1AKgwA+QhpAehUA5QhfABA9AaQB2ALB3ABIABAAQDyADD4ghQB9BrAyglQAfgogfgaQgVgMgKgXQAmgHAWAeQBJCwkMBXQicg+jkADg");
	this.shape_22.setTransform(168,266.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#EDA970").s().p("ABiC/QhIgCgagwQgxhGiUgvQhqgUgQhFQgTghgCAGQAQg7AlgjQB5hzFOBEQAXAQAqgBQAYA4BTA4IgQgBQihhTiuAoIgJADQlVBUDXBXQBfASA7BDQAHAeFGB0QgrAAgvADIgUABQgag2hrgOg");
	this.shape_23.setTransform(132.6,259.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FAD59C").s().p("AEKDAQBIhEhYASQhkAnhVgnQgsgOgZAFQgRgWg7gqQgpgnhGgSQhYgYhviCQgZgUgXgIQAEg7BWgOQA9AZCPAmQC9A/g2BMQguAZgVAyQC+hNg2hxIB1gBQBFCOBnBlIANAMQA3ApAVA0IAAABQhEAFhIArQgUAEgOAAQg1AAA3g0g");
	this.shape_24.setTransform(173.5,222.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#C27D4D").s().p("AAdCRQgSgOgDgYQh0h3hciTQAQgBAQAGQAXAIAYAUQBwB/BVAbQBGASApAnQAkAug5gCQhygQAqAvIgFAAQgnAAgVgPg");
	this.shape_25.setTransform(146.5,221.2);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#EFB581").s().p("Al2HGQgJhsCLlaQCHjqCeirQgGBNDWASQgvhLAPhHQARARAVAHQgfBQBrBIQikgZAOAzQALATAaAEIACACQAKAJAcALQhXAOgDA7QgQgFgQAAQBcCRB2B5QADAZASANQlRhEh2BzQhlgig5CeQgZBVg/AmIgKAAQgTAAgTgDgAhViWQhdBphCB+QgVAuBXApQA6AJAtglQhjgGgVgWQgMgNAOgTICJjMQATgvgOAAQgKAAgYAVg");
	this.shape_26.setTransform(111.9,219.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#D69A6E").s().p("AhmAAIAWgVIAMgPQA1hBBnAHQgLAWgFAXQgPBGAvBLQjUgSAGhOg");
	this.shape_27.setTransform(127.3,178.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#F6C78F").s().p("AknF7IgBgBIAAgGIgCgLQgEgrACg0QAChzAlhlQA9lTgxhJQD0jSDKA7QAnAMBCAYIgMAPIgWAYQihCriEDqQiMFaAKBsQgKAJgIAKQgdAkgKAzQhDghgQhzg");
	this.shape_28.setTransform(90.1,222.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#EAB883").s().p("AidCZQgVgHgRgRQCdAmh7k0QBIgfBWAfQARAEASAGIAIADQBxApArCAQhkAQh1A8Qg+AoguAAQgPAAgNgEg");
	this.shape_29.setTransform(154.2,160.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#D49261").s().p("AjaC0QAOi0CPhBQAYhcBGg7QCdBPAdBIQhWgghIAgQB7EzidgmQAFgXALgWQhngHg1BAQhCgYgngMg");
	this.shape_30.setTransform(131.8,153.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#D49A6B").s().p("AhchKQAaAEAVAGQA+AQAjApQAdAgAMAyQgdhIichNg");
	this.shape_31.setTransform(144.4,138.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#F8D1A1").s().p("Ag9AOQAFgNgBgLQB4gYgCAYQgMAPg/ASQgWgGgZgDg");
	this.shape_32.setTransform(141.3,130);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FED7A4").s().p("Ai2AqQBBgRAMgSQACgVh6AVQgDgUgVgXQACghgTgVQA+gTB1ATQACALAkAYQBCAzD6BZQiwgYiuAnQgkgpg/gRg");
	this.shape_33.setTransform(158.2,128);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#DE9A6C").s().p("AkvCnQBHhuAfh6QDSjPBzA0QAoAEAbARQALAHAIAJQANAOAIAUQAlAHATATQATAUgCAiQAVAWADAXQABANgFALQgmh7hMgLQhihehlBeQivCkijDJIAYhAg");
	this.shape_34.setTransform(102.7,131.4);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#AA7355").s().p("AjLLDIAAgBQgNifAXiXQAvhughhmQAvgvABg5QCsmNBUnLQAqjcAqgGQg6DZgSDZQg7Ebg7A5QhXDsgDBqQABBOgbAyQASE9gLE+QgtApgPBVQAHi8g4hsg");
	this.shape_35.setTransform(66.2,173);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#DFA173").s().p("AgZi5QAkg8gBh6QAHAFAGAIQAxBJg+FTQgiBkgDB0QgCA0AFAqQgnk0Amj1g");
	this.shape_36.setTransform(62.7,221.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#DD9466").s().p("AlgFgQgYhCBUjuQCjjICvimQBlhdBiBdQBMALAmB9QhIA7gYBbQiPBBgOC1QjKg7j0DSQgFgIgHgFg");
	this.shape_37.setTransform(99.2,149.7);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#D2935B").s().p("Al5C/QHPjYEZjCQAVgNARgMQg0BphwA7QhOA2ARBEQAGBrjmAjQi0A4i1AFQAAgsAcgKg");
	this.shape_38.setTransform(40.6,98.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#CF9162").s().p("AjJhHQB1iNDEh+QB6hLgsB3QhQCuAaCUQACAMAAANQAAA4gwAvQAiBmgwBuQhJjyjMjFg");
	this.shape_39.setTransform(39,175.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#C1865C").s().p("ABoFmQAbgygBhOQADhpBZjtQA7g5A7kbQATjZA5jZQgqAHgqDbQhTHMivGNQAAgMgCgNQgaiVBQitQAsh3h6BLQjEB/h1CKQhChKhOjaQgshrAAg2QC0gFC1g5QDmgjgGhrQgShGBOg2QBxg6A0hqQBRg5AQg9QgJG2hMC9QgfB9hHBtIgYBBQhUDsAYBCQABB7gmA7QgnD4AnE0IACALIABAGIAAABQgTgKgTALQALk9gSk+g");
	this.shape_40.setTransform(45.5,161.3);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#F9C28B").s().p("Ai7jQQBUguA6hJQBbgMBcg7QANgMAOgHQAKFzBiDnQheAng8A8QgagRgogEQhyg0jTDPQBMi9AJm1g");
	this.shape_41.setTransform(109.8,82.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#D4945A").s().p("AAqgCQgHgwA4hIQAPCSglAuQhQAJhTAsQAYg2BwhHg");
	this.shape_42.setTransform(289,156.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#CB8A60").s().p("AAfCwQgmgeg3gTQgkgMgqgIQhRgqg+ATQhFAHAfg3QCbhPAkgxQDwA3A9hoQAmg2AogBIAGAAIABAAQAVACAVAQQAhAWABAOQgSABgcA/Qg7BngXBrQgrBBg7AAQghAAgmgVg");
	this.shape_43.setTransform(265.1,214.1);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#A46941").s().p("Ah3gSQA7gPAWgtQAdgfAXANQAKAGAKAOQAOASAMAjQBFBqgKASQhphTiFgkg");
	this.shape_44.setTransform(313.1,164.8);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FDCE90").s().p("AgcgpQAJgTAogHQAUCCgfADQgEACgDAAQgVAAgKhtg");
	this.shape_45.setTransform(249.4,196.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#DF9E6E").s().p("AgdABQAZgCAigBIgKAEIgPABQgRAAgRgCg");
	this.shape_46.setTransform(254.6,189.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#F3B576").s().p("AkQBYQgBhfgTgpQgcg0C3gLQALB+AdgRQAfgCgUiEQAYACAbgBIAKgGQAxAABMAHIAAAiQCugMAWAWQgnABgnA2Qg9Bmjwg3QgkAxibBRIACg2g");
	this.shape_47.setTransform(260.3,203.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#DD9B6A").s().p("AjFAOQCyBACaijQAdAMAWgMIAMALQhCBWhoBFQgjABgYAEQhkgKhCg+g");
	this.shape_48.setTransform(254.8,181.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#F8D599").s().p("Ai/CsQg2hRhDgKQhagdAFghQAViUCGg4IBMhwQBFhJB7BqQAVASAWAXQCrCsAaBSQCJBUgFBLQgZgOgdAgQgWAtg7APQgGACgDACQgWAAgVADQAmgugQiTQg4BHAHAxQhxBIgZA2QinhQhGhMg");
	this.shape_49.setTransform(274.7,136.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#BC8355").s().p("AhcBGQBpgOgBgdQAMg+h8gWQA5ggA7AuQBkAUgRAqQgeAdgUAXQhGgChHABg");
	this.shape_50.setTransform(248,104.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FECB92").s().p("AB+FIQgng8iZhuQg7hchrgeQgbjUDBg2QANgUAbgeQAUgYAcgdIhKBwQiGA4gVCWQgFAfBaAdQBDAKA2BRQBEBNCpBQQgdAPgeAUQgLAGgNAAQgNAAgOgGg");
	this.shape_51.setTransform(255.7,139.6);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#BA8651").s().p("ACqDdQAFhLiJhUQgahSipisQgWgXgVgSQADgRCHAjQAQgDAPAAQBWBPAQBvQAFBGBtB2QAeAsgZAkQgKgOgKgFg");
	this.shape_52.setTransform(297.5,133);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#A66338").s().p("AACCcQAZiViOAzQhFAjgdgeQglgmAZiJQBRBECdh0QAdAQAcAKQBCA+BkAJQgqAHgJATQi3AKAcAzQATApABBgQgbgEgVgBg");
	this.shape_53.setTransform(227.9,196.2);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#C4845E").s().p("AhjCOIgNgNQhLhLCGhkQBtgyBKhGQgQBkAZCgQhkBJhDAAQgpAAgegZg");
	this.shape_54.setTransform(215.3,170.6);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#D28E65").s().p("AAsgLQiNgmg8gZQgcgLgKgJIgCgCQgRgSBMgDQDugXAtAxIAHAMQBKC3gkARIgKAFQA4hMjAg9g");
	this.shape_55.setTransform(154.4,205.8);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#F4B988").s().p("AimCIQhMACARASQgagEgLgSQgOg0CkAaQhrhJAfhNQA3ARBRg1QB2g8BkgRQA0gIAuADQhuAug4BWQhSAaBlCkQgtgyjuAYg");
	this.shape_56.setTransform(157.2,180.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#B07146").s().p("AAECmIAKgFQAkgRhIi2IgHgNQhlilBSgbIA2AAQAGCXA+CPQA3Bxi/BPQAVg0AtgZg");
	this.shape_57.setTransform(172,201.8);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#E9B584").s().p("AATCaIgSAAIg2AAQA1hWBvguQgvgDg0AIQgph/hxgqQDeguAsCOQA/DIiXAAIgRAAg");
	this.shape_58.setTransform(172.6,162);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#CF8D63").s().p("AizAHQCTguDUAEQgGAPgEASQjKAAiCAmg");
	this.shape_59.setTransform(211.9,151.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#9C5D35").s().p("Ai3CcIgFjhQAPiKgTiGQAZgLAcgIQCCgoDKAAQgEANgCAPQhKBGhvAxQiEBnBLBKIANANQgZCKAlAlQg0A8BSCzIgKAUIAAAeQhohnhFiOg");
	this.shape_60.setTransform(209.6,191.2);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#844D30").s().p("AgcgIQAUgIAUgGIARAaQgcAJgXAKIgGgfg");
	this.shape_61.setTransform(192.7,154.6);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#F3C18D").s().p("AAVA8IASAAQCsAMhCjTQgtiOjdAuIgIgDQgSgGgUgEQgLgxgdgiQCwgnCuAYQALAzAYA1QAIAhAGAiIAFAhQATCGgPCIIAFDjIh1ABQg+iRgGiXg");
	this.shape_62.setTransform(170.5,171.3);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FDBC8F").s().p("AkwA6QgJgJgLgHQA8g6BegnQAdgMAegJIGXAAQgKBNAnBMQlGgokvAVg");
	this.shape_63.setTransform(154.3,107.1);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FBE7B0").s().p("AiKgwQgkgYgCgLQgFgSBbAVQAxAKBJAWICJAsQgCAuALAyQj4hbhEgxg");
	this.shape_64.setTransform(167.1,127.3);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFD8A2").s().p("AgMgBQhLgWgxgLQCCgMCOALQgKAkgCAog");
	this.shape_65.setTransform(171.7,122.7);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FCE5AF").s().p("Ag6AgQh1gUg+AUQgTgTglgHQgIgSgNgOQEwgVFFAoQgJATgGAVQiQgLiCAMQhZgUAFASg");
	this.shape_66.setTransform(155.3,115.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FBCC8C").s().p("AiBC7QgdgKgcgQQgZihAQhiQACgPADgNQAEgSAGgPQAKgaAPgTQBqAeA6BcQCbBsAnA8QhxB3h6AAQgwAAgxgSg");
	this.shape_67.setTransform(248.1,163.8);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#F9D795").s().p("AjeivQClgWClgFIAugBQBHgBBHACQgbAegMAVQjBA2AbDUQgPATgKAaQjTgEiUAwQgRjgBYibg");
	this.shape_68.setTransform(223.3,131.8);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#CE936B").s().p("AhRgWQAZgcAZgOQB8AXgMA9QABAehpAOIgtABQAXgsgkgrg");
	this.shape_69.setTransform(241.1,104.9);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#6B3D25").s().p("AhjhXQAIgWAGgVQBTBwC9AXQAkAtgYAsQinAEijAWIhNALQBUhXAZiDg");
	this.shape_70.setTransform(214.2,102);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#D7A26E").s().p("AhnhxQCCAhBLgZQANA6hIBvIgjAyg");
	this.shape_71.setTransform(197.2,52.2);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#885130").s().p("AgmEhQgYg1gLgzQgLgyADgwQACgnALgmQAFgUAJgVQgnhMALhPQAGgtAWguIAhhOQg9EVBBA3IAagEIBMgLQhWCZAQDiQgUAHgTAHQgGghgIghg");
	this.shape_72.setTransform(192.3,118.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#C38D54").s().p("Ag3j2IBvDlIhOC6IghBNQA4itg4k/g");
	this.shape_73.setTransform(192.5,65.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#865025").s().p("AhGgtIBOi9IAjgxQBaB6gzCyQgGAVgIAWQgYCFhSBXIgcAEQhBg3A9kSg");
	this.shape_74.setTransform(197.2,87.1);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FDD492").s().p("Ak7koQAmgUArAUQARIlChg1QBcg2C+l4QAYguAlgWQA7E/g7CtQgWAugGAtImXAAQgfAKgcAMQhjjqgJlxg");
	this.shape_75.setTransform(158,70.7);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#F7C28F").s().p("AkvjuQBSAbA8guQAJGoBuiNQChk8C5AgQgxgEgkAWQglAVgYAvQi8F4heA2QgOAEgNAAQiIAAgQn0g");
	this.shape_76.setTransform(164.9,65);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#F6C596").s().p("AgZDCQAigVAxADQBAgQksk6IAKgDQAZhBBEAMQAlBoDaE0QghALgrAAQg4AAhJgTg");
	this.shape_77.setTransform(189.5,21.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#F6B886").s().p("AjtAGQASgNARgVICbkEQAHgaAfgLQEtE7hBAPQi5geihE8QgbAjgVAAQhAAAgGlAg");
	this.shape_78.setTransform(172.5,38.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#A96A3F").s().p("AhMEuQBDhigdiXQgGgMgIABQgBgOghgWQgVgOgUgCQC9ANCpgGQBbgYgcAjQhFBBg4BQQgaA/hPAtQhAA9gmAAQgXAAgPgUgAkgjaIgMgLQAegUAdgQQBTgsBSgJQAVgDAWAAQgXASB9AyQCUA/BTB/QhUAShOAAQjxAAi5itg");
	this.shape_79.setTransform(303.6,195.6);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#C38258").s().p("AFLBeQAcglhbAZQipAHi9gPIgCAAIgGAAQgWgWiuANIAAgjQhMgHgzAAQBohDBChXQD1DiFXhKQhTh8iUhAQh9gyAVgRQADgCAGgDQCHAmBpBTIATAQQCLBWAMBCQAHAcgdAhQgwA4iRBIQA4hPBFhCg");
	this.shape_80.setTransform(299.9,186.9);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#C98F62").s().p("ACbGyQAdghgGgcQgMhEiLhWIgUgQQALgShDhsQgNgjgNgSQAYgjgdgsQhuh1gEhJQgQhvhYhOQAjAAAjAOQAoAtBJAgQBmAqBCB6QApgMAiAWQgZAwAZAvQBnCqA5CkQAXAhgXAnQg5BnhBAAIgLgBg");
	this.shape_81.setTransform(324.3,154.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,354.3,323.4);


(lib.krawatte_zeigen_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8F1D01").s().p("AAgBDIhCAAIgKAAIgmiGIClAAIgoCGg");
	this.shape.setTransform(11.4,6.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CC3300").s().p("AhwEgIBOqMIBCAAIBRKMIhxBNg");
	this.shape_1.setTransform(11.4,50.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,22.8,86.7);


(lib.kanister = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Kanister weiß
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["#FFFFFF","#FFFFFF"],[0,1],-9,0,9,0).s().p("AhZARQADgCCvgqIgCAWIibAhg");
	this.shape.setTransform(31.5,24);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["#FFFFFF","#FFFFFF"],[0,1],-8.1,0,8.1,0).s().p("AhPAGQACgCCZgfIAFAaIiRAdg");
	this.shape_1.setTransform(40.1,-10);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#FFFFFF","#C6C6C6","#BEBEBE"],[0,0.518,1],-17.5,-0.4,17.5,-0.4).s().p("AisAxQgEgNAFgTQAFgRARgLQATgQAcgCICZgRIB8gPIgFAXIjhAdIgtAmIgLAOQgPAOgTAEIgIABQgPAAgEgNg");
	this.shape_2.setTransform(24.3,-70.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#FFFFFF","#FFFFFF"],[0,1],-22.5,-35.2,18.5,-35.2).s().p("ADWBuQgPl8gMgvQgFgagLgHIgIgCIgvAoQgGgHAOglIlcAsIADgPIFzg/IBCAcIAJLwIgLkYg");
	this.shape_3.setTransform(52.5,-33.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["#FFFFFF","#FFFFFF"],[0,1],-21.3,0,21.4,0).s().p("AjHA6QAOgSAKgBQAKABAUgIIASgHIAggGQCUgXAtgOQAcgKAvgaIAogZIgnAfIg6AsQgfAUh6AVQhLAMhkAfg");
	this.shape_4.setTransform(38.9,-51.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#FFFFFF","#BAB9B9"],[0,1],-18.1,0,18.1,0).s().p("AilBAQgMgGgCgNQgBgGAAgOQABgMAUgOQATgPAUgFQATgFCKgTQCFgSAAgBIAFACQAEAEABAFQACAJgKAJIi7AdQgeAGgKADQgRAHgXASIgdAWQgXAPgMAAIgGgBg");
	this.shape_5.setTransform(35.5,-67.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#FFFFFF","#FFFFFF"],[0,1],-1.5,0,1.6,0).s().p("AgBG0IgNkFIACk5IAHjeIADgnQACgnACAAIAEAkIgHJ2IAQDTg");
	this.shape_6.setTransform(-15.4,8.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.lf(["#C6C6C6","#FFF9F9"],[0,1],-2.4,0,2.5,0).s().p("AgXgHIAAgIIAvAAIgEAfg");
	this.shape_7.setTransform(-3.5,-49.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Kanister schwarz
	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-0.7,-1,1.5,-1).ss(0.1,1,1,3,true).p("AAGhDQgHAUgEBz");
	this.shape_8.setTransform(31.5,0.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-0.3,0.8,-0.3,0.8).ss(0.1,1,1,3,true).p("AgCiLIAFEX");
	this.shape_9.setTransform(54.2,10);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-0.3,0,0.4,0).ss(0.1,1,1,3,true).p("AgCBoIAFjP");
	this.shape_10.setTransform(28.5,4.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().ls(["#000000","#000000"],[0.012,1],-0.3,0,0.4,0).ss(0.1,1,1,3,true).p("AgCCeIAFk7");
	this.shape_11.setTransform(-14.7,-14);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().ls(["#000000","#000000"],[0.012,1],-0.6,-2,1.6,-2).ss(0.1,1,1,3,true).p("AAGBfIgLi9");
	this.shape_12.setTransform(-14.6,45.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().ls(["#000000","#000000"],[0.012,1],0.2,-2,0.8,-2).ss(0.1,1,1,3,true).p("AABgzIgBBn");
	this.shape_13.setTransform(-13.8,50.1);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().ls(["#000000","#000000"],[0.012,1],-0.1,0,0.1,0).ss(0.1,1,1,3,true).p("AAACsIAAlX");
	this.shape_14.setTransform(-15.1,19);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().ls(["#000000","#000000"],[0.012,1],-0.1,0,0.2,0).ss(0.1,1,1,3,true).p("AABjBIgBGD");
	this.shape_15.setTransform(-13.6,25.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-14.8,0,15.3,0).ss(0.1,1,1,3,true).p("AiXg8IEvB6");
	this.shape_16.setTransform(55.5,29.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-2.8,0,2.9,0).ss(0.1,1,1,3,true).p("AAcghIg3BD");
	this.shape_17.setTransform(10.2,52.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-1.2,0,1.2,0).ss(0.1,1,1,3,true).p("AAMABIgXgB");
	this.shape_18.setTransform(30.3,18.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-0.3,0,0.4,0).ss(0.1,1,1,3,true).p("AgCg0IAFBp");
	this.shape_19.setTransform(31.2,12.9);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-0.4,-0.1,-0.4,-0.1).ss(0.1,1,1,3,true).p("AAAgFIAAAL");
	this.shape_20.setTransform(40.2,22.9);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-7.5,-0.1,7.8,-0.1).ss(0.1,1,1,3,true).p("AhKCWQAlhMAlhKQBKiWABAB");
	this.shape_21.setTransform(14.9,40.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-5.5,0,5.6,0).ss(0.1,1,1,3,true).p("AA3huIhtDd");
	this.shape_22.setTransform(18.7,37.8);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-0.8,0,0.9,0).ss(0.1,1,1,3,true).p("AgHgEIAPAJ");
	this.shape_23.setTransform(23.3,26.1);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-0.4,0,0.5,0).ss(0.1,1,1,3,true).p("AAEANIgHgZ");
	this.shape_24.setTransform(28.7,16.7);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-1.3,-2,2.2,-2).ss(0.1,1,1,3,true).p("AAACLQgBg8gChAQgCiAAJgZ");
	this.shape_25.setTransform(51.9,6.5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-15,-0.2,15.3,-0.2).ss(0.1,1,1,3,true).p("ACYBEQhLgkhMghQiXhGgBAE");
	this.shape_26.setTransform(55.5,29.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-1.3,0,1.3,0).ss(0.1,1,1,3,true).p("AANARIgZgh");
	this.shape_27.setTransform(53.3,22.2);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-1.8,0,1.9,0).ss(0.1,1,1,3,true).p("AgRAKIAjgT");
	this.shape_28.setTransform(1.6,-59.4);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-4,0,4,0).ss(0.1,1,1,3,true).p("AgnBSIBPij");
	this.shape_29.setTransform(25.8,-56.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-5.1,0.3,4.9,0.3).ss(0.1,1,1,3,true).p("AAwhPIhfCf");
	this.shape_30.setTransform(22.9,-57.1);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-4.6,-8.7,11.4,-8.7).ss(0.1,1,1,3,true).p("AA1iGIhpEN");
	this.shape_31.setTransform(59.2,-17.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-9.3,-1.8,10.6,-1.8).ss(0.1,1,1,3,true).p("AhKCgQBjjXAthhQALgYgSA0QgJAagIAY");
	this.shape_32.setTransform(59.9,-23.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-7.5,-0.1,7.6,-0.1).ss(0.1,1,1,3,true).p("ABLAdQiNg1gIgE");
	this.shape_33.setTransform(17.4,-18.4);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-5.1,0,5.1,0).ss(0.1,1,1,3,true).p("AgygTIBkAn");
	this.shape_34.setTransform(19.4,-15.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-1.8,0,1.9,0).ss(0.1,1,1,3,true).p("AgRgCIAjAF");
	this.shape_35.setTransform(19.9,-48.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-0.6,0,0.7,0).ss(0.1,1,1,3,true).p("AgFgHIALAP");
	this.shape_36.setTransform(32.7,-8.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-1.4,0.7,0.6,0.7).ss(0.1,1,1,3,true).p("AAFgDIgCgCQgDABgEAK");
	this.shape_37.setTransform(32.8,-6.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-1.6,0,2,0).ss(0.1,1,1,3,true).p("AgOARQAHgJAHgIQAMgQADAA");
	this.shape_38.setTransform(30.4,-7.3);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-0.2,0,0.3,0).ss(0.1,1,1,3,true).p("AgBAKIADgT");
	this.shape_39.setTransform(24.7,-14.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f().ls(["#2A2521","#5D3719"],[0.012,1],-2.2,0,2.2,0).ss(0.1,1,1,3,true).p("AgVgRIAqAj");
	this.shape_40.setTransform(12.1,-19.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-7.5,1.4,4.8,1.4).ss(0.1,1,1,3,true).p("AguAZQARgRAngRIAlgP");
	this.shape_41.setTransform(23.3,-69.6);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-6.7,0.4,5.5,0.4).ss(0.1,1,1,3,true).p("AA3gMIgzALQgxAKgJAE");
	this.shape_42.setTransform(22.5,-70.8);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-1,0,1,0).ss(0.1,1,1,3,true).p("AAKABIgTgB");
	this.shape_43.setTransform(28.8,-65);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-2.7,0,2.8,0).ss(0.1,1,1,3,true).p("AgaANIA1gZ");
	this.shape_44.setTransform(13,-61.3);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-3.3,0,3.4,0).ss(0.1,1,1,3,true).p("AgggBIBBAD");
	this.shape_45.setTransform(6.9,-60.1);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-3.3,-1.3,7.2,-1.3).ss(0.1,1,1,3,true).p("AAfhEQgNALgZBAQgbBCAFgF");
	this.shape_46.setTransform(2.8,-65.3);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-2.7,0.3,5.8,0.3).ss(0.1,1,1,3,true).p("AAbADQgSAIgSgJQgKgCgHgF");
	this.shape_47.setTransform(9.8,-65.7);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-0.7,-0.7,1.8,-0.7).ss(0.1,1,1,3,true).p("AgDAVQgDgaALgP");
	this.shape_48.setTransform(7.5,-68.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-2.1,-1.3,3.4,-1.3).ss(0.1,1,1,3,true).p("AAGAaQgGgGgDgKQgGgSAPgR");
	this.shape_49.setTransform(17.9,-64.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-1.3,0,1.4,0).ss(0.1,1,1,3,true).p("AgMgCIAZAF");
	this.shape_50.setTransform(17.1,-62.3);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-4,-0.5,4,-0.5).ss(0.1,1,1,3,true).p("AAogEQgPgCgSABQghACgNAJ");
	this.shape_51.setTransform(10,-72.8);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-4.2,0.7,3,0.7).ss(0.1,1,1,3,true).p("AgdANQAJgJAYgIIAagI");
	this.shape_52.setTransform(11,-72);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-5.2,0.3,3.5,0.3).ss(0.1,1,1,3,true).p("AAWgTQgDADgNAQQgKAMgRAI");
	this.shape_53.setTransform(14.8,-67.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f().ls(["#000000","#000000"],[0.012,1],-1,-1.6,2.4,-1.6).ss(0.1,1,1,3,true).p("AAKjWQgJAVgFDNQgDBogCBj");
	this.shape_54.setTransform(-12.4,-15.5);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f().ls(["#000000","#000000"],[0.012,1],-1.3,-1.1,3.1,-1.1).ss(0.1,1,1,3,true).p("AgIAtQgBgRACgUQAEgmAMgO");
	this.shape_55.setTransform(-13.5,-34.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f().ls(["#000000","#000000"],[0.012,1],-6.2,1.1,4.4,1.1).ss(0.1,1,1,3,true).p("AgnAZQANgOAjgSQAbgOAEgD");
	this.shape_56.setTransform(-8.5,-41.5);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f().ls(["#000000","#000000"],[0.012,1],-4.8,1.6,3.6,1.6).ss(0.1,1,1,3,true).p("AAjgiIgeAXQgeAZgJAV");
	this.shape_57.setTransform(-7.9,-40.5);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.lf(["#000000","#000000"],[0,1],-8.4,0,8.4,0).s().p("AgIAAQBJiWABABIASALIhtDcIg6BEIBLiWg");
	this.shape_58.setTransform(15.8,40.6);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.lf(["#000000","#000000"],[0,1],-15.3,0,15.3,0).s().p("AiXg2IAAgNQABgECXBGICYBFg");
	this.shape_59.setTransform(55.5,29.1);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.lf(["#000000","#000000"],[0,1],-8,-3.3,10.9,-3.3).s().p("AhJEaQgDg8gChAQgCiCALgZICQk5QALgXgSAzIgRAyIhpENIAHEZg");
	this.shape_60.setTransform(59.4,-7.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.lf(["#000000","#000000"],[0,1],-2.5,0,2.6,0).s().p("AgPCGIgJgbIAHjOIANgSQANgSADAAIANASIgCgCQgDAAgGANQgJAUgEBzIAHBrg");
	this.shape_61.setTransform(30.8,4.6);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.lf(["#000000","#000000"],[0,1],-7.5,0,7.5,0).s().p("AgegBIgsglQAIAFCNA0IgFAUg");
	this.shape_62.setTransform(17.4,-17.4);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.lf(["#000000","#000000"],[0,1],-5.8,0,5.9,0).s().p("Ag5BMIBfieIAUACIhOCjg");
	this.shape_63.setTransform(23.9,-56.8);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.lf(["#3C3C3C","#4A4A4A"],[0,1],-7.1,-1.1,-8.1,-1.3).s().p("Ah1ANQAbg/ANgLQAMgLAkgCQARgBANACIgXAIQgbAKgIAJQgMAPACAcQAHADAKAEQAUAJASgIQAQgGALgOQANgQADgCQAIgFA0gMIAygLIglAPQgpASgRARQgRAPAHAUQADAKAHAGIgbgIIg1AcIhEgFIglAUIgBAAQgCAAAZg+g");
	this.shape_64.setTransform(13.8,-65.9);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.lf(["#000000","#000000"],[0.008,0.988],-6.3,0,6.4,0).s().p("AgWALQAPgOgBgRIgEgPQgDgCBOgIIgLAOQgMARgCAOQgCAOgVAQQgUAOgKgGQgIgEgUAFIgTAHQAPgKAZgZg");
	this.shape_65.setTransform(50.1,-60);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.lf(["#E6E0E0","#626262","#595959","#000000"],[0.157,0.314,0.349,0.976],-12.2,0.4,-6.8,0.4).s().p("AhZImQgggVAAhCQAKkBgCglQgCgYACikIADliQAAgJgCgUQgBgHAFgEIDHiXIAeAOIg3BCIiHBmIgLLbQgDApAABDQAABCAbAYQAOANAUADIgUACQgbgBgUgOg");
	this.shape_66.setTransform(7.8,8);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.lf(["#000000","#000000"],[0,1],-5.4,-2,5.4,-2).s().p("Ag1ExIAClWIAHk9QgBgRACgUQAEgoANgOQAOgOAigUIAggQIgeAWQgeAbgJAVQgIAVgHDPQgDBogCBgIgCGEIgDBpg");
	this.shape_67.setTransform(-9.8,5.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8}]}).wait(1));

	// Kanister grau
	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-6.6,0.9,3.9,0.9).ss(0.1,1,1,3,true).p("AglAXIBLgt");
	this.shape_68.setTransform(43.4,-61.5);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-3.6,-0.6,5.9,-0.6).ss(0.1,1,1,3,true).p("AAfgOQhAAdADAA");
	this.shape_69.setTransform(32.6,-57.4);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-5,-0.8,7.7,-0.8).ss(0.1,1,1,3,true).p("AgxAQQBHgPAcgQ");
	this.shape_70.setTransform(34.5,-57.5);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-0.7,0,0.8,0).ss(0.1,1,1,3,true).p("AgGAUIANgn");
	this.shape_71.setTransform(37,-53.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-5.3,0.6,2.7,0.6).ss(0.1,1,1,3,true).p("AAagUIgQARQgSAQgRAI");
	this.shape_72.setTransform(38.4,-61);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-0.6,0,0.7,0).ss(0.1,1,1,3,true).p("AAGALIgLgV");
	this.shape_73.setTransform(32.1,-63.5);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-6.7,2.1,3.3,2.1).ss(0.1,1,1,3,true).p("AgfA1QAigXASgrIALgn");
	this.shape_74.setTransform(62.8,-64.5);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-7,-1.6,10.5,-1.6).ss(0.1,1,1,3,true).p("AhFAhQBjgnAoga");
	this.shape_75.setTransform(52.5,-55.8);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-8.4,1.5,4.9,1.5).ss(0.1,1,1,3,true).p("AA6g1IglAkQgHAFgGAGQhQBHATgO");
	this.shape_76.setTransform(58.9,-63.8);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-4.1,-1.1,7.4,-1.1).ss(0.1,1,1,3,true).p("AApgfIgDACQhOA8AAAB");
	this.shape_77.setTransform(49.6,-55.6);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-3.1,0,3.2,0).ss(0.1,1,1,3,true).p("AAfgCIg9AF");
	this.shape_78.setTransform(44.1,-63.5);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-6.6,1.3,3.4,1.3).ss(0.1,1,1,3,true).p("AAhgfIgHAJIgOAOQgYAZgUAP");
	this.shape_79.setTransform(57.1,-62.1);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f().ls(["#9C9B9B","#505050"],[0,1],-2.7,0.5,2.8,0.5).ss(0.1,1,1,3,true).p("AAbgVIgwAoIgEACIgBAB");
	this.shape_80.setTransform(63.3,-67.6);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.lf(["#918E8E","#8F8B8B"],[0.012,1],-9.5,0,9.5,0).s().p("AhUCYICNgjQALgDAGgMIADgNIAIjAIgGgfQgCAAgFgdIAWAqQgEDGgDAUQgBAMgLALQgGAFgEACIifAmg");
	this.shape_81.setTransform(41,3.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.lf(["#918E8E","#8F8B8B"],[0.012,1],-11.5,0,11.5,0).s().p("AgICUQBni3gDABQgFADAIjuIgDgbIgKgMIAFgXIAbAeIgJEdIjaFcIBpi4g");
	this.shape_82.setTransform(16.5,18.1);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.lf(["#9C9B9B","#505050"],[0,1],-17.4,0,17.5,0).s().p("AimC1ICqgmICqlUIilFmQioAlgKAAQgKAAANgRg");
	this.shape_83.setTransform(52.8,-32);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.lf(["#9C9B9B","#505050"],[0,1],-7.8,0,7.9,0).s().p("Ag/ApIAxgmIgbADIAVgaQAAgEAPgTIANgRIBGAeIibBbg");
	this.shape_84.setTransform(12.1,-44.5);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.lf(["#827B7B","#867C7C"],[0.008,1],-4.7,0,4.8,0).s().p("AAbhNIAUAUIg3B7IgmAMQgFgFBOiWg");
	this.shape_85.setTransform(27,-56);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.lf(["#929292","#979292"],[0,0.988],-3.8,0,3.9,0).s().p("AgWgTIA8ASIhLAVg");
	this.shape_86.setTransform(40.1,-53.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.lf(["#797878","#979292"],[0,0.988],-6.6,0,6.7,0).s().p("AgoAsIgLAGQgMAHgCADIAIg3IAegSIBdgzIhJCAg");
	this.shape_87.setTransform(21.1,-59.6);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.lf(["#827B7B","#867C7C"],[0.008,1],-16.6,0.5,15.7,0.5).s().p("AilALQACgBCjgVICmgWIglAiIgEACIkVAfg");
	this.shape_88.setTransform(48.1,-65.8);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.lf(["#9C9B9B","#505050"],[0,1],-8.8,0,8.9,0).s().p("AgZAKQARgJASgPIAQgRIA+gIIhNAuQgaAShIAPQgEAABCgeg");
	this.shape_89.setTransform(38.4,-59.9);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.lf(["#9C9B9B","#BDBBBB"],[0,1],-14.9,0,14.9,0).s().p("Ah2AWIB2gNIAhgeQAAgCA+gIIAyANIAEAFQAAAGgOAEQgWADg3AHIjOAZg");
	this.shape_90.setTransform(51.2,-71.9);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.lf(["#9C9B9B","#505050"],[0,1],-10.2,0.5,10.3,0.5).s().p("AgVAYIACgCQATgQAZgYIAPgPIAHgIIACgBIADgCIAygqIgLAoQgSAsgkAVQgmAbhkApQAAgCBQg9gAAoghIAMgLIgMALg");
	this.shape_91.setTransform(55.8,-61.1);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.lf(["#9C9B9B","#BDBBBB"],[0,1],-8,0,8,0).s().p("Ag9gLQgGAAAegEQAfgFASAAQATAAAaAHIAWAGIieAcg");
	this.shape_92.setTransform(48,-75.5);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.lf(["#9C9B9B","#505050","#3C3A3A"],[0,0.655,1],-10.2,0.6,6.5,0.6).s().p("AgqAyQgEgLgNgKQgMgJgQgFIgOgDQgDgFBGg1IgDAKQABANARAJQARAKATgQIARgSIAqgSIAbgDIgyAmIgqAvIg0AiQAAgEgBgGg");
	this.shape_93.setTransform(0.3,-38.1);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.lf(["#9C9B9B","#505050"],[0,1],-7.8,0,7.8,0).s().p("AgdBGIAPgmIg/gZQgCgDBshSIAoAqIAHAOQAFAPgMAGQgUAIg9BJg");
	this.shape_94.setTransform(-12.4,-43.4);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.lf(["#827B7B","#2B2A2A"],[0.008,1],-10.6,0,10.7,0).s().p("AhaAnQgVgHAIgJQARgPALgMQAOgRAKgEIAIABIAdgLQAdgLAIACQAMACA1AAQAWAAgEAMQgEAKgWAIIgoAOQgWAJgXAPQgbARgSACIgGAAQgOAAgUgGg");
	this.shape_95.setTransform(1.9,-55.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68}]}).wait(1));

	// Kanister 
	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.lf(["#E2E2E2","#8E8E8E","#929292","#B5B3B2","#A9A9A9","#BEB5B5"],[0.012,0.349,0.396,0.537,0.859,0.882],-49.9,0,49.9,0).s().p("AjqLJQgZgCgDgGIhdgqQhhgvgTgWQgSgVAAhuQACh8gCgHQgJgjAApnQAkgwAjgfQAXgUATgOIB7hbQAWg+ARgfQAMgTAogVIAlgRIFegpIB8AcIBuAsIAUAcQAVAoADA4QADA3ABHXIAAHNIgBAPQgEATgHARQgZA1hAALQhnASn4Bvg");
	this.shape_96.setTransform(26.5,-6.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_96).wait(1));

	// Schatten
	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.lf(["rgba(0,0,0,0)","#000000"],[0.008,1],-74,-1.8,74.3,-1.8).s().p("ApXB+QhvgNgZgTQgIgGACgGIADgFIIzjPIOVAGIrdDaQhqANiDALQiiANhoAAQg/AAgqgFg");
	this.shape_97.setTransform(-3,64.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_97).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.2,-78,153.6,155.5);


(lib.flamme3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgfAnIAAhNIAdAAQAIAAAEACQAHACAGAFQAEAFADAIQACAHABAJQgBAKgCAHQgDAIgFAGQgFAEgHACQgFACgGAAgAgQAZIAMAAIAIAAQADgBADgDQADgCACgFQABgFAAgJQAAgIgBgFQgCgEgDgDQgDgDgEgBIgMgBIgHAAg");
	this.shape.setTransform(16,53.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAPAnIgegyIAAAyIgPAAIAAhNIAQAAIAeAzIAAgzIAPAAIAABNg");
	this.shape_1.setTransform(7.9,53.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AAVAnIgGgSIgeAAIgGASIgRAAIAehNIAQAAIAfBNgAAJAIIgJgcIgJAcIASAAg");
	this.shape_2.setTransform(0,53.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AAQAnIgMgRIgGgMIgFgDIgIgBIgDAAIAAAhIgQAAIAAhNIAhAAQALAAAGACQAFACAEAGQADAFABAHQgBAJgFAGQgFADgKACQAFADADAEQAEADAFAJIAKAQgAgSgFIAMAAQAJAAADgBQADgBACgCQABgCAAgEQAAgEgCgCQgCgDgEAAIgJgBIgNAAg");
	this.shape_3.setTransform(-7.5,53.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AggAnIAAhNIAgAAIAMABQAEABAEACQAEADACAEQACAEAAAFQAAAFgDAFQgDAFgFACQAIABADAEQAFAFAAAHQgBAFgCAFQgCAFgFAEQgEADgGAAIgSABgAgQAZIAPAAIAJAAQAEgBACgCQACgDAAgEQAAgDgBgDQgDgCgDgBQgDgCgIAAIgOAAgAgQgHIALAAIAKAAQAEAAACgDQACgCAAgEQAAgEgCgCQgCgCgEgBIgMAAIgJAAg");
	this.shape_4.setTransform(-15.6,53.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 1
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["#B60000","#FF6600"],[0,1],0,63.5,0,-78.6).s().p("AEeHJQA9h1gnhgIimBeQAuhQgghEQgbg6hVg2QhhhCg1hCQg+hOgThoQgZA/ApBwQAjBdBBBZQA5BOgeBFQgbA+hCAFIiehTQhJEEEYCZQirgPh7hcQhzhVgviCQguiBAfiDQAiiJBuhlQgaBAAhBFQAlBLBSACQgcgkgShGQgWhfASheQA2kPFtiZQhMBMgEBYQgCBsBzBSQBYA+AzBBQBDBVgPBGQBag9ANhpQBvBiAlB9QAlB7gmB8QhXERlkB0QB6hmA1hqg");
	this.shape_5.setTransform(0,7.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-57.3,-59,114.7,133.2);


(lib.ende_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgHAJIAAgQIAPAAIAAAQg");
	this.shape.setTransform(-25.8,45.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgBAsQgEgBgCgDQgCgDgBgEIAAgNIAAgbIgIAAIAAgOIAIAAIAAgOIAQgKIAAAYIAMAAIAAAOIgMAAIAAAZIAAAKIACACIADABIAHgCIABAOQgGADgIAAQgEAAgCgCg");
	this.shape_1.setTransform(-29.8,41.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgUAiIAAhBIAQAAIAAAJQAEgHACgCQADgCAFAAQAGAAAFAEIgFAPQgFgDgDAAQgEAAgDACQgBACgBAFQgBAGAAAPIAAAVg");
	this.shape_2.setTransform(-34,42.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgQAfQgJgFgEgIQgFgIABgKQgBgIAFgJQAEgIAJgEQAHgFAJAAQAPAAAJAKQAKAKAAAOQAAAPgKAKQgJAKgPAAQgHAAgJgEgAgLgOQgEAGAAAIQAAAKAEAFQAGAFAFAAQAGAAAFgFQAFgFAAgKQAAgIgFgGQgFgFgGAAQgFAAgGAFg");
	this.shape_3.setTransform(-40.9,42.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgLAvIAAg0IgKAAIAAgOIAKAAIAAgFQAAgIACgEQABgFAFgCQADgDAHAAQAIAAAHACIgCANIgIgBQgEAAgCACQgBABAAAGIAAAEIANAAIAAAOIgNAAIAAA0g");
	this.shape_4.setTransform(-46.8,41.3);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgUAlQgJgLAAgaQAAgZAJgMQAIgJAMAAQANAAAIAJQAJAMAAAZQAAAagKAMQgHAJgNAAQgMAAgIgKgAgEgdQgDACgBAFQgCAHAAAPQAAAQACAGQABAGADACQACACACAAQADAAACgCQADgCABgFQACgHAAgQQAAgPgCgGQgBgGgDgCQgCgCgDAAQgCAAgCACg");
	this.shape_5.setTransform(-56.4,41.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgHAJIAAgQIAPAAIAAAQg");
	this.shape_6.setTransform(-61.8,45.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgeAuQACgJAFgJQAEgIAPgOQALgJACgEQAEgGAAgFQAAgGgDgDQgDgDgGAAQgEAAgDADQgDADgBAIIgSgCQACgOAJgHQAHgGALAAQAOAAAIAHQAIAIAAALQAAAGgCAGQgDAFgFAFIgLALIgKALIgDAFIAiAAIAAAQg");
	this.shape_7.setTransform(-67.3,41.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_8.setTransform(-78,42.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgHAuIAAhBIAPAAIAABBgAgHgcIAAgRIAPAAIAAARg");
	this.shape_9.setTransform(-83.4,41.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgHAuIAAhbIAPAAIAABbg");
	this.shape_10.setTransform(-87,41.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgQAfQgJgFgEgIQgEgIgBgKQABgIAEgJQAEgIAIgEQAJgFAIAAQAOAAALAKQAKAKAAAOQAAAPgKAKQgLAKgOAAQgIAAgIgEgAgKgOQgFAGAAAIQAAAKAFAFQAEAFAGAAQAGAAAFgFQAFgFAAgKQAAgIgFgGQgFgFgGAAQgGAAgEAFg");
	this.shape_11.setTransform(-92.7,42.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgfAuIAAhbIA+AAIAAAQIgrAAIAAAWIAlAAIAAAOIglAAIAAAng");
	this.shape_12.setTransform(-100.4,41.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgUAiIAAhBIAQAAIAAAJQAEgHACgCQADgCAFAAQAGAAAFAEIgFAPQgFgDgDAAQgEAAgDACQgBACgBAFQgBAGAAAPIAAAVg");
	this.shape_13.setTransform(-110.2,42.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_14.setTransform(-116.9,42.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgXAlQgIgJAAgRQAAgPAIgJQAIgJAMAAQAJAAAJAKIAAgiIARAAIAABbIgQAAIAAgKQgEAGgGADQgGADgDAAQgMAAgIgKgAgJgDQgEADAAAKQAAALADAFQAEAHAGAAQAGAAAEgGQAFgFAAgKQAAgMgFgDQgEgFgGAAQgFAAgEAFg");
	this.shape_15.setTransform(-124.5,41.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgBAsQgEgBgCgDQgCgDgBgEIAAgNIAAgbIgIAAIAAgOIAIAAIAAgOIAQgKIAAAYIAMAAIAAAOIgMAAIAAAZIAAAKIACACIADABIAHgCIABAOQgGADgIAAQgEAAgCgCg");
	this.shape_16.setTransform(-134.1,41.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgHAuIAAhBIAPAAIAABBgAgHgcIAAgRIAPAAIAAARg");
	this.shape_17.setTransform(-138,41.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AAfAiIAAgkQAAgKgCgEQgCgEgFABQgEAAgDACQgEADgBADQgBAFAAAIIAAAgIgQAAIAAgjQAAgKgBgCQgBgEgCgBQgCgBgDAAQgEAAgEACQgEACgBAEQgBAEAAAIIAAAhIgSAAIAAhBIAQAAIAAAJQAJgLAMAAQAHAAAEADQADADADAFQAFgFAFgDQAFgDAGAAQAIAAAEADQAGADACAGQACAFAAAJIAAApg");
	this.shape_18.setTransform(-145.6,42.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_19.setTransform(-158.6,42.7);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgHAuIAAhBIAPAAIAABBgAgHgcIAAgRIAPAAIAAARg");
	this.shape_20.setTransform(-164,41.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgZAnQgJgHgCgQIASgCQABAJAFAEQAFAFAHAAQAKAAAEgEQAEgEAAgFQAAgEgBgBQgCgDgFgCIgNgEQgQgDgGgEQgIgIAAgKQAAgIAEgGQAEgGAIgEQAIgCAJAAQARgBAJAIQAIAIABANIgTABQgCgIgDgDQgEgDgHAAQgHAAgFAEQgDACAAADQAAADADACQADADAMAEQAOADAHADQAGAEAEAEQADAGAAAJQAAAIgEAHQgEAHgJADQgIADgMAAQgQAAgJgIg");
	this.shape_21.setTransform(-170.2,41.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AANAiIAAgiQAAgJgCgDQgBgDgCgDQgDgBgDAAQgDAAgEACQgDADgCAEQgBAEAAAKIAAAeIgSAAIAAhBIARAAIAAAKQAIgMAMAAQAGAAAFACQAEACADADQACAEABAEIABAMIAAAog");
	this.shape_22.setTransform(-182,42.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_23.setTransform(-189.6,42.7);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgUAiIAAhBIAQAAIAAAJQAEgHACgCQADgCAFAAQAGAAAFAEIgFAPQgFgDgDAAQgEAAgDACQgBACgBAFQgBAGAAAPIAAAVg");
	this.shape_24.setTransform(-195.2,42.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AANAuIAAgkQAAgKgBgBQgBgDgEgCQgCgBgDAAQgDAAgDACQgEACgCADQgCADAAAJIAAAiIgRAAIAAhbIARAAIAAAiQAJgKAKAAQAGAAAGADQAFACACADQADADABAFIAAAMIAAAng");
	this.shape_25.setTransform(-202.1,41.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgYAdQgGgGAAgIQAAgGADgEQACgFAFAAQAFgDAJgBIAQgFIAAgCQAAgFgDgCQgCgCgFAAQgFAAgDACQgCACgCAEIgQgDQACgJAHgFQAHgFAMAAQALAAAGADQAGADACAEQACAFAAALIAAATIABANIADAJIgRAAIgCgFIgBgCQgEAEgGADQgDACgGAAQgKAAgGgGgAAAAEQgHABgCACQgDACAAAEQAAAEADACQACADAFAAQACAAAFgDQADgCABgEIABgJIAAgDg");
	this.shape_26.setTransform(-209.7,42.7);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgLAvIAAg0IgKAAIAAgOIAKAAIAAgFQAAgIACgEQABgFAFgCQADgDAHAAQAIAAAHACIgCANIgIgBQgEAAgCACQgBABAAAGIAAAEIANAAIAAAOIgNAAIAAA0g");
	this.shape_27.setTransform(-215.2,41.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgXAXQgHgJAAgOQAAgPAJgJQAIgKANAAQAOAAAJAKQAIAKAAATIgrAAQAAAIAEAEQAFAEAEAAQAEAAADgCQADgCABgFIASADQgEAKgHAFQgHAFgLAAQgQAAgIgMgAANgEQAAgIgEgEQgEgEgFAAQgEAAgEAEQgEAEAAAIIAZAAIAAAAg");
	this.shape_28.setTransform(-224.8,42.7);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AgBAsQgEgBgCgDQgCgDgBgEIAAgNIAAgbIgIAAIAAgOIAIAAIAAgOIAQgKIAAAYIAMAAIAAAOIgMAAIAAAZIAAAKIACACIADABIAHgCIABAOQgGADgIAAQgEAAgCgCg");
	this.shape_29.setTransform(-230.5,41.6);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgBAsQgEgBgCgDQgCgDgBgEIAAgNIAAgbIgIAAIAAgOIAIAAIAAgOIAQgKIAAAYIAMAAIAAAOIgMAAIAAAZIAAAKIACACIADABIAHgCIABAOQgGADgIAAQgEAAgCgCg");
	this.shape_30.setTransform(-234.8,41.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgHAuIAAhBIAPAAIAABBgAgHgcIAAgRIAPAAIAAARg");
	this.shape_31.setTransform(-238.8,41.4);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgmAuIAAhbIAlAAIAPABQAGABAEACQAEAEADAEQADAGAAAFQAAAHgEAGQgDAFgGADQAIABAFAFQAEAGAAAIQAAAGgCAHQgEAGgEADQgGADgHABIgVABgAgTAeIARAAIAMAAQAEgBADgDQACgDAAgFQAAgEgCgDQgCgDgEgBQgEgBgLAAIgPAAgAgTgIIANAAIALAAQAFgBADgCQACgDAAgFQAAgEgCgDQgCgCgFgBIgOAAIgLAAg");
	this.shape_32.setTransform(-245.1,41.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer 2
	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.lf(["rgba(255,255,255,0.4)","rgba(255,255,255,0.086)"],[0,1],-264.2,-28.4,-264.2,7.6).s().p("EgyGADeQhpAAAAhkIAAjzQAAhkBpAAMBkMAAAQBpAAABBkIAADzQgBBkhpAAg");
	this.shape_33.setTransform(-137.1,42.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_33).wait(1));

	// Ebene 1
	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#D0DB8F").s().p("EgysAD8QhkAAAAhkIAAkvQAAhkBkAAMBlZAAAQBkAAAABkIAAEvQAABkhkAAg");
	this.shape_34.setTransform(-137.3,42.6);

	this.timeline.addTween(cjs.Tween.get(this.shape_34).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-471.8,17.3,669.1,50.5);


(lib.sauerstoff = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgZAnIAAhNIA0AAIAAANIgkAAIAAATIAeAAIAAALIgeAAIAAAig");
	this.shape.setTransform(121.4,-25.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgaAnIAAhNIA0AAIAAANIgkAAIAAATIAgAAIAAALIggAAIAAAig");
	this.shape_1.setTransform(114.7,-25.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbAdQgKgKAAgTQABgKADgIQACgGAFgFQAFgFAFgCQAIgDAIAAQARAAAKAKQALALAAASQAAATgLAKQgKALgRAAQgQAAgLgLgAgOgTQgHAHABAMQAAANAGAHQAGAHAIAAQAJAAAGgHQAGgHAAgNQAAgMgGgHQgFgHgKAAQgIAAgGAHg");
	this.shape_2.setTransform(107,-25.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgHAnIAAhAIgXAAIAAgNIA9AAIAAANIgYAAIAABAg");
	this.shape_3.setTransform(99.3,-25.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgVAhQgIgHgCgNIAQgBQABAHAFAEQAEAEAFAAQAIAAADgEQAFgDAAgEQAAgBgBAAQAAgBAAgBQAAAAAAgBQgBAAAAgBQgBgCgFgBIgKgEQgNgDgFgDQgIgGABgJQgBgGAEgGQADgFAGgDQAHgCAIAAQAOAAAHAGQAIAHAAALIgPAAQgCgGgDgCQgEgDgFAAQgGAAgEADQgDABAAAEQAAACADACQADADAJADQAMACAFADQAGADADADQADAFABAIQgBAHgEAFQgDAGgHADQgHADgKAAQgNAAgIgHg");
	this.shape_4.setTransform(92.3,-25.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAQAnIgMgRIgGgMIgFgDIgIgBIgDAAIAAAhIgQAAIAAhNIAhAAQALAAAGACQAGACADAGQADAFABAHQgBAJgFAGQgFADgLACQAGADADAEQADADAGAJIAKAQgAgSgFIAMAAQAJAAADgBQADgBACgCQABgCAAgEQAAgEgCgCQgCgDgEAAIgJgBIgNAAg");
	this.shape_5.setTransform(85.1,-25.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgdAnIAAhNIA5AAIAAANIgoAAIAAASIAlAAIAAALIglAAIAAAVIAqAAIAAAOg");
	this.shape_6.setTransform(77.3,-25.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgPAlQgFgDgEgEQgDgEgBgFQgCgHAAgNIAAgoIAQAAIAAApIABANQABAFAEADQADADAFAAQAHAAADgDQAEgDAAgEIABgNIAAgqIAQAAIAAAoIgBATQgCAHgDADQgEAFgFACQgGADgKgBQgJABgGgDg");
	this.shape_7.setTransform(69.5,-25.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAWAnIgHgSIgdAAIgHASIgRAAIAehNIAPAAIAgBNgAAKAIIgKgcIgKAcIAUAAg");
	this.shape_8.setTransform(61.6,-25.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgVAhQgIgHgBgNIAPgBQABAHAEAEQAFAEAFAAQAIAAAEgEQADgDAAgEQAAgBAAAAQAAgBAAgBQAAAAAAgBQgBAAAAgBQgCgCgEgBIgLgEQgNgDgFgDQgHgGAAgJQABgGADgGQADgFAHgDQAGgCAIAAQAOAAAIAGQAHAHAAALIgQAAQgBgGgDgCQgEgDgFAAQgGAAgEADQgDABABAEQgBACADACQADADAKADQALACAGADQAFADAEADQACAFAAAIQAAAHgDAFQgEAGgHADQgHADgKAAQgNAAgIgHg");
	this.shape_9.setTransform(54,-25.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Ebene 1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_10.setTransform(165.2,-4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_11.setTransform(161,-2.9);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgCgDQgBgCAAgJIAAgfIgHAAIAAgIIAHAAIAAgNIAIgGIAAATIAKAAIAAAIIgKAAIAAAgIAAAEIACACIAEABIAEAAIABAIIgHACQgGgBAAgCg");
	this.shape_12.setTransform(156.5,-3.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgCgDQgBgCAAgJIAAgfIgHAAIAAgIIAHAAIAAgNIAIgGIAAATIAKAAIAAAIIgKAAIAAAgIAAAEIADACIADABIAEAAIACAIIgIACQgFgBgBgCg");
	this.shape_13.setTransform(153.5,-3.8);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_14.setTransform(150.7,-4);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAcAdIAAgiIgBgJQgBgCgCgCQgDgBgDAAQgFAAgEAEQgEAEAAAJIAAAfIgJAAIAAgjQAAgHgCgDQgCgDgGAAQgEAAgDACQgDACgCAEQgCAEABAHIAAAdIgKAAIAAg3IAJAAIAAAIQACgEAEgDQAFgDAGAAQAGAAAEADQACADACAEQAHgKAKAAQAJAAAFAFQAEAFAAAKIAAAlg");
	this.shape_15.setTransform(144.9,-3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgPAZQgGgFgBgJIAJgBQABAFAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgDACgEIAFgFIAGgDQAEgCAEAAQAFABAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgDgFAAQgGAAgDADQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAEgFADQgFADgHgBQgJAAgGgEg");
	this.shape_16.setTransform(137.5,-2.9);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_17.setTransform(131.8,-3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgSAVQgHgHAAgOQAAgPAJgHQAHgHAJAAQALABAIAHQAHAIAAANQAAAJgDAHQgDAHgHADQgGADgHAAQgKABgIgJgAgKgPQgFAGAAAJQAAALAFAFQAEAGAGgBQAHABAFgGQAEgFAAgLQAAgKgEgFQgFgGgHAAQgGAAgEAGg");
	this.shape_18.setTransform(125.6,-2.9);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_19.setTransform(121.4,-4);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgBgDQgBgCAAgJIAAgfIgHAAIAAgIIAHAAIAAgNIAHgGIAAATIAKAAIAAAIIgKAAIAAAgIABAEIACACIACABIAFAAIACAIIgIACQgGgBAAgCg");
	this.shape_20.setTransform(118.8,-3.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgUAZQgFgFAAgHQAAgEACgEIAFgFIAHgCIAJgBIAPgDIAAgCQAAgHgDgCQgDgEgHAAQgGAAgDADQgDACgCAHIgJgCQABgGADgEQADgDAGgCQAFgCAGgBQAHABAEACQAFABACACIADAIIABAIIAAALIAAARIADAHIgKAAIgCgHQgGAFgFACQgDABgFAAQgKAAgFgEgAgBADIgIACIgEADIgBAEQAAAFACACQADADAGgBQAEAAAEgCQAEgCACgFQACgDAAgGIAAgDQgFACgJABg");
	this.shape_21.setTransform(114.1,-2.9);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgLAkQgGgEgDgHQgDgHAAgIQAAgJACgFQAEgHAFgDQAGgEAGgBQAEAAAEADQAEACACADIAAgcIAKAAIAABNIgIAAIAAgHQgGAIgKAAQgGAAgFgDgAgJgFQgEAFgBAKQAAALAGAFQAEAGAEgBQAGABAFgGQAFgFAAgKQAAgLgFgFQgFgGgGAAQgFAAgEAGg");
	this.shape_22.setTransform(107.8,-3.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_23.setTransform(103.8,-4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AAPAcIgNgSIgCgFIgOAXIgLAAIAUgcIgTgbIAMAAIAJANIADAHIADgHIAKgNIAMAAIgUAbIAVAcg");
	this.shape_24.setTransform(99.8,-2.9);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgSAjQgJgGgFgJQgEgJAAgLQAAgRAKgLQALgLAPAAQAKAAAJAFQAJAFAFAJQAEAKAAAKQAAALgEAKQgGAJgJAFQgIAFgKAAQgJAAgJgFgAgRgXQgJAIAAAQQABAOAHAIQAIAIAKAAQALAAAIgIQAHgIAAgPQAAgIgDgHQgDgIgGgDQgHgEgHAAQgJAAgIAHg");
	this.shape_25.setTransform(92.8,-4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgPAZQgGgFgBgJIAJgBQABAFAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgDACgEIAFgFIAGgDQAEgCAEAAQAFABAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgDgFAAQgGAAgDADQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAEgFADQgFADgHgBQgJAAgGgEg");
	this.shape_26.setTransform(82.7,-2.9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_27.setTransform(78.7,-4);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgUAZQgFgFAAgHQAAgEACgEIAFgFIAHgCIAJgBIAPgDIAAgCQAAgHgDgCQgDgEgHAAQgGAAgDADQgDACgCAHIgJgCQABgGADgEQADgDAGgCQAFgCAGgBQAHABAEACQAFABACACIADAIIABAIIAAALIAAARIADAHIgKAAIgCgHQgGAFgFACQgDABgFAAQgKAAgFgEgAgBADIgIACIgEADIgBAEQAAAFACACQADADAGgBQAEAAAEgCQAEgCACgFQACgDAAgGIAAgDQgFACgJABg");
	this.shape_28.setTransform(74.5,-2.9);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgCgDQgBgCAAgJIAAgfIgHAAIAAgIIAHAAIAAgNIAIgGIAAATIAKAAIAAAIIgKAAIAAAgIAAAEIACACIAEABIAEAAIABAIIgHACQgGgBAAgCg");
	this.shape_29.setTransform(67,-3.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgHAnIAAgvIgIAAIAAgIIAIAAIAAgGIABgIQACgEADgCQACgCAGAAIAJABIgBAIIgGAAQgEAAgCABQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAvg");
	this.shape_30.setTransform(64.1,-4);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgMAbQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCg");
	this.shape_31.setTransform(59.2,-2.8);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgXAnIAAhNIAKAAIAABDIAlAAIAAAKg");
	this.shape_32.setTransform(53.4,-4);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgEAAQgDAAgCACQgCACAAAEQgCAFAAAFIAAAdg");
	this.shape_33.setTransform(45.7,-3);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_34.setTransform(40.3,-2.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgLAkQgGgEgDgHQgDgHAAgIQAAgJADgFQADgHAFgDQAGgEAGgBQAEAAAEADQAEACACADIAAgcIAKAAIAABNIgJAAIAAgHQgFAIgKAAQgFAAgGgDgAgJgFQgFAFABAKQAAALAEAFQAFAGAEgBQAGABAFgGQAEgFAAgKQAAgLgEgFQgFgGgGAAQgFAAgEAGg");
	this.shape_35.setTransform(34.1,-3.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgPAZQgGgFgBgJIAJgBQABAFAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgDACgEIAFgFIAGgDQAEgCAEAAQAFABAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgDgFAAQgGAAgDADQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAEgFADQgFADgHgBQgJAAgGgEg");
	this.shape_36.setTransform(25.4,-2.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgMAbQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCg");
	this.shape_37.setTransform(19.6,-2.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgUAZQgFgFAAgHQAAgEACgEIAFgFIAHgCIAJgBIAPgDIAAgCQAAgHgDgCQgDgEgHAAQgGAAgDADQgDACgCAHIgJgCQABgGADgEQADgDAGgCQAFgCAGgBQAHABAEACQAFABACACIADAIIABAIIAAALIAAARIADAHIgKAAIgCgHQgGAFgFACQgDABgFAAQgKAAgFgEgAgBADIgIACIgEADIgBAEQAAAFACACQADADAGgBQAEAAAEgCQAEgCACgFQACgDAAgGIAAgDQgFACgJABg");
	this.shape_38.setTransform(13.5,-2.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	// Ebene 5
	this.instance = new lib.sauerstoffblase();
	this.instance.setTransform(128.9,36.5,3,3);

	this.instance_1 = new lib.sauerstoffblase();
	this.instance_1.setTransform(84.5,60.8,3,3);

	this.instance_2 = new lib.sauerstoffblase();
	this.instance_2.setTransform(32,45.5,3,3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_2},{t:this.instance_1},{t:this.instance}]}).wait(1));

	// Ebene 4
	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("rgba(0,0,0,0.702)").s().p("AtqLUQhjAAgBhkIAAzfQABhkBjAAIbVAAQBjAAABBkIAATfQgBBkhjAAg");
	this.shape_39.setTransform(88.2,27.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_39).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.3,-45.1,195,145);


(lib.rahmen_layout = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 1
	this.instance = new lib.rahmen_neu("synched",0);
	this.instance.setTransform(371.4,272.1,1,1,0,0,0,371.4,272.1);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#808080").ss(1,1,1).p("EA16ABkMhrzAAAIAAjHMBrzAAAIAAC7g");
	this.shape.setTransform(374.5,97);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#AAAAAA").ss(1,1,1).p("AABAAIgBAA");
	this.shape_1.setTransform(719.6,105.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,750,108);


(lib.gruen_coach_zeigen_3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 3
	this.shape = new cjs.Shape();
	this.shape.graphics.lf(["rgba(0,0,0,0.498)","rgba(0,0,0,0)"],[0,1],-4.5,2.7,-4,-0.7).s().p("AgxAUIAAgnIBjAAIgZAnIhKAAg");
	this.shape.setTransform(46.9,87.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.lf(["rgba(0,0,0,0.498)","rgba(0,0,0,0)"],[0,1],-4.5,2.7,-4,-0.7).s().p("AgxAUIAAgnIBjAAIgZAnIhKAAg");
	this.shape_1.setTransform(46.9,49.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Ebene 3
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.lf(["#5A7F00","#739F00"],[0,1],24.3,0.4,-19.1,0.4).s().p("AguCtQgJAAADgCQACgBgSgBQgfAAgdgOQg0gYgUg4QgUg3AZgyQAZg1A4gTQAKgEAMgDIAuAAIAAhBIBPAAQAmAAAlARQBCAfAYBFQAaBDgfBDQggBBhFAZQgPAFgOADIgKAAIhjgCg");
	this.shape_2.setTransform(46.6,101);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.lf(["#5A7F00","#739F00"],[0,1],24.3,0.4,-19.1,0.4).s().p("AAlCvIhTgCQgJAAADgCQACgBgSgBQgfAAgdgOQg0gYgUg4QgUg3AZgyQAZg1A4gTQAKgEAMgDIAuAAIAAhBIBPAAQAmAAAlARQBCAfAYBFQAaBDgfBDQggBBhFAZQgPAFgOADIgHAAIgTAAg");
	this.shape_3.setTransform(46.6,63);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.lf(["rgba(255,255,255,0.6)","rgba(255,255,255,0)"],[0,1],-0.3,-10.6,0.4,10.6).s().p("AhsBKQgugcgCgqQgBgoAtgfQAtgfBCgCQA/gCAvAcQAvAcABArQABAogtAeQgtAghBACIgHAAQg8AAgsgbg");
	this.shape_4.setTransform(91.6,20.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2}]}).wait(1));

	// Ebene 1
	this.instance = new lib.krawatte_zeigen_3();
	this.instance.setTransform(67.4,103,1,1,0,0,180,11.3,43.3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Layer 7
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.lf(["rgba(255,255,255,0.6)","rgba(255,255,255,0)"],[0,1],8.1,-33,-38.3,22.6).s().p("AkMoYIAIAIQCNBzBhBRQBgBQCLB0QAQALAOATQAfAngGAuQAAALgEAKQgDAIgEAIIoNIJg");
	this.shape_5.setTransform(68.8,92.3);

	this.timeline.addTween(cjs.Tween.get(this.shape_5).wait(1));

	// Layer 6
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.lf(["#537601","#739F00"],[0,1],-2.8,-36.2,-124.1,112.4).s().p("AklpHIAMALQB5BjCKByQCIByB2BjQAUAOAPAWQAiAvgJA6QgDANgFANQgFALgFAKIo3Ieg");
	this.shape_6.setTransform(71.3,92.4);

	this.timeline.addTween(cjs.Tween.get(this.shape_6).wait(1));

	// Ebene 4
	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.rf(["#739F00","#537601"],[0,1],-3.9,6.1,0,-3.9,6.1,26.5).s().p("AitDFQgPgOgNgPQg2hAgGhYQgDgtAMgqQAQg3AoguQBIhSBtgHQBrgHBRBIQAeAaAUAgQAiA2AFBFQAHBrhIBRQgpAug0AWQgoARgwAEIgQAAQhiAAhLhBg");
	this.shape_7.setTransform(90.6,33.5);

	this.timeline.addTween(cjs.Tween.get(this.shape_7).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(25.6,7.2,91.3,143.7);


(lib.brennstoff = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Ebene 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgaAnIAAhNIA0AAIAAANIgkAAIAAATIAgAAIAAALIggAAIAAAig");
	this.shape.setTransform(121.7,-25.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgZAnIAAhNIA0AAIAAANIgkAAIAAATIAeAAIAAALIgeAAIAAAig");
	this.shape_1.setTransform(115,-25.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgaAdQgLgKAAgTQAAgKAEgIQADgGAEgFQAFgFAGgCQAGgDAJAAQARAAAKAKQALALAAASQAAATgKAKQgLALgRAAQgQAAgKgLgAgOgTQgHAHAAAMQABANAGAHQAGAHAIAAQAJAAAGgHQAGgHAAgNQAAgMgGgHQgGgHgJAAQgJAAgFAHg");
	this.shape_2.setTransform(107.3,-25.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgHAnIAAhAIgXAAIAAgNIA9AAIAAANIgYAAIAABAg");
	this.shape_3.setTransform(99.6,-25.9);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgVAhQgIgHgBgNIAPgBQACAHADAEQAFAEAFAAQAIAAAEgEQADgDAAgEQAAgBAAAAQAAgBAAgBQAAAAAAgBQgBAAAAgBQgCgCgEgBIgKgEQgOgDgEgDQgIgGAAgJQABgGADgGQADgFAHgDQAGgCAIAAQAOAAAIAGQAHAHAAALIgPAAQgCgGgDgCQgEgDgFAAQgGAAgEADQgDABABAEQgBACADACQADADAKADQALACAGADQAFADAEADQADAFAAAIQAAAHgFAFQgDAGgHADQgHADgKAAQgNAAgIgHg");
	this.shape_4.setTransform(92.6,-25.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAPAnIgegyIAAAyIgPAAIAAhNIAQAAIAeAzIAAgzIAPAAIAABNg");
	this.shape_5.setTransform(85,-25.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAPAnIgegyIAAAyIgPAAIAAhNIAQAAIAeAzIAAgzIAPAAIAABNg");
	this.shape_6.setTransform(77.1,-25.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgcAnIAAhNIA4AAIAAANIgpAAIAAASIAmAAIAAALIgmAAIAAAVIAqAAIAAAOg");
	this.shape_7.setTransform(69.7,-25.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AAQAnIgLgRIgHgMIgFgDIgIgBIgDAAIAAAhIgQAAIAAhNIAhAAQALAAAGACQAFACAEAGQADAFAAAHQABAJgGAGQgFADgLACQAGADADAEQADADAGAJIAKAQgAgSgFIALAAQAKAAADgBQADgBABgCQACgCAAgEQAAgEgCgCQgCgDgEAAIgKgBIgMAAg");
	this.shape_8.setTransform(62.3,-25.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AggAnIAAhNIAgAAIAMABQAEABAEACQAEADACAEQACAEABAFQAAAFgDAFQgEAFgEACQAHABAEAEQADAFAAAHQAAAFgCAFQgDAFgEAEQgEADgHAAIgRABgAgPAZIAOAAIAJAAQADgBADgCQACgDAAgEQAAgDgCgDQgCgCgCgBQgEgCgJAAIgMAAgAgPgHIAKAAIAJAAQAFAAACgDQACgCAAgEQAAgEgCgCQgCgCgEgBIgLAAIgJAAg");
	this.shape_9.setTransform(54.2,-25.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Ebene 1
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgQAkQgGgFAAgJIAKABQAAAFADACQAEACAFAAQAFAAAEgCQAEgDABgFIABgMQgHAHgIAAQgLAAgGgIQgHgJAAgKQAAgIADgHQADgHAGgDQAFgEAHAAQAJAAAHAIIAAgHIAJAAIAAAwQAAANgDAFQgDAGgGADQgGADgHAAQgJAAgHgEgAgJgaQgFAFAAALQAAAKAFAEQAEAFAFAAQAHAAAEgFQAFgEAAgKQAAgKgFgGQgFgFgGAAQgFAAgEAFg");
	this.shape_10.setTransform(92.6,63.4);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_11.setTransform(86.7,62.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgMAbQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCg");
	this.shape_12.setTransform(80.5,62.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AALAnIgQgdIgHAGIAAAXIgKAAIAAhNIAKAAIAAArIAUgVIANAAIgVATIAXAkg");
	this.shape_13.setTransform(75.1,61.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgEgDgEAAQgCAAgCACQgBACgCAEQgBAFAAAFIAAAdg");
	this.shape_14.setTransform(70.6,62.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_15.setTransform(67.2,61.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAKAcIgJggIgBgKIgKAqIgKAAIgRg3IAKAAIAJAfIADAMIACgLIAKggIAHAAIAJAfIADALIADgLIAKgfIAJAAIgSA3g");
	this.shape_16.setTransform(62,62.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAFAAAFACQAEACACADIADAHIABAKIAAAhg");
	this.shape_17.setTransform(55,62.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_18.setTransform(50.8,61.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFAAAEgEQADgCADgHIAKACQgDAJgGAEQgHAFgKABQgKgBgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_19.setTransform(46.5,62.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAEQAEAFAGABQAFAAAEgEQADgCADgHIAKACQgDAJgGAEQgHAFgKABQgKgBgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_20.setTransform(40.4,62.3);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAdAdIAAgiIgBgJQgCgCgCgCQgDgBgCAAQgGAAgFAEQgEAEAAAJIAAAfIgHAAIAAgjQAAgHgCgDQgDgDgFAAQgFAAgDACQgEACgBAEQgBAEgBAHIAAAdIgJAAIAAg3IAIAAIAAAIQADgEAFgDQAEgDAGAAQAGAAAEADQACADACAEQAHgKALAAQAIAAAEAFQAFAFAAAKIAAAlg");
	this.shape_21.setTransform(32.8,62.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgEgDgEAAQgDAAgBACQgCACgBAEQgBAFAAAFIAAAdg");
	this.shape_22.setTransform(26.8,62.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgUAjQgFgFAAgHQAAgEACgDIAFgGIAHgDIAJgCIAPgDIAAgCQAAgEgDgDQgDgDgHAAQgGAAgDACQgDADgCAFIgJgBQABgGADgDQADgEAGgCQAFgCAGAAQAHAAAEACQAFABACADIADAHIABAGIAAANIAAARIADAHIgKAAIgCgHQgGAFgFACQgDACgFAAQgKAAgFgFgAgBANIgIACIgEADIgBAFQAAAEACACQADADAGAAQAEAAAEgCQAEgDACgEQACgDAAgHIAAgDQgFACgJABgAAEgcIAAgLIALAAIAAALgAgOgcIAAgLIALAAIAAALg");
	this.shape_23.setTransform(21.5,61.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AATAnIgRg6IgCgJIgBAJIgQA6IgMAAIgUhNIAKAAIANAyIADAQIADgPIAPgzIALAAIALAmQAFAPABANIAFgRIALgxIALAAIgWBNg");
	this.shape_24.setTransform(13.3,61.2);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AANAnIAAgkQAAgGgDgDQgDgDgGAAQgCAAgEACQgEACgCAEQgBACAAAHIAAAfIgKAAIAAhNIAKAAIAAAcQAGgIAJAAQAGAAAFADQAEACACAFQACAEAAAHIAAAkg");
	this.shape_25.setTransform(163.5,44.9);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgQAWQgHgIAAgOQAAgIADgHQADgGAGgEQAGgEAGABQAJAAAGAEQAGAFABAJIgJABQgBgGgEgDQgDgCgFAAQgFgBgFAGQgFAFAAAKQAAALAFAFQAEAGAFAAQAGAAAEgEQAEgEABgHIAJABQgBAKgHAGQgGAGgKgBQgJAAgHgHg");
	this.shape_26.setTransform(157.9,46);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgEAAQgEAAgBACQgCACAAAEQgCAFAAAFIAAAdg");
	this.shape_27.setTransform(153.6,45.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgMAbQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCg");
	this.shape_28.setTransform(148.2,46.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgLAjQgGgDgDgHQgDgGAAgKQAAgIADgFQADgHAFgEQAGgDAGAAQAEgBAEADQAEACADAEIAAgcIAJAAIAABMIgIAAIAAgHQgGAJgKgBQgFAAgGgEgAgJgFQgFAFABAJQAAAMAEAFQAFAGAEAAQAGAAAFgGQAEgFABgLQgBgKgEgFQgFgGgGABQgFgBgEAGg");
	this.shape_29.setTransform(142,45);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAFQAEAEAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_30.setTransform(133,46);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgDAGABIAJABIgBAIIgGAAQgEgBgCACQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_31.setTransform(128.7,44.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgDAGABIAJABIgBAIIgGAAQgEgBgCACQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_32.setTransform(125.6,44.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgSAWQgHgIAAgOQAAgOAJgIQAHgGAJAAQALgBAIAJQAHAHAAANQAAAKgDAGQgDAGgHAEQgGADgHAAQgKAAgIgHgAgKgPQgFAFAAAKQAAALAFAFQAEAGAGAAQAHAAAFgGQAEgGAAgKQAAgKgEgFQgFgGgHABQgGgBgEAGg");
	this.shape_33.setTransform(120.8,46);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AAAAlQgDgCgBgDQgCgDAAgIIAAgfIgGAAIAAgIIAGAAIAAgNIAIgHIAAAUIAKAAIAAAIIgKAAIAAAgIABAFIACACIACAAIAFAAIACAJIgIABQgFAAgBgCg");
	this.shape_34.setTransform(116.3,45.1);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgOAlQgHgDgEgGQgFgHAAgIIAKAAQABAGACADQADAEAFACQAGADAEAAQAGAAAFgCQAEgCADgDQACgDAAgEQAAgDgCgDQgCgDgFgCIgMgEIgQgCQgFgDgDgFQgDgEAAgGQAAgGAEgFQADgFAGgDQAHgCAHAAQAIAAAGADQAHACAEAGQADAFABAHIgKABQgBgIgFgDQgFgEgIAAQgIAAgEADQgFAEAAAFQAAAEADADQADACALADIARAFQAHABAEAFQADAFAAAHQAAAGgEAFQgDAGgHADQgHADgIAAQgJAAgHgDg");
	this.shape_35.setTransform(111,44.9);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgFAAQgCAAgCACQgBACgCAEQgBAFAAAFIAAAdg");
	this.shape_36.setTransform(103,45.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgRAWQgIgIAAgOQAAgNAIgHQAHgJAKABQALgBAIAJQAHAHAAANIAAACIgpAAQABAKAFAFQAEAEAGABQAFgBAEgDQADgCADgHIAKACQgDAJgGAFQgHAEgKAAQgKAAgHgHgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_37.setTransform(97.6,46);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgEgDgEAAQgDAAgBACQgBACgCAEQgBAFAAAFIAAAdg");
	this.shape_38.setTransform(93.2,45.9);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgSAWQgHgIAAgOQAAgOAJgIQAHgGAJAAQALgBAIAJQAHAHAAANQAAAKgDAGQgDAGgHAEQgGADgHAAQgKAAgIgHgAgKgPQgFAFAAAKQAAALAFAFQAEAGAGAAQAHAAAFgGQAEgGAAgKQAAgKgEgFQgFgGgHABQgGgBgEAGg");
	this.shape_39.setTransform(87.9,46);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AANAnIAAgkQAAgGgDgDQgDgDgGAAQgDAAgDACQgEACgBAEQgCACAAAHIAAAfIgKAAIAAhNIAKAAIAAAcQAGgIAJAAQAGAAAFADQAEACACAFQACAEAAAHIAAAkg");
	this.shape_40.setTransform(81.8,44.9);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgXAoIAAhNIAIAAIAAAHQADgEAEgCQAEgDAEAAQAHAAAGAEQAFAEADAHQADAHAAAIQAAAJgDAFQgDAHgGADQgGAEgGAAQgEAAgDgCQgEgCgDgDIAAAcgAgKgZQgFAGAAALQAAAJAFAFQAEAFAGAAQAFAAAFgFQAEgGAAgJQAAgLgEgGQgFgFgFAAQgFAAgFAGg");
	this.shape_41.setTransform(75.9,47);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgSAWQgHgIAAgOQAAgOAJgIQAHgGAJAAQALgBAIAJQAHAHAAANQAAAKgDAGQgDAGgHAEQgGADgHAAQgKAAgIgHgAgKgPQgFAFAAAKQAAALAFAFQAEAGAGAAQAHAAAFgGQAEgGAAgKQAAgKgEgFQgFgGgHABQgGgBgEAGg");
	this.shape_42.setTransform(69.6,46);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgFAAQgCAAgCACQgBACgCAEQgBAFAAAFIAAAdg");
	this.shape_43.setTransform(65.2,45.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AgTAmIgCgJIAGABQADAAACgBIADgDIADgHIABgCIgWg4IAKAAIAMAhIADAMIADgMIANghIAKAAIgWA5IgEAMQgCAFgEACQgDACgFAAIgFgBg");
	this.shape_44.setTransform(60.2,47.2);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgEAAQgDAAgCACQgCACAAAEQgCAFAAAFIAAAdg");
	this.shape_45.setTransform(56,45.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgXAoIAAhNIAIAAIAAAHQADgEAEgCQAEgDAEAAQAHAAAGAEQAFAEADAHQADAHAAAIQAAAJgDAFQgDAHgGADQgGAEgGAAQgEAAgDgCQgEgCgDgDIAAAcgAgKgZQgFAGAAALQAAAJAFAFQAEAFAGAAQAFAAAFgFQAEgGAAgJQAAgLgEgGQgFgFgFAAQgFAAgFAGg");
	this.shape_46.setTransform(50.9,47);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgQAkQgGgFAAgJIAKABQAAAFADACQAEACAFAAQAFAAAEgCQAEgDABgFIABgMQgHAHgIAAQgLAAgGgIQgHgJAAgKQAAgIADgHQADgHAGgDQAFgEAHAAQAJAAAHAIIAAgHIAJAAIAAAwQAAANgDAFQgDAGgGADQgGADgHAAQgJAAgHgEgAgJgaQgFAFAAALQAAAKAFAEQAEAFAFAAQAHAAAEgFQAFgEAAgKQAAgKgFgGQgFgFgGAAQgFAAgEAFg");
	this.shape_47.setTransform(41.4,47.1);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_48.setTransform(35.5,45.9);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgMAbQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCg");
	this.shape_49.setTransform(29.3,46.1);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgLAjQgGgDgDgHQgDgGAAgKQAAgIADgFQADgHAFgEQAGgDAGAAQAEgBAEADQAEACADAEIAAgcIAJAAIAABMIgIAAIAAgHQgGAJgKgBQgFAAgGgEgAgJgFQgFAFAAAJQABAMAEAFQAFAGAEAAQAHAAAEgGQAEgFABgLQgBgKgEgFQgEgGgHABQgEgBgFAGg");
	this.shape_50.setTransform(23.1,45);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_51.setTransform(19,44.9);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_52.setTransform(16.6,44.9);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgcAnIAAhNIAcAAQAIAAAGACQAFADADAFQADAFAAAFQAAAFgCAFQgDAEgGADQAIABADAEQAEAFAAAHQAAAFgCAFQgCAFgEADQgDACgFABQgGACgHAAgAgSAdIASAAIAHAAIAGgCIAEgEQABgDAAgEQAAgEgCgEQgCgDgEgBQgEgCgGAAIgSAAgAgSgFIARAAIAIgBQAEgBACgDQACgCAAgFQAAgEgCgCQgCgDgDgCIgKgBIgQAAg");
	this.shape_53.setTransform(11.9,44.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgEAcIAAgLIAJAAIAAALgAgEgQIAAgLIAJAAIAAALg");
	this.shape_54.setTransform(130.9,29.7);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_55.setTransform(126.3,29.6);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_56.setTransform(120.1,29.7);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgDAGABIAJABIgBAIIgGAAQgEgBgCACQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_57.setTransform(115.8,28.6);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgDAGABIAJABIgBAIIgGAAQgEgBgCACQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_58.setTransform(112.8,28.6);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("AgSAVQgHgHAAgOQAAgPAJgHQAHgHAJABQALAAAIAIQAHAHAAANQAAAKgDAGQgDAHgHADQgGAEgHgBQgKAAgIgIgAgKgPQgFAFAAAKQAAALAFAFQAEAGAGgBQAHABAFgGQAEgFAAgLQAAgJgEgGQgFgGgHABQgGgBgEAGg");
	this.shape_59.setTransform(107.9,29.7);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("AAAAlQgDgCgBgDQgBgDAAgIIAAgfIgHAAIAAgIIAHAAIAAgNIAHgHIAAAUIAKAAIAAAIIgKAAIAAAgIABAEIABADIADAAIAFAAIABAJIgHABQgGAAAAgCg");
	this.shape_60.setTransform(103.5,28.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("AgOAlQgHgDgEgGQgFgHAAgIIAKAAQABAGACADQADAEAFACQAGADAEAAQAGAAAFgCQAEgCADgDQACgDAAgEQAAgDgCgDQgCgDgFgCIgMgEIgQgCQgFgDgDgFQgDgEAAgGQAAgGAEgFQADgFAGgDQAHgCAHAAQAIAAAGADQAHACAEAGQADAFABAHIgKABQgBgIgFgDQgFgEgIAAQgIAAgEADQgFAEAAAFQAAAEADADQADACALADIARAFQAHABAEAFQADAFAAAHQAAAGgEAFQgDAGgHADQgHADgIAAQgJAAgHgDg");
	this.shape_61.setTransform(98.2,28.6);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_62.setTransform(88.5,29.6);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_63.setTransform(82.3,29.7);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("AgLAkQgGgEgDgHQgDgGAAgKQAAgIADgFQADgHAFgEQAGgDAGAAQAEAAAEACQAEACADAEIAAgdIAJAAIAABNIgIAAIAAgHQgGAJgKgBQgFAAgGgDgAgJgFQgFAFAAAJQABAMAFAFQAEAGAEgBQAGABAFgGQAEgFABgLQgBgKgEgFQgFgGgGABQgEgBgFAGg");
	this.shape_64.setTransform(76.1,28.7);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIAAAKIAAAhg");
	this.shape_65.setTransform(70.2,29.6);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_66.setTransform(64,29.7);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("AgLAkQgGgEgDgHQgDgGAAgKQAAgIACgFQADgHAGgEQAGgDAGAAQAEAAAEACQAEACACAEIAAgdIAKAAIAABNIgJAAIAAgHQgFAJgKgBQgGAAgFgDgAgJgFQgEAFgBAJQAAAMAGAFQAEAGAEgBQAHABAEgGQAFgFgBgLQABgKgFgFQgEgGgHABQgFgBgEAGg");
	this.shape_67.setTransform(57.8,28.7);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_68.setTransform(53.7,28.6);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_69.setTransform(51.3,28.6);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("AgOAfIAAAHIgJAAIAAhNIAKAAIAAAdQAGgIAHAAQAGAAAEACQAFACADAEQADADACAGQABAEAAAGQAAAPgHAHQgHAIgKAAQgIABgGgJgAgKgFQgEAFAAAJQAAALADAEQAEAIAHgBQAFABAFgGQAFgFAAgMQAAgJgFgFQgEgGgGABQgFgBgFAGg");
	this.shape_70.setTransform(47.2,28.7);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AAAAlQgDgCgCgDQAAgDgBgIIAAgfIgHAAIAAgIIAHAAIAAgNIAIgHIAAAUIAKAAIAAAIIgKAAIAAAgIAAAEIACADIAEAAIAEAAIABAJIgHABQgFAAgBgCg");
	this.shape_71.setTransform(42.6,28.8);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("AgMAbQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCg");
	this.shape_72.setTransform(37.9,29.8);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_73.setTransform(33.6,28.6);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("AgQAkQgGgFAAgJIAKABQAAAFADACQAEACAFAAQAFAAAEgCQAEgDABgFIABgMQgHAHgIAAQgLAAgGgIQgHgJAAgKQAAgIADgHQADgHAGgDQAFgEAHAAQAJAAAHAIIAAgHIAJAAIAAAwQAAANgDAFQgDAGgGADQgGADgHAAQgJAAgHgEgAgJgaQgFAFAAALQAAAKAFAEQAEAFAFAAQAHAAAEgFQAFgEAAgKQAAgKgFgGQgFgFgGAAQgFAAgEAFg");
	this.shape_74.setTransform(29.2,30.8);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_75.setTransform(22.1,28.6);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgHQAHgIAKAAQALAAAIAIQAHAHAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgDQADgCADgHIAKACQgDAIgGAGQgHAEgKAAQgKAAgHgIgAAQgEQgBgHgDgEQgFgGgHABQgFgBgEAFQgFAEAAAIIAeAAIAAAAg");
	this.shape_76.setTransform(17.8,29.7);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("AgOAfIAAAHIgJAAIAAhNIAKAAIAAAdQAGgIAHAAQAGAAAEACQAFACADAEQADADACAGQABAEAAAGQAAAPgHAHQgHAIgKAAQgIABgGgJgAgKgFQgEAFAAAJQAAALADAEQAEAIAHgBQAFABAFgGQAFgFAAgMQAAgJgFgFQgEgGgGABQgFgBgFAGg");
	this.shape_77.setTransform(11.9,28.7);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("AgNAFIAAgJIAbAAIAAAJg");
	this.shape_78.setTransform(3.8,29.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgIQAHgHAKAAQALAAAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgHIAKACQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_79.setTransform(162.8,13.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("AgHAoIAAgwIgIAAIAAgIIAIAAIAAgFIABgJQACgEADgCQACgCAGAAIAJABIgBAIIgGAAQgEAAgCABQgCACAAAFIAAAFIALAAIAAAIIgLAAIAAAwg");
	this.shape_80.setTransform(158.5,12.3);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("AgXAoIAAhNIAIAAIAAAHQADgEAEgCQAEgDAEAAQAHAAAGAEQAFAEADAHQADAHAAAIQAAAJgDAFQgDAHgGADQgGAEgGAAQgEAAgDgCQgEgCgDgDIAAAcgAgKgZQgFAGAAALQAAAJAFAFQAEAFAGAAQAFAAAFgFQAEgGAAgJQAAgLgEgGQgFgFgFAAQgFAAgFAGg");
	this.shape_81.setTransform(153.9,14.4);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("AAdAdIAAgiIgCgJQgBgCgCgCQgDgBgDAAQgFAAgFAEQgDAEAAAJIAAAfIgIAAIAAgjQAAgHgCgDQgDgDgFAAQgEAAgEACQgDACgCAEQgBAEgBAHIAAAdIgJAAIAAg3IAIAAIAAAIQADgEAFgDQAEgDAGAAQAGAAAEADQACADACAEQAHgKALAAQAIAAAEAFQAFAFAAAKIAAAlg");
	this.shape_82.setTransform(146.1,13.3);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("AgUAjQgFgFAAgHQAAgEACgDIAFgGIAHgDIAJgCIAPgDIAAgCQAAgEgDgDQgDgDgHAAQgGAAgDACQgDADgCAFIgJgBQABgGADgDQADgEAGgCQAFgCAGAAQAHAAAEACQAFABACADIADAHIABAGIAAANIAAARIADAHIgKAAIgCgHQgGAFgFACQgDACgFAAQgKAAgFgFgAgBANIgIACIgEADIgBAFQAAAEACACQADADAGAAQAEAAAEgCQAEgDACgEQACgDAAgHIAAgDQgFACgJABgAAEgcIAAgLIALAAIAAALgAgOgcIAAgLIALAAIAAALg");
	this.shape_83.setTransform(138.4,12.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("AgfAnIAAhNIAbAAIAMABQAHACAEAEQAHAFADAIQADAIAAAKQAAAIgCAHQgCAHgEAEQgCAFgFACQgEADgFABQgGACgEAAgAgUAdIAQAAIALgBQAEgBADgDQADgEACgGQADgGAAgIQAAgMgFgGQgEgHgGgCQgEgCgHAAIgQAAg");
	this.shape_84.setTransform(131.6,12.3);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgBgDgDgBQgDgCgEAAQgEAAgEAEQgFAEAAALIAAAdIgKAAIAAg3IAJAAIAAAIQAGgKAKAAQAFAAAEACQAFACACADIADAHIAAAKIAAAhg");
	this.shape_85.setTransform(121.4,13.3);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgIQAHgHAKAAQALAAAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgHIAKACQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_86.setTransform(115.3,13.4);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("AgOAdIAAg3IAJAAIAAAIQADgGACgCQACgCADAAQAFAAAFAEIgDAJQgDgDgFAAQgDAAgBACQgCACgBAEQgBAFAAAFIAAAdg");
	this.shape_87.setTransform(110.9,13.3);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgIQAHgHAKAAQALAAAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgHIAKACQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_88.setTransform(105.5,13.4);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("AgLAkQgGgEgDgHQgDgGAAgJQAAgJACgFQAEgHAFgDQAGgEAGAAQAEAAAEACQAEACACADIAAgcIAKAAIAABNIgIAAIAAgHQgGAIgKAAQgGAAgFgDgAgJgFQgEAFgBAKQAAALAGAFQAEAGAEgBQAGABAFgGQAFgFAAgKQAAgLgFgFQgFgGgGAAQgFAAgEAGg");
	this.shape_89.setTransform(99.3,12.4);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("AgEAcIAAgLIAJAAIAAALgAgEgQIAAgLIAJAAIAAALg");
	this.shape_90.setTransform(91.9,13.4);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("AANAdIAAghIgBgJQgCgDgCgBQgDgCgEAAQgEAAgFAEQgEAEAAALIAAAdIgJAAIAAg3IAIAAIAAAIQAGgKAKAAQAGAAAEACQAEACACADIADAHIAAAKIAAAhg");
	this.shape_91.setTransform(87.3,13.3);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgIQAHgHAKAAQALAAAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgHIAKACQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_92.setTransform(81.1,13.4);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("AAAAkQgDgBgCgDQAAgCAAgJIAAgfIgIAAIAAgIIAIAAIAAgNIAHgGIAAATIAKAAIAAAIIgKAAIAAAgIAAAEIACADIAEAAIAEAAIABAJIgHABQgGAAAAgDg");
	this.shape_93.setTransform(76.7,12.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_94.setTransform(73.9,12.3);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgIQAHgHAKAAQALAAAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgHIAKACQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_95.setTransform(69.6,13.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("AALAnIgQgdIgIAGIAAAXIgJAAIAAhNIAJAAIAAArIAWgVIAMAAIgVATIAXAkg");
	this.shape_96.setTransform(64.2,12.3);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("AgQAkQgGgFAAgJIAKABQAAAFADACQAEACAFAAQAFAAAEgCQAEgDABgFIABgMQgHAHgIAAQgLAAgGgIQgHgJAAgKQAAgIADgHQADgHAGgDQAFgEAHAAQAJAAAHAIIAAgHIAJAAIAAAwQAAANgDAFQgDAGgGADQgGADgHAAQgJAAgHgEgAgJgaQgFAFAAALQAAAKAFAEQAEAFAFAAQAHAAAEgFQAFgEAAgKQAAgKgFgGQgFgFgGAAQgFAAgEAFg");
	this.shape_97.setTransform(57.8,14.5);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_98.setTransform(53.8,12.3);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("AgPAZQgGgFgBgJIAJgCQABAGAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgDAAgFQAAgEACgDIAFgFIAGgDQAEgBAEAAQAFAAAFACQAFACADADQACADABAFIgKACQAAgFgDgCQgDgDgFAAQgGAAgDADQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAFgFACQgFADgHgBQgJAAgGgEg");
	this.shape_99.setTransform(49.8,13.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("AgPAZQgGgFgBgJIAJgCQABAGAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgDAAgFQAAgEACgDIAFgFIAGgDQAEgBAEAAQAFAAAFACQAFACADADQACADABAFIgKACQAAgFgDgCQgDgDgFAAQgGAAgDADQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAFgFACQgFADgHgBQgJAAgGgEg");
	this.shape_100.setTransform(44.3,13.4);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("AgMAmQgEgCgCgDIgDgHIgBgJIAAgiIAKAAIAAAeIABAKQAAAEADACQADACAFAAQACAAAEgCQAEgCABgEQACgEAAgHIAAgdIAKAAIAAA3IgJAAIAAgIQgHAKgJAAQgFAAgFgCgAAEgcIAAgLIAKAAIAAALgAgOgcIAAgLIAKAAIAAALg");
	this.shape_101.setTransform(38.5,12.4);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("AgDAnIAAhNIAHAAIAABNg");
	this.shape_102.setTransform(34.2,12.3);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("AgZAnIAAhNIAzAAIAAAJIgpAAIAAAZIAkAAIAAAHIgkAAIAAAkg");
	this.shape_103.setTransform(29.9,12.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("AgDAnIAAg3IAHAAIAAA3gAgDgbIAAgLIAHAAIAAALg");
	this.shape_104.setTransform(22.1,12.3);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgNAIgIQAHgHAKAAQALAAAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgHIAKACQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_105.setTransform(17.8,13.4);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("AgOAfIAAAHIgJAAIAAhNIAKAAIAAAcQAGgHAHAAQAGAAAEACQAFACADAEQADAEACAFQABADAAAHQAAAPgHAHQgHAJgKgBQgIAAgGgIgAgKgFQgEAFAAAJQAAALADAEQAEAIAHgBQAFABAFgGQAFgFAAgLQAAgKgFgFQgEgGgGAAQgFAAgFAGg");
	this.shape_106.setTransform(11.9,12.4);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("AgNAEIAAgIIAbAAIAAAIg");
	this.shape_107.setTransform(3.8,13.4);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("AgRAVQgIgHAAgOQAAgMAIgJQAHgHAKgBQALABAIAHQAHAIAAANIAAACIgpAAQABAJAFAGQAEAEAGAAQAFAAAEgCQADgDADgGIAKABQgDAIgGAGQgHAEgKAAQgKABgHgJgAAQgEQgBgHgDgEQgFgGgHAAQgFAAgEAFQgFAFAAAHIAeAAIAAAAg");
	this.shape_108.setTransform(31.9,-2.9);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("AgPAZQgGgFgBgJIAJgBQABAFAEAEQADACAFAAQAHAAADgCQADgDAAgEQAAgDgDgCIgKgDIgMgEQgFgBgCgDQgCgEAAgEQAAgDACgEIAFgFIAGgDQAEgCAEAAQAFABAFACQAFACADADQACADABAFIgKACQAAgEgDgDQgDgDgFAAQgGAAgDADQgCACAAADIABAEIADACIAHACIAOAFQAEAAADADQACADAAAFQAAAFgDAEQgDAEgFADQgFADgHgBQgJAAgGgEg");
	this.shape_109.setTransform(26.1,-2.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("AgUAZQgFgFAAgHQAAgEACgEIAFgFIAHgCIAJgBIAPgDIAAgCQAAgHgDgCQgDgEgHAAQgGAAgDADQgDACgCAHIgJgCQABgGADgEQADgDAGgCQAFgCAGgBQAHABAEACQAFABACACIADAIIABAIIAAALIAAARIADAHIgKAAIgCgHQgGAFgFACQgDABgFAAQgKAAgFgEgAgBADIgIACIgEADIgBAEQAAAFACACQADADAGgBQAEAAAEgCQAEgCACgFQACgDAAgGIAAgDQgFACgJABg");
	this.shape_110.setTransform(20.3,-2.9);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("AgQAjQgJgFgFgJQgFgKAAgLQAAgKAFgKQAFgKAJgEQAJgFAKAAQAIAAAHACQAHADAEAFQAEAFACAIIgKADQgBgGgDgEQgDgDgFgCQgEgCgGAAQgGAAgFACQgFACgDADIgFAIQgDAIAAAHQAAAKADAHQAEAHAHADQAHAEAGAAQAHAAAGgDIAKgFIAAgPIgXAAIAAgIIAhAAIAAAcQgIAGgIADQgIADgJAAQgJAAgKgFg");
	this.shape_111.setTransform(12.9,-4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("AgNAEIAAgIIAbAAIAAAIg");
	this.shape_112.setTransform(3.8,-2.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98},{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77},{t:this.shape_76},{t:this.shape_75},{t:this.shape_74},{t:this.shape_73},{t:this.shape_72},{t:this.shape_71},{t:this.shape_70},{t:this.shape_69},{t:this.shape_68},{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10}]}).wait(1));

	// Ebene 5
	this.instance = new lib.papierkugel_braun();
	this.instance.setTransform(115,122.8,0.16,0.16,12,0,0,177.2,161.7);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Ebene 3
	this.instance_1 = new lib.kanister();
	this.instance_1.setTransform(51.8,112.1,0.5,0.5,0,0,0,-0.5,-0.3);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1));

	// Ebene 4
	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("rgba(0,0,0,0.702)").s().p("AtqP7QhjAAgBhkIAA8tQABhkBjAAIbVAAQBjAAABBkIAActQgBBkhjAAg");
	this.shape_113.setTransform(88.2,56.8);

	this.timeline.addTween(cjs.Tween.get(this.shape_113).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.3,-45.1,214.5,204);


(lib.animation = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_420 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(420).call(this.frame_420).wait(1));

	// sprechblase
	this.instance = new lib.sprechblase();
	this.instance.setTransform(105.1,106.6,1,1,0,0,0,-255.3,65.8);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(45).to({_off:false},0).to({alpha:1},11).wait(365));

	// coach
	this.instance_1 = new lib.gruen_coach_zeigen_3();
	this.instance_1.setTransform(-36,423.2,1.049,1.049,0,0,0,7.3,7.3);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(14).to({_off:false},0).to({y:13.2},21,cjs.Ease.get(1)).wait(386));

	// rahmen
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#808080").ss(1,1,1).p("EA15Ag0MhrxAAAMAAAhBnMBrxAAAg");
	this.shape.setTransform(345,210);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(421));

	// maske (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("Eg14Ag0MAAAhBnMBrxAAAMAAABBng");
	mask.setTransform(345,210);

	// ende
	this.instance_2 = new lib.ende_mc();
	this.instance_2.setTransform(344.9,464.8,1,1,0,0,0,-137.3,42.6);
	this.instance_2._off = true;

	this.instance_2.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(404).to({_off:false},0).to({y:374.8},11,cjs.Ease.get(1)).to({y:384.8},5,cjs.Ease.get(-1)).wait(1));

	// zuendquelle
	this.instance_3 = new lib.zuendquelle();
	this.instance_3.setTransform(338.8,200.6,1,1,0,0,0,50.8,48.8);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.instance_3.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(275).to({_off:false},0).to({alpha:1},11).wait(135));

	// feld_sauerst
	this.instance_4 = new lib.sauerstoff();
	this.instance_4.setTransform(812.2,112,1,1,0,0,0,97.9,56.8);
	this.instance_4._off = true;

	this.instance_4.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(100).to({_off:false},0).to({x:582.2},16,cjs.Ease.get(1)).to({x:592.2},5,cjs.Ease.get(-1)).wait(300));

	// feld_brennst
	this.instance_5 = new lib.brennstoff();
	this.instance_5.setTransform(816.8,246.2,1,1,0,0,0,102.5,36.8);
	this.instance_5._off = true;

	this.instance_5.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(111).to({_off:false},0).to({x:586.8},16,cjs.Ease.get(1)).to({x:596.8},5,cjs.Ease.get(-1)).wait(289));

	// pfeil_sauerstoff
	this.instance_6 = new lib.pfeil_rot3();
	this.instance_6.setTransform(469.3,40,0.65,0.65,161,0,0,47.5,12.6);
	this.instance_6.alpha = 0;
	this.instance_6._off = true;

	this.instance_6.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(156).to({_off:false},0).to({alpha:1},9).wait(256));

	// pfeil_brennstoff
	this.instance_7 = new lib.pfeil_rot2();
	this.instance_7.setTransform(464.1,195.6,0.65,0.65,-145,0,0,28.7,12.3);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.instance_7.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(156).to({_off:false},0).to({alpha:1},9).wait(256));

	// wolke
	this.instance_8 = new lib.rauchwolke();
	this.instance_8.setTransform(347,94.4,1,1,0,0,0,116.9,74.2);
	this.instance_8.alpha = 0;
	this.instance_8._off = true;

	this.instance_8.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(189).to({_off:false},0).to({alpha:1},11,cjs.Ease.get(1)).wait(221));

	// pfeil_lang
	this.instance_9 = new lib.pfeil_rot1();
	this.instance_9.setTransform(-19.1,200.8,0.65,0.65,0,0,0,56.7,12.5);
	this.instance_9._off = true;

	this.instance_9.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(241).to({_off:false},0).to({x:290.9},16,cjs.Ease.get(1)).to({x:280.9},6,cjs.Ease.get(-1)).wait(158));

	// txt_zuendquelle
	this.instance_10 = new lib.zündquelle();
	this.instance_10.setTransform(-182.7,220,1,1,0,0,0,97.9,56.8);
	this.instance_10._off = true;

	this.instance_10.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(241).to({_off:false},0).to({x:127.3},16,cjs.Ease.get(1)).to({x:117.3},6,cjs.Ease.get(-1)).wait(158));

	// brand
	this.instance_11 = new lib.flamme3();
	this.instance_11.setTransform(348,494);
	this.instance_11.alpha = 0;
	this.instance_11._off = true;

	this.instance_11.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(303).to({_off:false},0).to({y:294,alpha:1},16,cjs.Ease.get(1)).wait(102));

	// dreieck_hg
	this.instance_12 = new lib.pfeil_mitte();
	this.instance_12.setTransform(349,168.1,1,1,0,0,0,53.1,26.1);
	this.instance_12.alpha = 0;
	this.instance_12._off = true;

	this.instance_12.mask = mask;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(270).to({_off:false},0).to({y:218.1,alpha:1},16,cjs.Ease.get(1)).wait(135));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-1,-1,691.9,422);


// stage content:



(lib._1_0 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// heading
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#004114").s().p("AgWAVQgGgIAAgNQAAgNAIgKQAIgIAMAAQAMAAAJAJQAIAJgBARIgnAAQAAAHAEAFQAEADADAAQAEAAADgBQADgDABgFIAQADQgDAKgHAEQgHAFgKAAQgOAAgIgLgAAMgEQAAgHgEgEQgDgEgFABQgEAAgDADQgEAEAAAHIAXAAIAAAAg");
	this.shape.setTransform(305.3,97.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#004114").s().p("AgUAnQgHgGAAgIIAAgCIATACQAAABABAAQAAABAAABQAAAAABABQAAAAAAABQADABADAAQAGAAADgCQADgBABgDIAAgIIAAgJQgHAKgJAAQgNAAgHgKQgGgIAAgLQAAgQAIgIQAHgIALAAQAKAAAHAKIAAgJIAQAAIAAA2QAAALgCAFQgCAGgDADQgDADgGACQgFACgJAAQgNAAgHgFgAgIgaQgEAFAAAJQAAAKAEACQAEAFAEAAQAFAAAFgFQAEgCAAgJQAAgKgEgFQgEgFgGABQgEgBgEAFg");
	this.shape_1.setTransform(298.2,98.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#004114").s().p("AAMAfIAAgfQAAgJgCgDQgBgDgCgBQgCgCgEAAQgCAAgDADQgEACgBAEQgBAEAAAIIAAAcIgRAAIAAg8IAQAAIAAAJQAIgKAKAAQAGAAAEACQAFACACADQACADABAEIABALIAAAkg");
	this.shape_2.setTransform(291,97.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#004114").s().p("AgWAnQgFgFAAgJQgBgFADgEQADgEAEgCQAFgCAIgCQAJgCAFgCIAAgBQAAgEgCgBQgCgCgFAAQgEAAgDABQgDACgBADIgPgCQADgIAFgFQAHgEALAAQAKAAAGADQAEACADAEQACAEAAAJIAAATIABAMIACAIIgPAAIgCgEIgBgCQgEAEgFACQgDACgFAAQgKAAgFgFgAAAAPQgGACgCABQgEADABADQAAADACADQADADAEgBQADAAAEgCQACgDABgDIABgIIAAgDgAAFgdIAAgOIAOAAIAAAOgAgSgdIAAgOIAOAAIAAAOg");
	this.shape_3.setTransform(284.1,96.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#004114").s().p("AgUAnQgHgGAAgIIAAgCIATACQAAABABAAQAAABAAABQAAAAABABQAAAAAAABQADABADAAQAGAAADgCQADgBABgDIAAgIIAAgJQgHAKgJAAQgNAAgHgKQgGgIAAgLQAAgQAIgIQAHgIALAAQAKAAAHAKIAAgJIAQAAIAAA2QAAALgCAFQgCAGgDADQgDADgGACQgFACgJAAQgNAAgHgFgAgIgaQgEAFAAAJQAAAKAEACQAEAFAEAAQAFAAAFgFQAEgCAAgJQAAgKgEgFQgEgFgGABQgEgBgEAFg");
	this.shape_4.setTransform(276.9,98.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#004114").s().p("AgTAfIAAg8IAQAAIAAAJQADgGACgCQADgCAEAAQAFAAAFADIgEAOQgEgDgEAAQgEAAgCACQgBACAAAFQgCAFAAAOIAAATg");
	this.shape_5.setTransform(271.6,97.5);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#004114").s().p("AgPAcQgIgEgDgHQgEgIAAgJQAAgHAEgJQADgHAIgEQAHgEAIAAQANAAAKAJQAIAJABANQgBAOgIAIQgKAKgNAAQgHAAgIgEgAgJgNQgFAFAAAIQAAAJAFAEQAEAGAFgBQAGABAEgGQAFgEAAgJQAAgIgFgFQgEgFgGABQgFgBgEAFg");
	this.shape_6.setTransform(265.2,97.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#004114").s().p("AgGAeIgZg8IARAAIAMAeIACAKIABgEIACgGIAMgeIARAAIgZA8g");
	this.shape_7.setTransform(258.1,97.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#004114").s().p("AAMAfIAAgfQAAgJgCgDQgBgDgCgBQgCgCgEAAQgCAAgDADQgEACgBAEQgBAEAAAIIAAAcIgRAAIAAg8IAQAAIAAAJQAIgKAKAAQAGAAAEACQAFACACADQACADABAEIABALIAAAkg");
	this.shape_8.setTransform(251.2,97.5);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#004114").s().p("AAMAfIAAgfQAAgJgCgDQgBgDgCgBQgCgCgEAAQgCAAgDADQgEACgBAEQgBAEAAAIIAAAcIgRAAIAAg8IAQAAIAAAJQAIgKAKAAQAGAAAEACQAFACACADQACADABAEIABALIAAAkg");
	this.shape_9.setTransform(243.8,97.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#004114").s().p("AgWAVQgGgIAAgNQAAgNAIgKQAIgIAMAAQAMAAAJAJQAIAJgBARIgnAAQAAAHAEAFQAEADADAAQAEAAADgBQADgDABgFIAQADQgDAKgHAEQgHAFgKAAQgOAAgIgLgAAMgEQAAgHgEgEQgDgEgFABQgEAAgDADQgEAEAAAHIAXAAIAAAAg");
	this.shape_10.setTransform(236.8,97.6);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#004114").s().p("AgSAfIAAg8IAOAAIAAAJQAEgGACgCQADgCAEAAQAGAAAEADIgEAOQgFgDgDAAQgDAAgDACQgBACAAAFQgCAFAAAOIAAATg");
	this.shape_11.setTransform(231.7,97.5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#004114").s().p("AgFApQgFgDgEgFIAAAJIgPAAIAAhUIARAAIAAAfQAHgJAJAAQALAAAHAIQAIAJAAANQAAAQgIAJQgHAIgLAAQgEAAgFgCgAgJgDQgDADAAAJQAAAKADAFQAEAGAFAAQAFAAAEgEQAEgFAAgKQAAgLgEgDQgEgEgFAAQgFAAgEAEg");
	this.shape_12.setTransform(225.4,96.4);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#004114").s().p("AgSAfIAAg8IAPAAIAAAJQADgGACgCQADgCAEAAQAFAAAFADIgEAOQgFgDgDAAQgEAAgCACQgBACAAAFQgCAFAAAOIAAATg");
	this.shape_13.setTransform(219.7,97.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#004114").s().p("AgWAVQgGgIAAgNQAAgNAIgKQAIgIAMAAQAMAAAJAJQAIAJgBARIgnAAQAAAHAEAFQAEADADAAQAEAAADgBQADgDABgFIAQADQgDAKgHAEQgHAFgKAAQgOAAgIgLgAAMgEQAAgHgEgEQgDgEgFABQgEAAgDADQgEAEAAAHIAXAAIAAAAg");
	this.shape_14.setTransform(213.6,97.6);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#004114").s().p("AgIAqIgfhTIATAAIAUA9IAVg9IASAAIgeBTg");
	this.shape_15.setTransform(206.3,96.4);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#004114").s().p("AgWAVQgGgIAAgNQAAgNAIgKQAIgIAMAAQAMAAAJAJQAIAJgBARIgnAAQAAAHAEAFQAEADADAAQAEAAADgBQADgDABgFIAQADQgDAKgHAEQgHAFgKAAQgOAAgIgLgAAMgEQAAgHgEgEQgDgEgFABQgEAAgDADQgEAEAAAHIAXAAIAAAAg");
	this.shape_16.setTransform(195.6,97.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#004114").s().p("AgHAqIAAhTIAPAAIAABTg");
	this.shape_17.setTransform(190.7,96.4);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#004114").s().p("AgHAqIAAhTIAPAAIAABTg");
	this.shape_18.setTransform(187.4,96.4);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#004114").s().p("AgWAbQgGgFAAgJQAAgFADgEQACgEAFAAQAEgCAJgCQAKgCAEgCIAAgBQAAgGgDgBQgCgCgEAAQgFAAgCABQgCACgCAFIgPgEQACgIAHgFQAGgEALAAQAKAAAFADQAGACACAEQACAEAAALIAAARIABAMIADAIIgRAAIgBgEIgBgCQgEAEgFACQgCACgGAAQgJAAgGgFgAAAADQgGACgCABQgDADgBADQAAADAEADQACADAEgBQACAAAEgCQADgDACgDIAAgIIAAgDg");
	this.shape_19.setTransform(182.4,97.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#004114").s().p("AgTAfIAAg8IAQAAIAAAJQADgGACgCQADgCAEAAQAFAAAFADIgEAOQgEgDgEAAQgEAAgCACQgBACgBAFQgBAFAAAOIAAATg");
	this.shape_20.setTransform(173.9,97.5);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#004114").s().p("AgSApQgFgDgCgFQgCgFAAgIIAAgmIAQAAIAAAbQAAANABADQABADADACQACABAEAAQACABADgDQAEgDABgDQABgDAAgOIAAgYIARAAIAAA8IgQAAIAAgJQgDAFgGADQgDADgGAAQgHAAgFgDgAAFgdIAAgOIAOAAIAAAOgAgSgdIAAgOIAOAAIAAAOg");
	this.shape_21.setTransform(167.5,96.4);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#004114").s().p("AgKArIAAgvIgJAAIAAgNIAJAAIAAgFQgBgIACgDQACgEAFgDQACgCAHAAQAGAAAHACIgCALIgIAAQgDAAgBABQgCACAAAFIAAAEIANAAIAAANIgNAAIAAAvg");
	this.shape_22.setTransform(162.1,96.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#004114").s().p("AAMAfIAAgfQAAgJgCgDQgBgDgCgBQgCgCgEAAQgCAAgDADQgEACgBAEQgBAEAAAIIAAAcIgRAAIAAg8IAQAAIAAAJQAIgKAKAAQAGAAAEACQAFACACADQACADABAEIABALIAAAkg");
	this.shape_23.setTransform(152.9,97.5);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#004114").s().p("AgWAVQgGgIAAgNQAAgNAIgKQAIgIAMAAQAMAAAJAJQAIAJgBARIgnAAQAAAHAEAFQAEADADAAQAEAAADgBQADgDABgFIAQADQgDAKgHAEQgHAFgKAAQgOAAgIgLgAAMgEQAAgHgEgEQgDgEgFABQgEAAgDADQgEAEAAAHIAXAAIAAAAg");
	this.shape_24.setTransform(145.9,97.6);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#004114").s().p("AgUAnQgHgGAAgIIAAgCIATACQAAABABAAQAAABAAABQAAAAABABQAAAAAAABQADABADAAQAGAAADgCQADgBABgDIAAgIIAAgJQgHAKgJAAQgNAAgHgKQgGgIAAgLQAAgQAIgIQAHgIALAAQAKAAAHAKIAAgJIAQAAIAAA2QAAALgCAFQgCAGgDADQgDADgGACQgFACgJAAQgNAAgHgFgAgIgaQgEAFAAAJQAAAKAEACQAEAFAEAAQAFAAAFgFQAEgCAAgJQAAgKgEgFQgEgFgGABQgEgBgEAFg");
	this.shape_25.setTransform(138.8,98.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#004114").s().p("AAMAfIAAgfQAAgJgCgDQgBgDgCgBQgCgCgEAAQgCAAgDADQgEACgBAEQgBAEAAAIIAAAcIgRAAIAAg8IAQAAIAAAJQAIgKAKAAQAGAAAEACQAFACACADQACADABAEIABALIAAAkg");
	this.shape_26.setTransform(131.7,97.5);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#004114").s().p("AgSAcQgFgCgCgFQgCgFAAgJIAAglIAQAAIAAAcQAAALABADQABADADACQACACAEAAQACAAADgDQAEgCABgDQABgEAAgLIAAgaIARAAIAAA8IgQAAIAAgKQgDAFgGADQgDADgGAAQgHAAgFgDg");
	this.shape_27.setTransform(124.4,97.6);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#004114").s().p("AgaAeIAAgMIAXgZIAHgJIgGAAIgWAAIAAgOIAxAAIAAAMIgXAaIgHAJIAHgBIAZAAIAAAOg");
	this.shape_28.setTransform(117.7,97.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#004114").s().p("AgBApQgEgCgCgCIgCgHIAAgLIAAgZIgIAAIAAgNIAIAAIAAgNIAOgJIAAAWIALAAIAAANIgLAAIAAAXIABAJIABACIADABIAGgCIACANQgGACgHAAQgFAAgBgBg");
	this.shape_29.setTransform(112.8,96.5);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#004114").s().p("AgWAVQgGgIAAgNQAAgNAIgKQAIgIAMAAQAMAAAJAJQAIAJgBARIgnAAQAAAHAEAFQAEADADAAQAEAAADgBQADgDABgFIAQADQgDAKgHAEQgHAFgKAAQgOAAgIgLgAAMgEQAAgHgEgEQgDgEgFABQgEAAgDADQgEAEAAAHIAXAAIAAAAg");
	this.shape_30.setTransform(107.4,97.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#004114").s().p("AgSAbQgIgFgCgKIARgCQABAFADADQADACAEAAQAGAAAEgCQAAgBABAAQAAgBAAAAQABgBAAAAQAAgBAAgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAIgGgCQgSgEgFgEQgIgDAAgJQAAgIAHgFQAGgGANAAQALAAAHAEQAGAEACAIIgPADQgBgDgDgCQgDgCgEAAQgGAAgCACQAAAAgBAAQAAABAAAAQgBABAAAAQAAABAAAAIABADIAOAFQANACAFAEQAFADABAIQgBAIgGAHQgIAGgOAAQgLAAgHgFg");
	this.shape_31.setTransform(100.7,97.6);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#004114").s().p("AgSAbQgIgFgCgKIARgCQABAFADADQAEACADAAQAGAAAEgCQAAgBABAAQAAgBAAAAQABgBAAAAQAAgBAAgBQAAAAAAAAQAAgBAAAAQgBgBAAAAQAAgBAAAAIgGgCQgSgEgFgEQgIgDAAgJQAAgIAHgFQAGgGANAAQAMAAAGAEQAGAEACAIIgPADQgBgDgDgCQgDgCgEAAQgGAAgCACQAAAAgBAAQAAABAAAAQgBABAAAAQAAABAAAAIABADIAOAFQANACAFAEQAFADABAIQgBAIgGAHQgIAGgOAAQgLAAgHgFg");
	this.shape_32.setTransform(94,97.6);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#004114").s().p("AgSAcQgFgCgCgFQgCgFAAgJIAAglIAQAAIAAAcQAAALABADQABADADACQACACAEAAQACAAADgDQAEgCABgDQABgEAAgLIAAgaIARAAIAAA8IgQAAIAAgKQgDAFgGADQgDADgGAAQgHAAgFgDg");
	this.shape_33.setTransform(87.2,97.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#004114").s().p("AgWAbQgFgFAAgJQgBgFADgEQADgEAEAAQAFgCAIgCQAJgCAFgCIAAgBQAAgGgCgBQgCgCgFAAQgEAAgDABQgDACgBAFIgPgEQADgIAFgFQAHgEALAAQAKAAAGADQAEACADAEQACAEAAALIAAARIABAMIACAIIgPAAIgCgEIgBgCQgEAEgFACQgDACgFAAQgKAAgFgFgAAAADQgGACgCABQgEADABADQAAADACADQADADAEgBQADAAAEgCQACgDABgDIABgIIAAgDg");
	this.shape_34.setTransform(80.2,97.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#004114").s().p("AgTAfIAAg8IAQAAIAAAJQADgGACgCQADgCAEAAQAFAAAGADIgFAOQgEgDgEAAQgEAAgCACQgBACgBAFQgBAFAAAOIAAATg");
	this.shape_35.setTransform(75,97.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#004114").s().p("AgPAcQgIgEgEgHQgDgIAAgJQAAgHADgJQAEgHAIgEQAHgEAIAAQANAAAKAJQAIAJABANQgBAOgIAIQgKAKgNAAQgHAAgIgEgAgJgNQgFAFAAAIQAAAJAFAEQAEAGAFgBQAGABAEgGQAFgEAAgJQAAgIgFgFQgEgFgGABQgFgBgEAFg");
	this.shape_36.setTransform(68.6,97.6);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#004114").s().p("AgIAqIgfhTIATAAIAUA9IAVg9IASAAIgeBTg");
	this.shape_37.setTransform(60.9,96.4);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#004114").s().p("AgTAiQgIgKAAgYQAAgXAJgLQAHgIALAAQAMAAAHAIQAJALgBAXQABAYgJAKQgHAJgMAAQgLAAgIgJgAgEgbQgCACgCAFQgBAGAAAOQAAAPABAFQACAGACACQACACACAAQADAAACgCQACgCABgFQACgGAAgPQAAgOgCgFQgBgGgCgCQgCgCgDAAQgCAAgCACg");
	this.shape_38.setTransform(50.3,96.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#004114").s().p("AgHAIIAAgPIAPAAIAAAPg");
	this.shape_39.setTransform(45.3,99.8);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#004114").s().p("AACAqIAAg8QgHAJgMAEIAAgPQAGgCAIgGQAFgGADgHIANAAIAABTg");
	this.shape_40.setTransform(39.8,96.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// animation
	this.animation = new lib.animation();
	this.animation.setTransform(374.7,329.8,1,1,0,0,0,344.9,210);

	this.timeline.addTween(cjs.Tween.get(this.animation).wait(1));

	// header
	this.instance = new lib.rahmen_layout();
	this.instance.setTransform(375,270.1,1,1,0,0,0,375,270.1);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(375,275,750,540.3);

})(lib = lib||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var lib, images, createjs, ss;