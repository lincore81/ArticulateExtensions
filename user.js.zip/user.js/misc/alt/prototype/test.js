var FOOTER = "spm GmbH | Friedrichstr. 13 | 19055 Schwerin | Telefon: 0385 / 34 41 932 | http://newspm.de";
var DISCLAIMER = "Dieses Dokument ist ausschließlich für den persönlichen Gebrauch bestimmt. Eine Vervielfältigung ist ohne die ausdrückliche Zustimmung der spm GmbH nicht gestattet.";
(function onload() {
    var canvas = document.getElementById('canvas');
    var body = document.querySelector('body');
    var button = document.createElement('button');
    var canvasToPdf;
    button.innerHTML = "Als PDF speichern";
    body.appendChild(button);
    button.onclick = function() {
        // Feature wird erst initialisiert, wenn es ein User nutzt:
        lazyCanvasToPdf(document, canvas, function(f) {
            button.onclick = f;
            f();
        });
    };
})();



function lazyCanvasToPdf(docRoot, canvas, callback) {
    var offscrCanvas = document.createElement('canvas');
    offscrCanvas.width = canvas.width;
    offscrCanvas.height = canvas.height + 300; //z. Z. 850px
    var aspectRatio = offscrCanvas.width / offscrCanvas.height;
    var ctx = offscrCanvas.getContext('2d');
    watermark = new Image();
    watermark.addEventListener('load', function() {
        callback(function() {
            var title = "Brandschutz";
            // bei der Konvertierung zu jpeg werden alle transparenten Pixel
            // in schwarz konvertiert, daher kopiere ich die Folie auf einen zweiten
            // Canvas, den ich zuvor weiss einfaerbe.
            ctx.fillStyle = "white";
            ctx.fillRect(0, 0, offscrCanvas.width, offscrCanvas.height);
            ctx.drawImage(canvas, 0, 30);
            ctx.drawImage(watermark, 0, 30);
            ctx.fillStyle = 'black';
            ctx.font = '24px Sans-Serif';
            ctx.textAlign = 'left';
            ctx.fillText(title, 0, 24, offscrCanvas.width);
            var horizCenter = offscrCanvas.width / 2;
            ctx.font = '18px Sans-Serif';
            ctx.textAlign = 'center';
            ctx.fillText(FOOTER, horizCenter, canvas.height + 46, offscrCanvas.width - 20);
            ctx.font = '12px Sans-Serif';
            ctx.fillText(DISCLAIMER, horizCenter, canvas.height + 64, offscrCanvas.width - 20);
            var data = offscrCanvas.toDataURL('image/jpeg');
            var pdf = new jsPDF('landscape', 'mm', 'a4');
            // A4: 210mm x 297mm, @300dpi: 2480px x 3508px

            var imgHeight = 240;
            var imgWidth = imgHeight * aspectRatio;
            var horizMargin = (297-imgWidth) / 2;
            var vertMargin = 20;
            pdf.addImage(data, 'JPEG', horizMargin, vertMargin, imgWidth, imgHeight);
            pdf.save('test.pdf');
        });
    });
    watermark.src = 'spm_wasserzeichen.png';
    function pxToMillis(width, height, dpi) {
        dpi = dpi || 300;
        return dpi / 25.4;
    }
}
