require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
var utils = require('./utils.js');
module.exports = ExtensionApi;

// {{{1 ExtensionApi
/**
 *  Stellt grundlegende Funktionen bereit, mit denen Erweiterungen einfacher 
 *  realisiert werden koennen.
 *
 *  - beobachtet und reagiert auf den Ladevorgang des Kurses
 *  - stellt ein Eventsystem bereit, um auf das Oeffnen und Schliessen von
 *    Folien reagieren zu koennen.
 *  - haelt alle relevanten HTML Elemente unter api.elements vor.
 *
 * @returns {object} Das api Objekt, ueber das Erweiterungen auf die o.g.
 *                   Funktionen zugreifen koennen.
 */
function ExtensionApi() {
    "use strict";
    var api = init();
    utils.async(null, lookForCanvasFrame, loadCanvasFrame, setCanvas, ready);
    return api;

    // {{{2 init()
    function init() {
        var api = {};
        api.isReady = false;
        api.verbose = localStorage.getItem('de.newspm.onlineacademy.verbose') || false;
        if (api.verbose) console.log('API: init()');
        api.events = {ready:[], slideChange:[], slideClose:[]};

        api.elements = {};

        api.elements.body = utils.assertExists(
                document.getElementsByTagName('BODY')[0], 'body');

        api.elements.rootWnd = utils.assertExists(
                utils.getRootWindow(), 'rootWnd');

        api.elements.slidecontainer = utils.assertExists(
                document.getElementById('slidecontainer'), 'slidecontainer');

        api.elements.controlPane = utils.assertExists(
                document.getElementById('controls'), 'div#controls');

        api.elements.radWnd = utils.assertExists(
                api.elements.rootWnd.GetRadWindowManager().GetActiveWindow(), 'radWnd');

        api.elements.radWndContent = api.elements.radWnd.GetContentFrame().contentWindow;
        
        api.elements.radWndWrapper = api.elements.rootWnd.
                document.getElementById('RadWindowWrapper_ContentWindow');    
        
        api.elements.rootWnd.toggleVerbosity = function() {
            api.verbose = !api.verbose;
            localStorage.setItem('de.newspm.onlineacademy.verbose', api.verbose);
            return api.verbose;
        };

        api.onReady = function(callback) {
            if (api.isReady) {
                callback(api);
            } else {
                api.events.ready.push(callback);
            }
        };

        api.onSlideChange = function(callback) {
            api.events.slideChange.push(callback);
        };

        api.onSlideClose = function(callback) {
            api.events.slideClose.push(callback);
        };

        api.addControlElement = function(controlElement) {
            if (api.verbose) console.log('API: addControlElement' , controlElement);
            api.elements.controlPane.appendChild(controlElement);
        };

        api.removeControlElement = function(selector) {
            if (api.verbose) console.log('API: removeControlElement', selector);
            var elem = api.elements.controlPane.querySelector(selector);
            if (!elem) return false;
            elem.parentNode.removeChild(elem);
            return true;
        };

        api.getLogger = function(module) {
            return (function() {
                var args = utils.toArray(arguments);
                args.unshift(module.toUpperCase() + ':');
                console.log.apply(console, args);
            });
        };

        /**
         * Gibt den Namen des Kurses (ggf. zusammen mit dem Folienname)
         * zurueck.
         * Z. Zt. gibt es zwei designs, wobei jedes eine andere Methode
         * erfordert, um den Kursnamen zu erfahren.
         */
        api.getCourseTitle = function() {
            // altes design (< 2016)
            var e = document.getElementById('storytitle_section');
            if (e && utils.isVisible(e)) return e.textContent;
            // neues design (~06/2016)
            e = api.elements.radWnd.GetTitlebar();
            if (!e) {
                console.log('API: WARNUNG, Konnte Kursnamen nicht finden, hat sich das Layout geaendert?');
                return '';
            }
            // entferne Text ab der ersten Klammer oder Close am Ende
            // (alt-text des Schliessen-buttons)
            var title = e.textContent.replace(/\(.*$/, '').replace(/Close$/, '').trim();
            return title;
        };

        api.getSlideTitle = function() {
            var e = document.querySelector('ul#slide_list > li.selected');
            return e? e.textContent : '';
        };
        return api;
    }
    // init 2}}}


    /**
     * wartet, bis der iframe, in dem die Folien-canvas liegt, dem Dokument
     * zugefuegt wurde. MutationObserver werden von IE 10 nicht unterstuetzt,
     * daher benutze ich timeouts.
     */
    // lookForCanvasFrame {{{2
    function lookForCanvasFrame(callback) {
        var timerid = setInterval(ontime, 100);
        console.log('API: lookForCanvasFrame()');
        function ontime() {
            var frame = document.getElementsByTagName('iframe');
            if (frame.length >= 1) {
                if (api.verbose) console.log('API: iframe gefunden.');
                if (frame.length > 1)
                    console.log('API: WARNUNG, habe nur einen iframe erwartet, aber mehrere gefunden! Das koennte bedeuten, dass das Skript ueberarbeitet werden muss.');
                clearInterval(timerid);
                callback(frame[0]);
                return;
            }
        }
    }
    // 2}}}

    // loadCanvasFrame {{{2
    function loadCanvasFrame(callback, canvasFrame) {
        if (api.verbose) console.log('API: loadCanvasFrame(): ', canvasFrame);
        api.elements.canvasFrame = canvasFrame;
        var doc = utils.getFrameDocument(canvasFrame);
        console.log('canvasFrame', canvasFrame, 'doc', doc, 'readyState', doc && doc.readyState);
        if (doc && doc.readyState === 'complete') {
            callback();
            return;
        } 
        
        var timeoutId = setTimeout(function() {
            if (api.verbose) console.log('API: canvas iframe wurde nicht geladen.');
            wait();
        }, 20*1000);

        canvasFrame.addEventListener('load', function() {
            if (api.verbose) console.log('API: iframe geladen');
            clearTimeout(timeoutId);
            callback();
        });
    }
    // 2}}}

    // setCanvas {{{2
    function setCanvas(callback) {
        if (api.verbose) console.log('API: setCanvas()');
        api.elements.canvasDoc = utils.assertExists(
                utils.getFrameDocument(api.elements.canvasFrame), 'canvasDoc');

        api.elements.canvasBody = utils.assertExists(
                api.elements.canvasDoc.getElementsByTagName('BODY')[0], 'body element');

        api.elements.canvas = utils.assertExists(
                api.elements.canvasDoc.getElementById('canvas'), 'canvas');

        callback();
    }
    // 2}}}

    // observeSlideChange {{{2
    function observeSlideChange(callback) {
        if (api.verbose) console.log('API: wait for slide change...');
        var slideDiv = document.getElementsByClassName('slide')[0];
        var id = slideDiv.id;
        var millis = 250;
        var timer = setInterval(function() {
            if (document.getElementById(id)) return;
            clearInterval(timer);
            if (api.verbose) console.log('API: slide change observed');
            slideClose();
            callback();
        }, millis);
    }
    // 2}}}

    // {{{2 wait
    function wait() {
        console.log('API: wait()');
        utils.async(null, observeSlideChange, lookForCanvasFrame, loadCanvasFrame, setCanvas, slideChange);
    }
    // 2}}}

    // ready {{{2
    function ready(callback) {
        if (api.verbose) console.log('API: ready()');
        api.isReady = true;
        api.events.ready.forEach(function(f) {
            f(api, 'ready');
        });
        callback();
        wait();
    }
    // 2}}}

    // slideChange {{{2
    function slideChange(callback) {
        if (api.verbose) console.log('API: slideChange');
        api.events.slideChange.forEach(function(f) {
            f(api, 'slide change');
        });
        callback();
        wait();
    }
    // 2}}}

    // slideClose {{{2
    function slideClose() {
        if (api.verbose) console.log('API: slideClose');
        api.events.slideClose.forEach(function(f) {
            f(api, 'slide close');
        });
    }
    // 2}}}

} // 1}}} ExtensionApi

                

},{"./utils.js":5}],2:[function(require,module,exports){
var initApi = require('./api.js');

/**
 * Als targets bezeichne ich alle ./targets/*.js Dateien. Diese werden via
 * browserify beim build dynamisch als 'target' geladen und geben ein array
 * mit gewuenschten Modulen zurueck, z.B. ['zoom', 'pdf'].
 */
var target = require('target');

window.addEventListener('load', function() {

    'use strict';
    var api = initApi();
    target.forEach(function(module) {
        startModule(module, api);
    });
});


function startModule(module, api) {
    if (api.verbose) console.log('loading module: ' + name);
    try {
        module(api);
    } catch (e) {
        console.log('Error caught in module ' + name + ':', e);
    }
}

},{"./api.js":1,"target":"target"}],3:[function(require,module,exports){
module.exports = antiTheft;

/**
 * Pseudo-Diebstahlsicherung, deaktiviert Kontextmenu fuer
 * Canvas. Kann unter ff mit Shift+Rechtsklick umgangen werden.
 * Fuer andere Browser sind entsprechende Erweiterungen verfuegbar.
 */
function antiTheft(api) {
    var log = api.getLogger('anti-theft');
    if (api.verbose) log('start...');
    api.onReady(disableRightClick);
    api.onSlideChange(disableRightClick);

    function disableRightClick() {
        if (api.verbose) log('disableRightClick()');
        api.elements.canvasDoc.onmousedown = function(event) {
            if (api.verbose) log('canvasDoc.onmousedown');
            if (event.button === 2) {
                return false;
            }
        };

        api.elements.canvasBody.oncontextmenu = function() {
            if (api.verbose) log('canvasBody.oncontextmenu');
            return false;
        };
    }
}

},{}],4:[function(require,module,exports){
/*
 * zoom-hack, erfindet die zoom-funktion neu.
 * debugging/problembehebung:
 * - ausfuerhliches logging ein/ausschalten:
 *     in der konsole toggleverbosity() tippen und mit enter bestaetigen.
 * - zoom zuruecksetzen:
 *     a) umschalt+linksklick auf die folie oder
 *     b) zoom.reset() in der konsole eingeen.
 * - zoom manuell festlegen:
 *     zoom.set(factor) in der konsole eingeben, wobei factor = prozent/100,
 *     100% entspricht factor=1.0
 *
 *
 * falls sich der seitenaufbau aendert, muss dieses skript ggf. angepasst werden.
 * verhalten:
 * - setzt die css width/height properties der folie auf je 100%, dadurch
 *   passt sich diese auch unter chrome der groesse des umgebenden iframe an.
 * - fuegt dem control pane ein menue hinzu aus dem der user die gewuenschte
 *   zoomstufe auswaehlen kann.
 * - das script reagiert auf groessenaenderungen des radwindow und stellt den
 *   dadurch erreichten zoom nummerisch dar. 
 * - deaktiviert die (ueberfluessigen) scrollbars des radwindow contentframes
 */

module.exports = zoom;
var utils = require('./../utils.js');


function zoom(api) {
    "use strict";
    var log = api.getLogger('zoom');
    if (api.verbose) log('start...');
    
    // diese zoomfaktoren werden dem zoommenue hinzugefuegt (1.0 entspricht 100%):
    var scaleFactors = [1.0, 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 2.0];
    var zoomPreferenceKey = 'de.newspm.onlineacademy.user_zoom';
    var zoomControlId = 'control-zoom';
    var zoomControl, canvasMinWidth, canvasMinHeight;
    var isMobileOrTouch;
    var zoomSelect;

    // globale funktionen, bei problemen:
    api.elements.rootWnd.zoom = {};
    api.elements.rootWnd.zoom.select = onZoomSelected;
    api.elements.rootWnd.zoom.reset = onZoomSelected.bind(null, 1);

    
    // massstab zur berechnung der skalierung: 
    var initialWndWidth = api.elements.radWnd.GetWidth();
    var initialWndHeight = api.elements.radWnd.GetHeight();

    // verstecke ueberfluessige scrollbars:
    api.elements.body.style.overflow = 'hidden';

    api.onReady(ready);
    api.onSlideChange(ready);

    function ready(api, evt) {
        if (api.verbose) log(evt);
        if (evt === 'ready') {       
            var touch = utils.isTouchSupported();
            var mobile = utils.isMobileUserAgent();
            var small = Math.max(screen.width, screen.height) < 998;
            isMobileOrTouch = (touch || mobile || small);
            if (api.verbose) log('touch=' + touch, 'mobile-ua=' + mobile, 'small=' + small);
        }
        setupCanvas();
        if (isMobileOrTouch) return;
        setupWindowResizeHandler();
        setupZoomControl(evt);
        if (evt === 'ready') loadUserPref();
        // shift+click setzt den zoom zurueck:
        api.elements.canvasDoc.documentElement.addEventListener('click', function(ev) {
            if (!ev.shiftKey) return;
            onZoomSelected(1);
            zoomSelect.value = 1;
        });
    }

    
    function setupCanvas() {
        canvasMinWidth = api.elements.canvas.clientWidth;
        canvasMinHeight = api.elements.canvas.clientHeight;

        utils.addStyleSheet(api.elements.canvasDoc, "#canvas {\n" +
        "   min-width: " + canvasMinWidth + "px !important;\n" +
        "   min-height: " + canvasMinHeight + "px !important;\n" +
        "   width: 100%;\n" +
        "   height: 100%;\n" +
        "}");
    }
    
    function setupWindowResizeHandler() {
        // verarbeite maximal 10 resize events pro sekunde:
        var resizeTimeout;
        window.addEventListener('resize', function() {
            if (!resizeTimeout) {
                resizeTimeout = setTimeout(function() {
                    resizeTimeout = null;
                    onRadWindowResize();
                }, 100); 
            }
        }, false);
    }

    /**
     * fuegt unterhalb der Folie ein drop-down Menue ein, mit dem unter den in 
     * ZOOM_LEVELS definierten Skalierungsstufen gewaehlt werden kann.
     */
    // setupZoomControl {{{2
    function setupZoomControl(evt) {
        if (evt === 'ready') {
            zoomSelect = document.createElement('select');
            zoomSelect.id = "zoomlvl-menu";
            zoomSelect.style.height = '20px';
            zoomSelect.style.verticalAlign = 'text-bottom';
            zoomSelect.style.marginLeft = '1em';
            var zoomSelectInner = [];
            scaleFactors.forEach(function(value) {
                zoomSelectInner.push('<option value="' + value + '">' + Math.floor(value * 100) + '%</option>\n');
            });
            zoomSelect.innerHTML = zoomSelectInner.join('') + '</select>\n\t';

            var label = document.createElement('div');
            label.className = 'label';
            label.innerText = 'Größe:';
            label.appendChild(zoomSelect);

            var zoomControl = document.createElement('div');
            zoomControl.className = 'controlbar-button';
            zoomControl.id = zoomControlId;
            zoomControl.appendChild(label);
            zoomControl.style.paddingBottom = '3px';
            zoomControl.style.paddingTop = '2px';
            api.addControlElement(zoomControl);
        }
        zoomSelect.onchange = function(event) {
            onZoomSelected(event.target.value);
        };
    }
    // 2}}}
    
    function measureZoom() {
        var sx = api.elements.radWndWrapper.clientWidth / initialWndWidth;
        var sy = api.elements.radWndWrapper.clientHeight / initialWndHeight;
        return Math.min(sx, sy);
    }
    
    
    /**
     * Skaliert die Folie entsprechend des vom User gewaehlten Faktors.
     * @param {number} factor, positiver Groessenfaktor, 1.0 = 100%
     */
    function onZoomSelected(factor) {
        utils.assert(factor && factor > 0, "setZoom: Falscher Paramter '" + factor + "', erwarte (factor > 0)");
        if (api.verbose) log("Skaliere auf " + factor);
        var newWidth = initialWndWidth * factor,
            newHeight = initialWndHeight * factor;
        api.elements.radWnd.SetSize(newWidth, newHeight);
        api.elements.radWnd.Center();
        saveUserPref(factor);
    }
    
    
    /**
     * Passt den Zoomfaktor im Menue der neuen Groesse des RadWindow an.
     */
    function onRadWindowResize() {
        var scale = Math.round(measureZoom() * 10) / 10;
        if (api.verbose) log('onWindowResize: scale=' + scale);
        var i = utils.getFloatInArray(scale, scaleFactors, 0.1);
        if (i) zoomSelect.value = scaleFactors[i];
        saveUserPref(scale);
    }

    function loadUserPref() {
        var savedScale = localStorage.getItem(zoomPreferenceKey);
        if (savedScale) {
            onZoomSelected(savedScale);
            var i = utils.getFloatInArray(savedScale, scaleFactors, 0.1);
            if (i) zoomSelect.value = scaleFactors[i];
        }
    }
    
    function saveUserPref(n) {
        localStorage.setItem(zoomPreferenceKey, ''+n);
    }
    
} // end zoom()

},{"./../utils.js":5}],5:[function(require,module,exports){
// Utils
utils = {};
module.exports = utils;

// MutationObserver alternative wegen ie10
// wartet, bis ein bestimmtes element hinzugefuegt wurde.
// waitForChild {{{1
utils.waitForChild = function(element, selector, callback, interval) {
    interval = interval || 100;
    var timerid = setTimeout(ontime, interval);
    function ontime() {
        if (element.childElementCount === 0) return;
        var child = element.querySelector(selector);
        if (child) callback(child);
        else timerid = setTimeout(ontime, interval);
    }
};
// 1}}}

/**
 * gibt true zurueck falls das touch api verfuegbar ist.
 * Touch api ist leider nicht 100% zuverlaessig.
 * @returns {boolean}
 */
// isTouchSupported? {{{1
utils.isTouchSupported = function() {
    var msTouchEnabled = window.navigator.msMaxTouchPoints;
    var generalTouchEnabled = "ontouchstart" in document.createElement("div");
    return msTouchEnabled || generalTouchEnabled;
};
// 1}}}
        
/**
 * gibt true zurueck, falls der user agent auf ein Mobilgeraet schliessen laesst.
 * nur bedingt zuverlaessig, da nicht standartisiert.
 * @returns {boolean}
 */
// isMobileUserAgent? {{{1
utils.isMobileUserAgent = function() {
    var agent = navigator.userAgent || navigator.vendor || window.opera;
    return /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od|ad)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(agent) || 
           /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(agent.substr(0, 4));
};
// 1}}}

/**
 * Sucht eine Zahl im gegebenen Array, die von der gegebenen Zahl f 
 * um nicht mehr als epsilon abweicht.
 * @param {number} f, die Zahl nach der gesucht werden soll.
 * @param {number[]} arr, das Array das durchsucht werden soll.
 * @param {number} epsilon, die maximale Abweichung. Wenn nicht gegeben, wird Number.EPSILON verwendet.
 * @returns {number} der Index der gefundenen Zahl oder undefined, wenn keine gefunden wurde.
 */
// getFloatInArray {{{1
utils.getFloatInArray = function(f, arr, epsilon) {
    epsilon = epsilon || Number.EPSILON;
    for (var i = 0, len = arr.length; i < len; i++)
        if ((Math.abs(f - arr[i])) <= epsilon) return i;
};
// 1}}}

/** 
 * gibt das document element des gegebenes iframes zurueck. 
 * @param elem {HTMLElement} - der iframe, dessen document zurueck gegeben werden soll
 * @returns {HTMLDocument}
 */ 
// getFrameDocument {{{1
utils.getFrameDocument = function(elem) {
    var ans = elem.contentWindow.contentDocument || elem.contentWindow.document;
    utils.assert(ans, 'Konnte frame document nicht finden!');
    return ans;
};
// 1}}}

// addStyleSheet {{{1
utils.addStyleSheet = function(doc, rules) {
    var css = doc.createElement('style');
    css.type = 'text/css';
    if (css.styleSheet) css.styleSheet.cssText = rules;
    else css.appendChild(doc.createTextNode(rules));
    doc.getElementsByTagName("head")[0].appendChild(css);
    return css;
};
// 1}}}

/** 
 * Gibt true zurueck, falls <elem> das Tag <tagname> hat und alle in <classes> definierte Klassen.
 * @param elem {HTMLElement}
 * @param tagname {string}
 * @param classes {string[]}Var i =
 * @param id {string}
 */
// doesElemMatch {{{1
utils.doesElemMatch = function(elem, tagname, classes, id) {
    if (tagname && elem.tagName !== tagname.toUpperCase()) return false;
    if (id && elem.id !== id) return false;
    if (!classes) return true;
    for (var j = 0, len = classes.length; j < len; j++) {
        if (!elem.classList.contains(classes[j])) return false;
    }
    return true;
};
// 1}}}

/** 
 * Sucht ein Element in <elems>, das das Tag <tagname> hat und alle in <classes> definierten Klassen.
 * Gibt das gefundene Element zurueck, oder null, falls keines gefunden wurde.
 * @param elem {HTMLElement}
 * @param tagname {string}
 * @param classes {string[]}
 */
// findElement {{{1
utils.findElement = function(elems, tagname, classes, id) {
    var elem;
    for (var i = 0, len = elems.length; i < len; i++) {
        elem = elems[i];
        if (utils.doesElemMatch(elem, tagname, classes, id)) return elem;
    }
    return null;
};
// 1}}}

/** Gibt das oberste DOM Fenster zurueck.
 * @returns {Window}, das oberste Fenster 
*/
// getRootWindow {{{1
utils.getRootWindow = function() {
    var wnd, root;
    do {
        wnd = root || window;
        root = wnd.parent;
    } while (root !== wnd);
    return root;
};
// 1}}}

// isVisible? {{{1
utils.isVisible = function(elem) {
    return !!(elem.offsetParent || elem.offsetWidth || 
            elem.offsetHeight || elem.getClientRects().length);
};
// 1}}}

// toArray {{{1
utils.toArray = function(arraylike) {
    var arr = [];
    for (var i = 0; i < arraylike.length; i++)
        arr[i] = arraylike[i];
    return arr;
};
// 1}}}

/*
 * async - fuehrt mehrere voneinander abhaengige funktionen asynchron aus.
 * @param initial {any} Der Wert, der der ersten Funktionbb uebergeben werden soll.
 * @param tasks {function...} ein oder mehr Argumente. Jede Funktion muss ein callback
 *                            und das Ergebnis des vorherigen Tasks entgegen nehmen.
 *                            Liegt ein Ergebnis vor, muss die callback-funktion damit
 *                            aufrufen werden. 
 *                            Zum Abbruch der Kette muss ein Fehler geworfen werden.
 */
// async {{{1
utils.async = function(initial, tasks) {
  if (arguments.length === 0) throw new Error('argument required');
  var chain = utils.toArray(arguments).slice(1);
  var head = -1;
  var top = chain.length - 1;
  var id = utils.nextUid();

  callback(initial);

  function callback(result) {
    head++;
//    console.log('[async#'+id+'] head:', head, 'result:', result);
    if (head > top) {
//        console.log('[async#'+id+'] head:', head, 'result:', result, 'DONE');
        return;
    }
    var task = chain[head];
    task(callback, result);
  }
};
// 1}}}

var uid = 0;
utils.nextUid = function() {
    return uid++;
};

utils.findInArray = function(arr, predicate) {
    for (var i = 0; i < arr.length; i++)
        if (predicate(arr[i])) return arr[i];
};


/**
 * Erzeugt einen Fehler, wenn cond false ist.
 * @param {boolean} cond, Die zu pruefende Bedingung.
 * @param {string} msg, Die Meldung, die im Fall eines Fehlers ausgegeben werden soll.
 */
utils.assert = function(cond, msg) {
    if (!cond) throw new Error(msg || 'Assertion failed.');
};

utils.assertExists = function(obj, name) {
    if (obj !== null && obj !== undefined) return obj;
    throw new Error(name + ' is undefined or null.');
};


},{}],"target":[function(require,module,exports){
var zoom = require('../modules/zoom.js');    
var atheft = require('../modules/anti-theft.js');
module.exports = [zoom, atheft];

},{"../modules/anti-theft.js":3,"../modules/zoom.js":4}]},{},[2]);
