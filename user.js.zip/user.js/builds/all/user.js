require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({1:[function(require,module,exports){
"use static";
var utils = require('./utils.js');
module.exports = extensionApi;

/*
 * ExtensionApi: {
 *  verbose: {boolean}
 *  isReady: {boolean}
 *  getLogger("module_name") : {string => ()}
 *  getCourseTitle(): {string}
 *  getSlideTitle(): {string}
 *
 * events:
 *  onReady(callback: API => ());
 *  onSlideChange(callback: (API, 'slide change') => ());
 *  onSlideClose(callback: (API, 'slide close') => ());
 *
 * HTML-elemente:
 *  elements: {
 *      document
 *      body: body Element der story.html (im Rad-Window)
 *      rootWnd: das oberste window
 *      slidecontainer: 
 *          in der story.html, beinhaltet den iframe mit der Folie,
 *          wird dynamisch ins DOM eingefuegt.
 *      radWnd: die aktive RadWindow Instanz
 *      radWndContent,
 *      radWndWrapper,
 *      canvasFrame,
 *      canvas
 *  }
 *
 * }
 *

// {{{1 ExtensionApi
/**
 *  Stellt grundlegende Funktionen bereit, mit denen Erweiterungen einfacher 
 *  realisiert werden koennen.
 *
 *  - beobachtet und reagiert auf den Ladevorgang des Kurses
 *  - stellt ein Eventsystem bereit, um auf das Oeffnen und Schliessen von
 *    Folien reagieren zu koennen.
 *  - haelt alle relevanten HTML Elemente unter api.elements vor.
 *
 * @returns {object} Das api Objekt, ueber das Erweiterungen auf die o.g.
 *                   Funktionen zugreifen koennen.
 */
function extensionApi(logger) {
    var api = {};
    init();
    return api;

    // {{{2 init()
    function init() {
        api.logger = logger.derive('API');
        api.preload = preload;
        api.load = load;
        api.isReady = false;
        api.state = 'init';


        // nur loggen wenn api.verbose:
        api.verbose = !!(localStorage && localStorage.getItem(
                    'de.newspm.onlineacademy.verbose') === 'true');
        if (api.verbose) {
            logger.setLevel(logger.LEVEL_ALL);
        }
        api.modules = {};
        api.events = {ready:[], slideChange:[], slideClose:[]};
        api.onPreload = function(callback) {

        };
        api.onReady = function(callback) {
            if (api.isReady) {
                callback(api);
            } else {
                api.events.ready.push(callback);
            }
        };
        api.onSlideChange = function(callback) {
            api.events.slideChange.push(callback);
        };
        api.onSlideClose = function(callback) {
            api.events.slideClose.push(callback);
        };
        api.registerModule = function(name, module) {
            api.modules[name] = module;
        };

        api.services = {};
        api.addService = function(name, fn) {
            utils.assertExists(name, 'name');
            utils.assertExists(fn, 'fn');
            api.services[name] = fn;
        };
        api.hasService = function(name) {
            return api.services.hasOwnPorperty(name);
        };
        api.request = function(name, param) {
            var fn = api.services[name];
            if (!fn || !api.services.hasOwnProperty(name)) {
                api.logger.warning('no service: ' + name);
                return;
            }
            return fn(param);
        };
    }
    // init 2}}}


    function preload() {  
        api.state = 'preload';      
        // in general, moduls should not hold references to DOM elements
        api.elements = {
            document: document,
            body: document.getElementsByTagName('BODY')[0],
            rootWnd: utils.getRootWindow(),
            slidecontainer: document.getElementById('slidecontainer'),
            slideframe: document.getElementById('slideframe'),
            controlPane: document.getElementById('controls'),
            topbar: document.getElementById('topbar')
        };
        api.elements.radWnd = api.elements.rootWnd.GetRadWindowManager().GetActiveWindow();
        api.elements.radWndContent = api.elements.radWnd.GetContentFrame().contentWindow;
        api.elements.radWndWrapper = api.elements.rootWnd.document.getElementById('RadWindowWrapper_ContentWindow');    

        Object.keys(api.elements).forEach(function(k) {
            if (!api.elements.hasOwnProperty(k)) return;
            utils.assertExists(api.elements[k], k);
        });

        // optional elements:
        api.elements.infoButton = api.elements.topbar;

        api.elements.rootWnd.toggleVerbosity = function() {
            api.verbose = !api.verbose;
            localStorage.setItem('de.newspm.onlineacademy.verbose', api.verbose);
            return api.verbose;
        };
        api.elements.rootWnd.toggleDebug = function() {
            api.debug = !api.debug;
            api.elements.rootWnd.extapi = api.debug? api : undefined;
            localStorage.setItem('de.newspm.onlineacademy.debug', api.debug);
            return api.debug;
        };

        /**
         * Gibt den Namen des Kurses (ggf. zusammen mit dem Folienname)
         * zurueck.
         * Z. Zt. gibt es zwei designs, wobei jedes eine andere Methode
         * erfordert, um den Kursnamen zu erfahren.
         */
        api.getCourseTitle = function() {
            // altes design (< 2016)
            var e = document.getElementById('storytitle_section');
            if (e && utils.isVisible(e)) return e.textContent;
            // neues design (~06/2016)
            e = api.elements.radWnd.GetTitlebar();
            if (!e) {
                api.logger.warning('Konnte Kursnamen nicht finden, hat sich das Layout geaendert?');
                return '';
            }
            // entferne Text ab der ersten Klammer oder Close am Ende
            // (alt-text des Schliessen-buttons)
            var title = e.textContent.replace(/\(.*$/, '').replace(/Close$/, '').trim();
            return title;
        };

        api.getSlideTitle = function() {
            var e = document.querySelector('ul#slide_list > li.selected');
            return e? e.textContent : '';
        };
    }

    function load() {
        api.state = 'load';
        utils.async(null, lookForCanvasFrame, loadCanvasFrame, setCanvas, ready);
    }

    /**
     * wartet, bis der iframe, in dem die Folien-canvas liegt, dem Dokument
     * zugefuegt wurde. MutationObserver werden von IE 10 nicht unterstuetzt,
     * daher benutze ich timeouts.
     */
    // lookForCanvasFrame {{{2
    function lookForCanvasFrame(callback) {
        var timerid = setInterval(ontime, 100);
        api.logger.info('lookForCanvasFrame()');
        function ontime() {
            var frame = document.getElementsByTagName('iframe');
            if (frame.length >= 1) {
                api.logger.info('iframe gefunden.');
                if (frame.length > 1)
                    api.logger.warning('habe nur einen iframe erwartet, aber mehrere gefunden! Das koennte bedeuten, dass das Skript ueberarbeitet werden muss.');
                clearInterval(timerid);
                callback(frame[0]);
                return;
            }
        }
    }
    // 2}}}

    // loadCanvasFrame {{{2
    function loadCanvasFrame(callback, canvasFrame) {
        api.logger.info('loadCanvasFrame(): ', canvasFrame);
        api.elements.canvasFrame = canvasFrame;
        api.elements.canvasWindow = canvasFrame.contentWindow;
        var doc = utils.getFrameDocument(canvasFrame);
        api.logger.info('canvasFrame', canvasFrame, 'doc', doc, 'readyState', doc && doc.readyState);
        if (doc && doc.readyState === 'complete') {
            callback();
            return;
        } 
        // in 20 secs. assume the loading failed 
        var timeoutId = setTimeout(function() {
            api.logger.info('canvas iframe wurde nicht geladen.');
            wait();
        }, 20*1000);

        canvasFrame.addEventListener('load', function() {
            api.logger.info('iframe geladen');
            clearTimeout(timeoutId);
            callback();
        });
    }
    // 2}}}

    // setCanvas {{{2
    function setCanvas(callback) {
        api.logger.info('setCanvas()');
        api.elements.canvasDoc = utils.assertExists(
                utils.getFrameDocument(api.elements.canvasFrame), 'canvasDoc');

        api.elements.canvasBody = utils.assertExists(
                api.elements.canvasDoc.getElementsByTagName('BODY')[0], 'body element');

        api.elements.canvas = utils.assertExists(
                api.elements.canvasDoc.getElementById('canvas'), 'canvas');

        callback();
    }
    // 2}}}

    // observeSlideChange {{{2
    function observeSlideChange(callback) {
        api.logger.info('wait for slide change...');
        var slideDiv = document.getElementsByClassName('slide')[0];
        var id = slideDiv.id;
        var millis = 250;
        var timer = setInterval(function() {
            if (document.getElementById(id)) return;
            clearInterval(timer);
            api.logger.info('slide change observed');
            slideClose();
            callback();
        }, millis);
    }
    // 2}}}

    // {{{2 wait
    function wait() {
        api.logger.info('wait()');
        utils.async(null, observeSlideChange, lookForCanvasFrame, loadCanvasFrame, setCanvas, slideChange);
    }
    // 2}}}

    // ready {{{2
    function ready(callback) {
        api.logger.info('READY.');
        api.state = 'ready';
        api.events.ready.forEach(function(f) {
            try {
                f(api, 'ready');
            } catch (e) {
                api.logger.error('Exception raised in ready listener:', e);
            }
        });
        callback();
        wait();
    }
    // 2}}}

    // slideChange {{{2
    function slideChange(callback) {
        api.logger.info('slideChange');
        api.events.slideChange.forEach(function(f) {
            try {
                f(api, 'slide change');
            } catch (e) {
                api.logger.error('Exception raised in "slide change" listener:', e);
            }
        });
        callback();
        wait();
    }
    // 2}}}

    // slideClose {{{2
    function slideClose() {
        api.logger.info('slideClose');
        api.events.slideClose.forEach(function(f) {
            try {
                f(api, 'slide close');
            } catch (e) {
                api.logger.error('Exception raised in "slide close " listener:', e);
            }
        });
    }
    // 2}}}

} // 1}}} ExtensionApi

                

},{"./utils.js":8}],2:[function(require,module,exports){
"use static";
// mehr fp fuer es5
var f = {};
module.exports = f;

f.aiter = function(arr, fn) {
    for (var i = 0; i < arr.length; i++) fn(arr[i], i, arr);
};

f.aexists = function(arr, fn) {
    return f.afindIndex(arr, fn) > -1;
};

f.afindIndex = function(arr, fn) {
    for (var i = 0; i < arr.length; i++) {
        if (fn(arr[i], i, arr)) return i;
    }
    return -1;
};

f.afind = function(arr, fn) {
    var n = f.afindIndex(arr, fn);
    return n >= 0? arr[n] : null;
};

// map([a']) => [b']
f.amap = function(arr, fn) {
    var ans = Array(arr.length);
    f.aiter(arr, function(x, i, arr) {
        ans[i] = fn(x, i, arr);
    });
    return ans;
};

f.foldRight = function(arr, acc, fn) {
    f.aiter(arr, function(x, i, arr) {
        acc = fn(acc, x, i, arr);
    });
    return acc;
};

f.afilter = function(arr, fn) {
    var ans = [];
    f.aiter(arr, function(x, i) {
        if (fn(x, i, arr)) ans.push(x);
    });
    return ans;
};

f.agen = function(fn, start) {
    var i = start || 0;
    var arr = [];
    while (true) {
        var x = fn(i++);
        console.log(x);
        if (x === undefined) return arr;
        arr.push(x);
    }
};

},{}],3:[function(require,module,exports){
var LEVEL_DETAIL = 3,
    LEVEL_INFO = 2,
    LEVEL_WARN = 1,
    LEVEL_ERROR = 0,
    LEVEL_NONE = 0,
    LEVEL_ALL = Infinity;

var LEVELS = [
    {str: '(EE)', fn: function() {
        console.error.apply(console, arguments);                            
    }}, 
    {str: '(WW)'}, 
    {str: '(II)'},
    {str: '(DD)'}
];

var loggers = {
};

function defaultLogFn() {
    console.log.apply(console, arguments);
}

module.exports = Logger;

function Logger(name, level, parent) {
    this.name = name;
    this.parent = parent;
    if (typeof level !== 'undefined') this.logLevel = level;
    this.error = this.log.bind(this, LEVEL_ERROR);
    this.warning = this.log.bind(this, LEVEL_WARN);
    this.info = this.log.bind(this, LEVEL_INFO);
    loggers[name] = this;
}

Logger.prototype.getLoggerByName = getLoggerByName;

Logger.prototype.derive = function(name, level) {
    return new Logger(name, level, this);
};

Logger.prototype.log = function(level) {
    var logLevel = this.getLevel();
    if (level > logLevel) return;
    if (arguments.length <= 1) {
        throw new Error('log requires at least 2 arguments.');
    }
    var args = Array(arguments.length-1);
    for (var i = 1; i < arguments.length; i++) {
        args[i-1] = arguments[i];
    }
    var levelStr, fn;
    if (level >= 0 && level < LEVELS.length) {
        levelStr = LEVELS[level].str;
        fn = LEVELS[level].fn || defaultLogFn;
    } else {
        levelStr = '(' + level + ')';
        fn = defaultLogFn;
    }
    var ans = [levelStr + ' ' + this.name.toUpperCase() + ': '].concat(args);
    fn.apply(null, ans);
};

Logger.prototype.LEVEL_NONE = LEVEL_NONE;
Logger.prototype.LEVEL_ERROR = LEVEL_ERROR;
Logger.prototype.LEVEL_WARN = LEVEL_WARN;
Logger.prototype.LEVEL_INFO = LEVEL_INFO;
Logger.prototype.LEVEL_DETAIL = LEVEL_DETAIL;
Logger.prototype.LEVEL_ALL = LEVEL_ALL;

Logger.prototype.setLevel = function(level) {
    if (level !== 'undefined' && typeof level !== 'number') 
        throw new Error('setLevel: must be a number');
    this.logLevel = level;
};


Logger.prototype.getLevel = function() {
    var curr = this;
    while (curr && typeof curr.logLevel === 'undefined') curr = curr.parent;
    if (!curr) return LEVEL_NONE;
    return curr.logLevel;
};

function getLoggerByName(name) {
    return loggers.hasOwnProperty(name) && loggers[name];
}

},{}],4:[function(require,module,exports){
'use strict';

/* Als targets bezeichne ich alle ./targets/*.js Dateien. Diese werden via
 * browserify beim build dynamisch als 'target' geladen und geben ein array
 * mit gewuenschten Modulen zurueck, z.B. ['zoom', 'pdf'].
 */
var target = require('target');
var initApi = require('./api.js');
var Logger = require('./logger.js');
var f = require('./f.js');
        
(function main() {

    var logger = new Logger('main', Logger.LEVEL_NONE);
    var moduleNames = getValidModuleNames();
    var api = initApi(logger);

    window.addEventListener('DOMContentLoaded', api.preload);
    window.addEventListener('load', api.load);

    f.aiter(moduleNames, startModule);
    
    function startModule(name) {
        var module = target[name];
        try {
            module(api, logger);
            api.registerModule(name, module);
        } catch (e) {
            logger.error('Fehler in Modul ' + name + ':', e);
        }
    }

    function getValidModuleNames() {
        return f.afilter(Object.keys(target), function(key) {
            if (typeof target[key] === 'function') return true;
            logger.error('Invalid module, not a function:', key, target[key]);
        });
    }

})();


},{"./api.js":1,"./f.js":2,"./logger.js":3,"target":"target"}],5:[function(require,module,exports){
"use strict";
module.exports = antiTheft;

/**
 * Pseudo-Diebstahlsicherung, deaktiviert Kontextmenu fuer
 * Canvas. Kann unter ff mit Shift+Rechtsklick umgangen werden.
 * Fuer andere Browser sind entsprechende Erweiterungen verfuegbar.
 */
function antiTheft(api, logger) {
    logger.info('START');
    api.onReady(disableRightClick);
    api.onSlideChange(disableRightClick);

    function disableRightClick() {
        logger.info('disableRightClick()');
        api.elements.canvasDoc.onmousedown = function(event) {
            logger.info('canvasDoc.onmousedown');
            if (event.button === 2) {
                return false;
            }
        };

        api.elements.canvasBody.oncontextmenu = function() {
            logger.info('canvasBody.oncontextmenu');
            return false;
        };
    }
}

},{}],6:[function(require,module,exports){
"use static";
/*
 * 
 *
 * This module puts a function in the slide's global environment.
 * When called (by the slide), a black panel with white text fades in from the 
 * right, indicating that the slide has ended.
 *
 * A variety of messagess can be shown. However, some constraints apply:
 * - a 'you're halfway done' message only makes sense when this statement is true.
 * - the same message should not be shown twice in a row.
 * - the algorithm choosing a message should be deterministic.
 * - in the first, last and second-to-last slide, special messages should be shown.
 *
 * Additional user stories:
 * - I can test the slide outside of the LMS and it logs the message in the 
 *   console.
 * - From within the slide I can adjust the messages to be shown.
 * - If the slide does not use this module, it should still work as intended.
 */
var utils = require('../utils.js');
var f = require('../f.js');

module.exports = endPrompt;

var style = "#end {\n" +
"    position: absolute;\n" +
"    bottom: 12px;\n" +
"    right: -12px;\n" +
"    background-color: rgba(51, 51, 51, .8);\n" +
"    color: gainsboro;\n" +
"    font-family: Arial, Sans-Serif;\n" +
"    font-size: 10pt;\n" +
"    font-weight: 100;\n" +
"    padding: 12px 36px 12px 12px;\n" +
"    transform: translateX(100%);\n" +
"}\n" +

"#end.animate {\n" +
"    animation-duration: 1s;\n" +
"    -webkit-animation-duration: 1s;\n" +
"    -moz-animation-duration: 1s;\n" +

"    animation-name: slide-in;\n" +
"    -webkit-animation-name: slide-in;\n" +
"    -moz-animation-name: slide-in;\n" +

"    animation-timing-function: ease-out, ease-in;\n" +
"    -webkit-animation-timing-function: ease-out, ease-in;\n" +
"    -moz-animation-timing-function: ease-out, ease-in;\n" +
"    transform: translateX(0);\n" +
"    -moz-transform: translateX(0);\n" +
"    -webkit-transform: translateX(0);\n" +
"}\n" +

"@keyframes slide-in {\n" +
"    from {\n" +
"        transform: translateX(100%);\n" +
"    }\n" +
"    67% {\n" +
"        transform: translateX(-12px);\n" +
"    }\n" +
"    to {\n" +
"        transform: translateX(0);\n" +
"    }\n" +
"}\n" +

"@-webkit-keyframes slide-in {\n" +
"    from {\n" +
"        transform: translateX(100%);\n" +
"        -webkit-transform: translateX(0);\n" +
"    }\n" +
"    67% {\n" +
"        transform: translateX(-12px);\n" +
"        -webkit-transform: translateX(-12px);\n" +
"    }\n" +
"    to {\n" +
"        transform: translateX(0);\n" +
"        -webkit-transform: translateX(0);\n" +
"    }\n" +
"}\n" +

"@-moz-keyframes slide-in {\n" +
"    from {\n" +
"        transform: translateX(100%);\n" +
"        -moz-transform: translateX(100%);\n" +
"    }\n" +
"    67% {\n" +
"        transform: translateX(-12px);\n" +
"        -moz-transform: translateX(-12px);\n" +
"    }\n" +
"    to {\n" +
"        transform: translateX(0);\n" +
"        -moz-transform: translateX(0);\n" +
"    }\n" +
"}";

/*
 * messages:
 * Enhaelt eine Liste der Texte, die in Endsprechblasen erscheinen sollen
 * sowie die Folienindezes, fuer die sie gelten. 
 * Die Liste wird der Reihe nach abgearbeitet, bis ein passender Eintrag gefunden
 * wurde.   
 *
 * slide: 
 *  - der Folienindex, beginnend bei 0.
 *  - Ein negativer Folienindex wird vom Ende gezaehlt, -1 beschreibt die letzte 
 *    Folie, -2 die vorletzte usw.
 *  - Ein Dezimalwert zwischen 0 und 1 entspricht einem prozentualen Wert, d.h:
 *    0.5 => 50% => die 5. Folie von 10 oder die 4. Folie von 7.
 *  - "any" trifft auf jede Folie zu und sollte daher nur am Ende der Liste
 *    vorkommen.
 *
 * minSlideCount:
 * Die Mindestanzahl an Folien die ein Kurs haben muss, damit dieser Eintrag
 * anwendbar ist. Insb. nuetzlich fuer prozentuale slide-Werte bei sehr kleinen
 * Kursen. 
 *
 * prompts:
 * Eine Liste der zulaessigen Texte. Der zu waehlende Text wird mithilfe des
 * Folienindexes berechnet, dadurch ist er fuer eine bestimmte Folie immer 
 * derselbe und aufeinander folgende Wiederholungen sind ausgeschlossen.
 *
 */


var settings = {
    "ignore": [1],
    "messages": [
        {"slide": 0, "prompts": [
            "Jetzt kann es losgehen."
        ]},
        {"slide": -1, "prompts": [
            "Geschafft!"
        ]},
        {"slide": -2, "prompts": [
            "Fast geschafft."
        ]},
        {"slide": -3, "prompts": [
            "Endspurt!",
            "Noch ein Kapitel.",
            "Nur noch ein Thema."
        ]},
        {"slide": 0.75, "minSlideCount": 10, "prompts": [
            "Nur noch ein paar Kapitel.",
            "Nur noch ein paar Themen."
        ]},
        {"slide": 0.5, "prompts": [
            "Die Hälfte ist geschafft."
        ]},
        {"slide": "any", "prompts": [
            "Fahren Sie bitte fort.",
            "Weiter geht’s!",
            "Und weiter …",
            "Weiter geht’s zum nächsten Kapitel!",
            "Auf geht’s zum nächsten Kapitel!",
            "Im nächsten Kapitel geht es weiter.",
            "Sehen wir uns das nächste Kapitel an.",
            "Es kann weitergehen."
        ]}
    ]
};



function endPrompt(api, logger) {
    logger.info('START');
    logger.info('Trying to load settings.json...'); 
    setTimeout(loadJson, 3000);
    api.onReady(ready);
    api.onSlideChange(setupSlide.bind(null, undefined));
    var prompts;
    var xhrSettled = false;
    var isReady = false;
    var xhrStart;
    function loadJson() {
        xhrStart = Date.now(); 
        utils.xhr('./story_content/settings.json', function(evt) {
            var timeTaken = Date.now() - xhrStart;
            logger.info('xhr response in ', timeTaken, 'ms');
            if (evt.target.responseURL.endsWith('settings.json')) {
                json = evt.target.response;
                var ans;
                try {
                    ans = JSON.parse(json);
                } catch (e) {
                    logger.error("Couldn't parse json:", json);
                }
                if (ans) {
                    settings = ans;
                    logger.info('loaded settings.json:', evt);
                }
            } else {
                logger.info('Unable to load settings.json:', evt);
            }
            xhrSettled = true;
            if (isReady) ready();     
        }, function(evt) {
            logger.info('Unable to load settings.json:', evt); 
            xhrSettled = true;
            if (isReady) ready();
        }, 'application/json');
    }

    function ready() {
        isReady = true;
        if (!xhrSettled) return;
        var courseTitle = api.getCourseTitle();
        var hash = Math.abs(utils.hashString(courseTitle || ''));
        var toc = api.request('toc-leaves-only', settings.ignore);
        logger.info('READY, hash:', hash, 'course title:', courseTitle, 'toc:', toc);
        var slideCount = toc && toc.chapters.length || 0;   
        settings.messages = filterInvalidMessages(settings.messages, logger, slideCount);
        prompts = getAllPrompts(settings, slideCount, hash); 
        logger.info('prompts: ', prompts);
        setupSlide(toc);
    }

    function setupSlide(toc) {
        toc = toc || api.request('toc-leaves-only', settings.ignore);
        logger.info('setupSlide, toc:', toc || 'none');
        var prompt;
        if (toc && (toc.selected || toc.selected === 0) && 
                prompts && prompts.length > toc.selected) 
        {
            prompt = prompts[toc.selected];
        } else {
            prompt = "Weiter geht's.";
        }
        var end = api.elements.canvasDoc.createElement('div');
        end.id = 'end';
        end.innerText = prompt;
        utils.addStyleSheet(api.elements.canvasDoc, style);
        var container = api.elements.canvasDoc.getElementById('dom_overlay_container');
        logger.info('appending to container: ', container, end);
        container.appendChild(end);

        api.elements.canvasWindow.endSlide = function(p) {
            if (p) end.innerText = p;
            end.className = "animate";
        };
        api.elements.canvasWindow.resetEnd = function() {
            end.className = '';
        };
    }
 
    function getAllPrompts(settings, slideCount, offset) {
        var ans = Array(slideCount);
        for (var i = 0; i < slideCount; i++) {
            ans[i] = getPrompt(settings, slideCount, i, offset);
        }
        return ans;
    }

    function getPrompt(settings, slideCount, slideIndex, offset) {
        for (var i = 0; i < settings.messages.length; i++) {
            var msg = settings.messages[i];
            if (!match(msg)) continue;
            logger.info('match slideCount:', slideCount, 'slideIndex:', slideIndex, 'offset:', offset, 'msg:', msg);
            return nextPrompt(msg.prompts);
        } 
        // uh oh, no match found. This should not happen...
        logger.error('No matching end message found for slide:', slideIndex, slideCount);
        // pretend nothing happened, tee-hee:
        return "Weiter geht's!";

        function nextPrompt(prompts) {
            var index = (slideIndex + offset) % prompts.length;
            return prompts[index];
        }

        // Determine if the given message's slide value matches slideIndex.
        function match(msg) {
            var t = typeof msg.slide;
            if (t === 'string' && msg.slide.toLowerCase() === 'any') {
                return true;
            } else if (t === 'number') {
                return slideIndex === utils.getAbsoluteSlideIndex(msg.slide, slideCount);
            }
        }
    }


    function filterInvalidMessages(messages, logger, slideCount) {
        return f.afilter(messages, isValid);

        function isValid(msg) {
            var type = typeof msg.slide;
            if (type !== 'number' && type !== 'string') {
                logger.error('bad format, slide must be number or string:', msg);
                return false;
            }
            if (type === 'string' && msg.slide.toLowerCase() !== 'any') {
                logger.error('bad format, when slide is a string, it should equal "any"', msg);
                return false;
            }
            var isInteger = msg.slide % 1 === 0;
            if ((msg.slide >= 1 || msg.slide <= 0) && !isInteger) {
                logger.error('bad format, slide outside of (0..1) should be an integer.', msg);
                return false;
            }
            if (msg.slide < 0 && Math.abs(msg.slide) >= slideCount) {
                logger.error('bad format, negative slide is too small (slideCount=' + 
                            slideCount + '):', msg);
                return false;
            }
            if (!msg.prompts || !msg.prompts.length) {
                logger.error('bad format, no prompts:', msg);
                return false;
            }
            return true;
        }
    }
}


},{"../f.js":2,"../utils.js":8}],7:[function(require,module,exports){
"use strict";
/** toc.js - extract the table of contents from html
 *
 */

var f = require('../f.js');
var utils = require('../utils.js');

module.exports = tocJs;

function tocJs(api, logger) {
    var toc, leaves;

    api.onSlideClose(function(){
        toc = undefined;
        leaves = undefined;
    });

    api.addService('toc', function() {
        logger.info('getting toc...');
        if (!toc) toc = getToc(api.elements.document);
        return toc;
    });

    api.addService('toc-leaves-only', function(filters) {
        if (!leaves) leaves = getLeavesOnly(api.elements.document, filters);
        return leaves;
    });

    function hasClass(elem, className) {
        return f.afindIndex(elem.classList, function(c) {return c === className;}) > -1;
    }


    function applyFilters(node, i, count, filters) {
        for (var j = 0; j < filters.length; j++) {
            var f = filters[j];
            var t = typeof f;
            if (t === 'number') {
                var n = utils.getAbsoluteSlideIndex(f, count);
                var ans = (n === i);
                if (ans) return false;
                else continue;
            }
            if (t === 'string') {
                if (f === node.title) return false;
                else continue;
            }
            if (f && f.constructor === RegExp) {
                if (f.test(node.title)) return false;
                else continue;
            }
            if (t === 'function') {
                if (f(node, i)) return false;
                else continue;
            }
        }
        return true;
    }

    function getDepth(elem) {
        // css class: depthN_M
        // M = Tiefe des elem-Knotes (ab 0).
        // keine Ahnung, welche Funktion M hat, war bis jetzt immer 0!
        var match = elem.className.match(/depth(\d+)_(\d+)/);
        //if (match && match[2] !== '0') logger.warning('HEY: depthN_M, M !== 0', elem);
        return match && parseInt(match[1]);
    }

    function getLeavesOnly(doc, filters) {
        toc = toc || getToc(doc);
        var leaves = {};
        leaves.chapters = f.afilter(toc.chapters, function(node, i) {
           if (node.hasChildren) return false;
           if (filters) {
               return applyFilters(node, i, toc.chapters.length, filters);
           }
           else return true;
       });
       leaves.selected = f.afindIndex(leaves.chapters, function(leaf, i) {
           return leaf.selected;
       });
       return leaves;
    }
    
    function getToc(doc) {
        var slideList = doc.getElementById('slide_list');
        if (!slideList) {
            logger.warning('#slide_list nicht gefunden, Abbruch.');
            return;
        }
        var chapterElems = slideList.getElementsByTagName('li');

        var selectedIndex = -1;
        var chapterInfo = f.amap(chapterElems, function(x, i) {
            var selected = hasClass(x, 'selected');
            if (selected) selectedIndex = i;
            return {
                hasChildren: hasClass(x, 'has_children'),
                title: x.textContent,
                depth: getDepth(x),
                selected: hasClass(x, 'selected')
            };
        });
        logger.info('getToc:', selectedIndex, chapterInfo);
        var ans = {
            selected: selectedIndex,
            chapters: chapterInfo
        }; 
        return ans;
    }
}


},{"../f.js":2,"../utils.js":8}],8:[function(require,module,exports){
"use static";
// Utils
utils = {};
module.exports = utils;

// MutationObserver alternative wegen ie10
// wartet, bis ein bestimmtes element hinzugefuegt wurde.
// waitForChild {{{1
utils.waitForChild = function(element, selector, callback, interval) {
    interval = interval || 100;
    var timerid = setTimeout(ontime, interval);
    function ontime() {
        if (element.childElementCount === 0) return;
        var child = element.querySelector(selector);
        if (child) callback(child);
        else timerid = setTimeout(ontime, interval);
    }
};
// 1}}}

/**
 * gibt true zurueck falls das touch api verfuegbar ist.
 * Touch api ist leider nicht 100% zuverlaessig.
 * @returns {boolean}
 */
// isTouchSupported? {{{1
utils.isTouchSupported = function() {
    var msTouchEnabled = window.navigator.msMaxTouchPoints;
    var generalTouchEnabled = "ontouchstart" in document.createElement("div");
    return msTouchEnabled || generalTouchEnabled;
};
// 1}}}
        
/**
 * gibt true zurueck, falls der user agent auf ein Mobilgeraet schliessen laesst.
 * nur bedingt zuverlaessig, da nicht standartisiert.
 * @returns {boolean}
 */
// isMobileUserAgent? {{{1
utils.isMobileUserAgent = function() {
    var agent = navigator.userAgent || navigator.vendor || window.opera;
    return /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od|ad)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(agent) || 
           /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(agent.substr(0, 4));
};
// 1}}}

/**
 * Sucht eine Zahl im gegebenen Array, die von der gegebenen Zahl f 
 * um nicht mehr als epsilon abweicht.
 * @param {number} f, die Zahl nach der gesucht werden soll.
 * @param {number[]} arr, das Array das durchsucht werden soll.
 * @param {number} epsilon, die maximale Abweichung. Wenn nicht gegeben, wird Number.EPSILON verwendet.
 * @returns {number} der Index der gefundenen Zahl oder undefined, wenn keine gefunden wurde.
 */
// getFloatInArray {{{1
utils.getFloatInArray = function(f, arr, epsilon) {
    epsilon = epsilon || Number.EPSILON;
    for (var i = 0, len = arr.length; i < len; i++)
        if ((Math.abs(f - arr[i])) <= epsilon) return i;
};
// 1}}}

/** 
 * gibt das document element des gegebenes iframes zurueck. 
 * @param elem {HTMLElement} - der iframe, dessen document zurueck gegeben werden soll
 * @returns {HTMLDocument}
 */ 
// getFrameDocument {{{1
utils.getFrameDocument = function(elem) {
    var ans = elem.contentWindow.contentDocument || elem.contentWindow.document;
    utils.assert(ans, 'Konnte frame document nicht finden!');
    return ans;
};
// 1}}}

// addStyleSheet {{{1
utils.addStyleSheet = function(doc, rules) {
    var css = doc.createElement('style');
    css.type = 'text/css';
    if (css.styleSheet) css.styleSheet.cssText = rules;
    else css.appendChild(doc.createTextNode(rules));
    doc.getElementsByTagName("head")[0].appendChild(css);
    return css;
};
// 1}}}


utils.loadScript = function(doc, src, mime, callback) {
    var script = doc.createElement('script');
    script.type = mime || 'text/javascript';
    script.onload(function() {
        console.log(script);
        callback(script.textContent);
    });
    script.src = src;
    doc.appendChild(script);
};

/** 
 * Gibt true zurueck, falls <elem> das Tag <tagname> hat und alle in <classes> definierte Klassen.
 * @param elem {HTMLElement}
 * @param tagname {string}
 * @param classes {string[]}Var i =
 * @param id {string}
 */
// doesElemMatch {{{1
utils.doesElemMatch = function(elem, tagname, classes, id) {
    if (tagname && elem.tagName !== tagname.toUpperCase()) return false;
    if (id && elem.id !== id) return false;
    if (!classes) return true;
    for (var j = 0, len = classes.length; j < len; j++) {
        if (!elem.classList.contains(classes[j])) return false;
    }
    return true;
};
// 1}}}

/** 
 * Sucht ein Element in <elems>, das das Tag <tagname> hat und alle in <classes> definierten Klassen.
 * Gibt das gefundene Element zurueck, oder null, falls keines gefunden wurde.
 * @param elem {HTMLElement}
 * @param tagname {string}
 * @param classes {string[]}
 */
// findElement {{{1
utils.findElement = function(elems, tagname, classes, id) {
    var elem;
    for (var i = 0, len = elems.length; i < len; i++) {
        elem = elems[i];
        if (utils.doesElemMatch(elem, tagname, classes, id)) return elem;
    }
    return null;
};
// 1}}}

/** Gibt das oberste DOM Fenster zurueck.
 * @returns {Window}, das oberste Fenster 
*/
// getRootWindow {{{1
utils.getRootWindow = function() {
    var wnd, root;
    do {
        wnd = root || window;
        root = wnd.parent;
    } while (root !== wnd);
    return root;
};
// 1}}}

// isVisible? {{{1
utils.isVisible = function(elem) {
    return !!(elem.offsetParent || elem.offsetWidth || 
            elem.offsetHeight || elem.getClientRects().length);
};
// 1}}}

// toArray {{{1
// Array.from ist leider ES6
utils.toArray = function(arraylike) {
    var arr = [];
    for (var i = 0; i < arraylike.length; i++)
        arr[i] = arraylike[i];
    return arr;
};
// 1}}}

/*
 * async - fuehrt mehrere voneinander abhaengige funktionen asynchron aus.
 * @param initial {any} Der Wert, der der ersten Funktionbb uebergeben werden soll.
 * @param tasks {function...} ein oder mehr Argumente. Jede Funktion muss ein callback
 *                            und das Ergebnis des vorherigen Tasks entgegen nehmen.
 *                            Liegt ein Ergebnis vor, muss die callback-funktion damit
 *                            aufrufen werden. 
 *                            Zum Abbruch der Kette muss ein Fehler geworfen werden.
 */
// async {{{1
utils.async = function(initial, tasks) {
  if (arguments.length === 0) throw new Error('argument required');
  var chain = utils.toArray(arguments).slice(1);
  var head = -1;
  var top = chain.length - 1;
  var id = utils.nextUid();

  callback(initial);

  function callback(result) {
    head++;
//    console.log('[async#'+id+'] head:', head, 'result:', result);
    if (head > top) {
//        console.log('[async#'+id+'] head:', head, 'result:', result, 'DONE');
        return;
    }
    var task = chain[head];
    task(callback, result);
  }
};
// 1}}}

var uid = 0;
utils.nextUid = function() {
    return uid++;
};

utils.findInArray = function(arr, predicate) {
    for (var i = 0; i < arr.length; i++)
        if (predicate(arr[i])) return arr[i];
};

utils.hashString = function(str) {
    var hash = 0; 
    var i, chr, len;
    if (str.length === 0) return hash;
    for (i = 0, len = str.length; i < len; i++) {
        chr = str.charCodeAt(i);
        hash = ((hash << 5) - hash) + chr;
        hash |= 0; // Convert to 32bit integer
    }
    return hash;   
};


/**
 * Erzeugt einen Fehler, wenn cond false ist.
 * @param {boolean} cond, Die zu pruefende Bedingung.
 * @param {string} msg, Die Meldung, die im Fall eines Fehlers ausgegeben werden soll.
 */
utils.assert = function(cond, msg) {
    if (!cond) throw new Error(msg || 'Assertion failed.');
};

utils.assertExists = function(obj, name) {
    if (obj !== null && obj !== undefined) return obj;
    throw new Error(name + ' is undefined or null.');
};

/**
 *
 */
utils.getAbsoluteSlideIndex = function(index, count) {
    if (index >= 0 && index % 1 === 0) return index;
    if (count <= 0) return NaN;
    // negative indezes are only valid if count-index >= 0
    if (count + index < 0) return NaN;
    if (index < 0) return count + index;
    // floats inside the 0..1 range:
    if (index > 0 && index < 1) {
        return Math.ceil(count * index);
    } 
    // floats outside the 0..1 range are invalid:
    if (index % 1 !== 0) return NaN;
};

utils.xhr = function(file, settle, reject, mime, method) {
    var req = new XMLHttpRequest();
    method = method || 'GET';
    req.addEventListener('load', settle);
    req.addEventListener('error', reject);
    req.addEventListener('abort', reject);
    req.open(method, file, true);
    if (mime) req.setRequestHeader('Accept', mime);
    req.send();
    return req;
};

},{}],"target":[function(require,module,exports){
"use strict";
var toc = require('../modules/toc.js');
// var controlsOnTop = require('../modules/controls-on-top.js');
// var zoom = require('../modules/zoom.js');    
var atheft = require('../modules/anti-theft.js');
// var tooltip = require('../modules/tooltip.js');
var endPrompt = require('../modules/end-prompt.js');
 
module.exports = {
    "toc": toc,
//    "control": controlsOnTop,
//    "zoom": zoom, 
    "atheft": atheft, 
//    "tooltip": tooltip,
    "endPrompt": endPrompt
};


},{"../modules/anti-theft.js":5,"../modules/end-prompt.js":6,"../modules/toc.js":7}]},{},[4]);
